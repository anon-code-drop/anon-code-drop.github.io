package secpriv.horst.data;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import secpriv.horst.tools.TestBuilder;
import secpriv.horst.types.Type;
import secpriv.horst.visitors.VisitorState;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.*;

class ExpressionViewTest {
    private TestBuilder testBuilder;

    @BeforeEach
    public void setUp() {
        VisitorState state = new VisitorState();
        state.defineFreeVar("?a", Type.Integer);
        state.defineFreeVar("?b", Type.Integer);
        state.defineFreeVar("?bo", Type.Boolean);
        state.defineFreeVar("?ai", Type.Array.of(Type.Integer));
        state.defineFreeVar("?ai2", Type.Array.of(Type.Integer));
        state.defineFreeVar("?ab", Type.Array.of(Type.Boolean));
        testBuilder = new TestBuilder(state);
    }

    @Test
    public void testSimpleAdditiveTermThrowsOnComplexTerm() {
        Expression e1 = testBuilder.parseExpression("(1 + ?a) + 2");
        assertThatThrownBy(() -> new ExpressionView.SimpleAdditiveTerm(e1)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void testSimpleAdditiveTermEquality1() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a + 2"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a + 2"));

        assertThat(v1).isEqualTo(v2);
        assertThat(v1.hashCode()).isEqualTo(v2.hashCode());
        assertThat(v1.isComparable(v2)).isTrue();
    }

    @Test
    public void testSimpleAdditiveTermEquality2() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a + 2"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a - 2"));

        assertThat(v1).isNotEqualTo(v2);
        assertThat(v1.isComparable(v2)).isTrue();
    }

    @Test
    public void testSimpleAdditiveTermEquality3() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a + 2"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a + ~2"));

        assertThat(v1).isNotEqualTo(v2);
        assertThat(v1.isComparable(v2)).isTrue();
    }

    @Test
    public void testSimpleAdditiveTermEquality4() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a + 2"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a - ~2"));

        assertThat(v1).isEqualTo(v2);
        assertThat(v1.hashCode()).isEqualTo(v2.hashCode());
        assertThat(v1.isComparable(v2)).isTrue();
    }

    @Test
    public void testSimpleAdditiveTermEquality5() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a - 2"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a + 2"));

        assertThat(v1).isNotEqualTo(v2);
        assertThat(v1.isComparable(v2)).isTrue();
    }

    @Test
    public void testSimpleAdditiveTermEquality6() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a - 2"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a - 2"));

        assertThat(v1).isEqualTo(v2);
        assertThat(v1.hashCode()).isEqualTo(v2.hashCode());
        assertThat(v1.isComparable(v2)).isTrue();
    }

    @Test
    public void testSimpleAdditiveTermEquality7() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a - 2"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a + ~2"));

        assertThat(v1).isEqualTo(v2);
        assertThat(v1.hashCode()).isEqualTo(v2.hashCode());
        assertThat(v1.isComparable(v2)).isTrue();
    }

    @Test
    public void testSimpleAdditiveTermEquality8() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a - 2"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a - ~2"));

        assertThat(v1).isNotEqualTo(v2);
        assertThat(v1.isComparable(v2)).isTrue();
    }

    @Test
    public void testSimpleAdditiveTermEquality9() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a + ~2"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a + 2"));

        assertThat(v1).isNotEqualTo(v2);
        assertThat(v1.isComparable(v2)).isTrue();
    }

    @Test
    public void testSimpleAdditiveTermEquality10() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a + ~2"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a - 2"));

        assertThat(v1).isEqualTo(v2);
        assertThat(v1.hashCode()).isEqualTo(v2.hashCode());
        assertThat(v1.isComparable(v2)).isTrue();
    }

    @Test
    public void testSimpleAdditiveTermEquality11() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a + ~2"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a + ~2"));

        assertThat(v1).isEqualTo(v2);
        assertThat(v1.hashCode()).isEqualTo(v2.hashCode());
        assertThat(v1.isComparable(v2)).isTrue();
    }

    @Test
    public void testSimpleAdditiveTermEquality12() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a + ~2"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a - ~2"));

        assertThat(v1).isNotEqualTo(v2);
        assertThat(v1.isComparable(v2)).isTrue();
    }

    @Test
    public void testSimpleAdditiveTermEquality13() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a - ~2"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a + 2"));

        assertThat(v1).isEqualTo(v2);
        assertThat(v1.hashCode()).isEqualTo(v2.hashCode());
        assertThat(v1.isComparable(v2)).isTrue();
    }

    @Test
    public void testSimpleAdditiveTermEquality14() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a - ~2"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a - 2"));

        assertThat(v1).isNotEqualTo(v2);
        assertThat(v1.isComparable(v2)).isTrue();
    }

    @Test
    public void testSimpleAdditiveTermEquality15() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a - ~2"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a + ~2"));

        assertThat(v1).isNotEqualTo(v2);
        assertThat(v1.isComparable(v2)).isTrue();
    }

    @Test
    public void testSimpleAdditiveTermEquality16() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a - ~2"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a - ~2"));

        assertThat(v1).isEqualTo(v2);
        assertThat(v1.hashCode()).isEqualTo(v2.hashCode());
        assertThat(v1.isComparable(v2)).isTrue();
    }

    @Test
    public void testSimpleAdditiveTermEqualityExhaustively() {
        List<String> aPlusThree = Arrays.asList("?a + 3", "3 + ?a", "?a - ~3");
        List<String> threeMinusA = Collections.singletonList("3 - ?a");
        List<String> minusThreeMinusA = Collections.singletonList("~3 - ?a");
        List<String> aMinusThree = Arrays.asList("?a - 3", "?a + ~3", "~3 + ?a");

        for(List<String> equivalenceClass1 : Arrays.asList(aPlusThree, threeMinusA, aMinusThree, minusThreeMinusA)) {
            for (String s1 : equivalenceClass1) {
                for (String s2 : equivalenceClass1) {
                    ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression(s1));
                    ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression(s2));

                    assertThat(v1).isEqualTo(v2);
                    assertThat(v1.hashCode()).isEqualTo(v2.hashCode());
                    assertThat(v1.isComparable(v2)).isTrue();
                }
            }
            for(List<String> equivalenceClass2 : Arrays.asList(aPlusThree, threeMinusA, aMinusThree)) {
                if(equivalenceClass1 == equivalenceClass2) {
                    continue;
                }
                for (String s1 : equivalenceClass1) {
                    for (String s2 : equivalenceClass2) {
                        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression(s1));
                        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression(s2));

                        assertThat(v1).isNotEqualTo(v2);
                        assertThat(v1.isComparable(v2)).isTrue();
                    }
                }
            }
        }

    }


    @Test
    public void test3() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("2 + ?a"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a + 2"));

        assertThat(v1).isEqualTo(v2);
        assertThat(v1.hashCode()).isEqualTo(v2.hashCode());
    }

    @Test
    public void test4() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a - 2"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a - 2"));

        assertThat(v1).isEqualTo(v2);
        assertThat(v1.hashCode()).isEqualTo(v2.hashCode());
    }

    @Test
    public void test5() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("2 - ?a"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a - 2"));

        assertThat(v1).isNotEqualTo(v2);
    }

    @Test
    public void test6() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a"));

        assertThat(v1).isEqualTo(v2);
        assertThat(v1.hashCode()).isEqualTo(v2.hashCode());
    }

    @Test
    public void testRightAddZeroEqualFreeVar() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a + 0"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a"));

        assertThat(v1).isEqualTo(v2);
        assertThat(v1.hashCode()).isEqualTo(v2.hashCode());
    }

    @Test
    public void testLeftAddZeroEqualFreeVar() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("0 + ?a"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a"));

        assertThat(v1).isEqualTo(v2);
        assertThat(v1.hashCode()).isEqualTo(v2.hashCode());
    }

    @Test
    public void testRightMinusZeroEqualFreeVar() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a - 0"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a"));

        assertThat(v1).isEqualTo(v2);
        assertThat(v1.hashCode()).isEqualTo(v2.hashCode());
    }

    @Test
    public void testAddZeroEqualsMinusZero() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a - 0"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("0 + ?a"));
        ExpressionView.SimpleAdditiveTerm v3 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a + 0"));
        ExpressionView.SimpleAdditiveTerm v4 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a"));

        ExpressionView.SimpleAdditiveTerm vm = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("0 - ?a"));

        for (ExpressionView.SimpleAdditiveTerm vx : Arrays.asList(v1, v2, v3, v4)) {
            for (ExpressionView.SimpleAdditiveTerm vy : Arrays.asList(v1, v2, v3, v4)) {
                assertThat(vx).isEqualTo(vy);
            }
            assertThat(vx).isNotEqualTo(vm);
            assertThat(vm).isNotEqualTo(vx);
        }
    }

    @Test
    public void testAddConstantUnequalMinusConstant() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a + 1"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("1 + ?a"));

        ExpressionView.SimpleAdditiveTerm vm1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a"));
        ExpressionView.SimpleAdditiveTerm vm2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("1 - ?a"));
        ExpressionView.SimpleAdditiveTerm vm3 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a - 1"));

        for (ExpressionView.SimpleAdditiveTerm vx : Arrays.asList(v1, v2)) {
            for (ExpressionView.SimpleAdditiveTerm vy : Arrays.asList(v1, v2)) {
                assertThat(vx).isEqualTo(vy);
            }

            for(ExpressionView.SimpleAdditiveTerm vm : Arrays.asList(vm1, vm2, vm3)) {
                assertThat(vx).isNotEqualTo(vm);
                assertThat(vm).isNotEqualTo(vx);
            }
        }
    }

    @Test
    public void testLeftMinusZeroUnequalFreeVar() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("0 - ?a"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a"));

        assertThat(v1).isNotEqualTo(v2);
    }

    @Test
    public void testLeftMinusZeroUnequalRightAddZero() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("0 - ?a"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("?a + 0"));

        assertThat(v1).isNotEqualTo(v2);
    }

    @Test
    public void testLeftMinusZeroUnequalLeftAddZero() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("0 - ?a"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("0 + ?a"));

        assertThat(v1).isNotEqualTo(v2);
    }

    @Test
    public void test12() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("0 - ?a"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("0 - ?a"));

        assertThat(v1).isEqualTo(v2);
        assertThat(v1.hashCode()).isEqualTo(v2.hashCode());
    }


    @Test
    public void test13() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("2"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("2"));

        assertThat(v1).isEqualTo(v2);
        assertThat(v1.hashCode()).isEqualTo(v2.hashCode());
    }

    @Test
    public void test14() {
        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("3"));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(testBuilder.parseExpression("2"));

        assertThat(v1).isNotEqualTo(v2);
    }

    @Test
    public void testIsArrayInitIsSimpleArray() {
        Optional<ExpressionView.SimpleArray> v1 = ExpressionView.viewAsSimpleArray(testBuilder.parseExpression("[3]"));

        assertThat(v1).isPresent();
    }

    @Test
    public void testFreeVarIsSimpleArray() {
        Optional<ExpressionView.SimpleArray> v1 = ExpressionView.viewAsSimpleArray(testBuilder.parseExpression("?ai"));
        assertThat(v1).isPresent();
    }

    @Test
    public void testConstantIndexStoreIsSimpleArray() {
        Optional<ExpressionView.SimpleArray> v1 = ExpressionView.viewAsSimpleArray(testBuilder.parseExpression("(store ?ai 1 ?a)"));
        assertThat(v1).isPresent();
    }

    @Test
    public void testFreeVarIndexStoreIsSimpleArray() {
        Optional<ExpressionView.SimpleArray> v1 = ExpressionView.viewAsSimpleArray(testBuilder.parseExpression("(store ?ai ?a 2)"));
        assertThat(v1).isPresent();
    }

    @Test
    public void testNestedFreeVarIndexStoreIsSimpleArray() {
        Optional<ExpressionView.SimpleArray> v1 = ExpressionView.viewAsSimpleArray(testBuilder.parseExpression("(store (store ?ai ?a 2) ?a 4)"));
        assertThat(v1).isPresent();
    }

    @Test
    public void testNestedDifferentFreeVarIndexStoreIsNotSimpleArray() {
        Optional<ExpressionView.SimpleArray> v1 = ExpressionView.viewAsSimpleArray(testBuilder.parseExpression("(store (store ?ai ?a 2) ?b 4)"));
        assertThat(v1).isNotPresent();
    }

    @Test
    public void testSimpleAdditiveIndexStoreIsSimpleArray() {
        Optional<ExpressionView.SimpleArray> v1 = ExpressionView.viewAsSimpleArray(testBuilder.parseExpression("(store ?ai (?a + 1) 2)"));
        assertThat(v1).isPresent();
    }

    @Test
    public void testNestedSimpleAdditiveIndexStoreIsSimpleArray() {
        Optional<ExpressionView.SimpleArray> v1 = ExpressionView.viewAsSimpleArray(testBuilder.parseExpression("(store (store ?ai (?a + 1) 2) (2 - ?a) 4)"));
        assertThat(v1).isPresent();
    }

    @Test
    public void testNestedSimpleAdditiveIndexStoreWithDifferentVariablesIsNotSimpleArray() {
        Optional<ExpressionView.SimpleArray> v1 = ExpressionView.viewAsSimpleArray(testBuilder.parseExpression("(store (store ?ai (?a + 1) 2) (2 - ?b) 4)"));
        assertThat(v1).isNotPresent();
    }

    @Test
    public void testIsSimpleEqualityIntegerEquality1() {
        Optional<ExpressionView.SimpleEquality> v1 = ExpressionView.viewAsSimpleEquality(testBuilder.parseExpression("?a = 1"));
        assertThat(v1).isPresent();
        assertThat(v1.get().getFreeVar()).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        assertThat(v1.get().getValue()).isEqualTo(new Expression.IntConst(BigInteger.ONE));
    }

    @Test
    public void testIsSimpleEqualityIntegerEquality2() {
        Optional<ExpressionView.SimpleEquality> v1 = ExpressionView.viewAsSimpleEquality(testBuilder.parseExpression("1 = ?a"));
        assertThat(v1).isPresent();
        assertThat(v1.get().getFreeVar()).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        assertThat(v1.get().getValue()).isEqualTo(new Expression.IntConst(BigInteger.ONE));
    }

    @Test
    public void testIntegerFreeVarIsNotSimpleEquality() {
        Optional<ExpressionView.SimpleEquality> v1 = ExpressionView.viewAsSimpleEquality(testBuilder.parseExpression("?a"));
        assertThat(v1).isNotPresent();
    }

    @Test
    public void testIsSimpleEqualityBooleanEquality1() {
        Optional<ExpressionView.SimpleEquality> v1 = ExpressionView.viewAsSimpleEquality(testBuilder.parseExpression("?bo = true"));
        assertThat(v1).isPresent();
        assertThat(v1.get().getFreeVar()).isEqualTo(new Expression.FreeVarExpression(Type.Boolean, "?bo"));
        assertThat(v1.get().getValue()).isEqualTo(Expression.BoolConst.TRUE);

    }

    @Test
    public void testIsSimpleEqualityBooleanEquality2() {
        Optional<ExpressionView.SimpleEquality> v1 = ExpressionView.viewAsSimpleEquality(testBuilder.parseExpression("false = ?bo"));
        assertThat(v1).isPresent();
        assertThat(v1.get().getFreeVar()).isEqualTo(new Expression.FreeVarExpression(Type.Boolean, "?bo"));
        assertThat(v1.get().getValue()).isEqualTo(Expression.BoolConst.FALSE);

    }

    @Test
    public void testIsSimpleEqualityBooleanEquality3() {
        Optional<ExpressionView.SimpleEquality> v1 = ExpressionView.viewAsSimpleEquality(testBuilder.parseExpression("?bo"));
        assertThat(v1).isPresent();
        assertThat(v1.get().getFreeVar()).isEqualTo(new Expression.FreeVarExpression(Type.Boolean, "?bo"));
        assertThat(v1.get().getValue()).isEqualTo(Expression.BoolConst.TRUE);

    }

    @Test
    public void testIsSimpleEqualityBooleanEquality4() {
        Optional<ExpressionView.SimpleEquality> v1 = ExpressionView.viewAsSimpleEquality(testBuilder.parseExpression("~?bo"));
        assertThat(v1).isPresent();
        assertThat(v1.get().getFreeVar()).isEqualTo(new Expression.FreeVarExpression(Type.Boolean, "?bo"));
        assertThat(v1.get().getValue()).isEqualTo(Expression.BoolConst.FALSE);

    }

    @Test
    public void testIsTrueEqualsComplexIsNotSimpleEqualityBooleanEquality() {
        Optional<ExpressionView.SimpleEquality> v1 = ExpressionView.viewAsSimpleEquality(testBuilder.parseExpression("true = select ?ab 2"));
        assertThat(v1).isNotPresent();

    }

    @Test
    public void testSimpleSelect1() {
        Optional<ExpressionView.SimpleSelect> v1 = ExpressionView.viewAsSimpleSelect(testBuilder.parseExpression("true = select ?ab 2"));
        assertThat(v1).isNotPresent();
    }

    @Test
    public void testSimpleSelect2() {
        Optional<ExpressionView.SimpleSelect> v1 = ExpressionView.viewAsSimpleSelect(testBuilder.parseExpression("select ?ab 2"));
        assertThat(v1).isPresent();
        assertThat(v1.get().getBase()).isEqualTo(new Expression.FreeVarExpression(Type.Array.of(Type.Boolean), "?ab"));
        assertThat(v1.get().getIndex()).isEqualTo(ExpressionView.viewAsSimpleAdditiveTerm(new Expression.IntConst(BigInteger.valueOf(2))).get());
    }

    @Test
    public void testSimpleSelectEquality1() {
        Optional<ExpressionView.SimpleSelectEquality> v1 = ExpressionView.viewAsSimpleSelectEquality(testBuilder.parseExpression("(select ?ai 3) = 2"));
        assertThat(v1).isPresent();
        assertThat(v1.get().getSelect()).isEqualTo(ExpressionView.viewAsSimpleSelect(testBuilder.parseExpression("select ?ai 3")).get());
        assertThat(v1.get().getValue()).isEqualTo(new Expression.IntConst(BigInteger.valueOf(2)));
    }

    @Test
    public void testSimpleSelectEquality2() {
        Optional<ExpressionView.SimpleSelectEquality> v1 = ExpressionView.viewAsSimpleSelectEquality(testBuilder.parseExpression("2 = (select ?ai 3)"));
        assertThat(v1).isPresent();
        assertThat(v1.get().getSelect()).isEqualTo(ExpressionView.viewAsSimpleSelect(testBuilder.parseExpression("select ?ai 3")).get());
        assertThat(v1.get().getValue()).isEqualTo(new Expression.IntConst(BigInteger.valueOf(2)));
    }

    @Test
    public void testSimpleSelectEquality3() {
        Optional<ExpressionView.SimpleSelectEquality> v1 = ExpressionView.viewAsSimpleSelectEquality(testBuilder.parseExpression("2 = (select ?ai (?a + ?b))"));
        assertThat(v1).isNotPresent();
    }

    @Test
    public void testSimpleSelectEquality4() {
        Optional<ExpressionView.SimpleSelectEquality> v1 = ExpressionView.viewAsSimpleSelectEquality(testBuilder.parseExpression("(select ?ai (?a + ?b)) = 2"));
        assertThat(v1).isNotPresent();
    }

    @Test
    public void testSimpleEqualityComparable1() {
        Optional<ExpressionView.SimpleEquality> v1 = ExpressionView.viewAsSimpleEquality(testBuilder.parseExpression("?a = 2"));
        Optional<ExpressionView.SimpleEquality> v2 = ExpressionView.viewAsSimpleEquality(testBuilder.parseExpression("?a = 1"));

        assertThat(v1.get().isComparable(v2.get())).isTrue();
    }

    @Test
    public void testSimpleEqualityComparable2() {
        Optional<ExpressionView.SimpleEquality> v1 = ExpressionView.viewAsSimpleEquality(testBuilder.parseExpression("?a = 2"));
        Optional<ExpressionView.SimpleEquality> v2 = ExpressionView.viewAsSimpleEquality(testBuilder.parseExpression("?b = 1"));

        assertThat(v1.get().isComparable(v2.get())).isFalse();
    }

    @Test
    public void testSimpleEqualityComparable3() {
        Optional<ExpressionView.SimpleEquality> v1 = ExpressionView.viewAsSimpleEquality(testBuilder.parseExpression("?a = 2"));
        Optional<ExpressionView.SimpleSelectEquality> v2 = ExpressionView.viewAsSimpleSelectEquality(testBuilder.parseExpression("(select ?ai 3) = 2"));

        assertThat(v1.get().isComparable(v2.get())).isFalse();
    }

    @Test
    public void testSimpleSelectEqualityComparable1() {
        Optional<ExpressionView.SimpleSelectEquality> v1 = ExpressionView.viewAsSimpleSelectEquality(testBuilder.parseExpression("(select ?ai 3) = 1"));
        Optional<ExpressionView.SimpleSelectEquality> v2 = ExpressionView.viewAsSimpleSelectEquality(testBuilder.parseExpression("(select ?ai 3) = 2"));

        assertThat(v1.get().isComparable(v2.get())).isTrue();
    }

    @Test
    public void testSimpleSelectEqualityComparable2() {
        Optional<ExpressionView.SimpleSelectEquality> v1 = ExpressionView.viewAsSimpleSelectEquality(testBuilder.parseExpression("(select ?ai 4) = 1"));
        Optional<ExpressionView.SimpleSelectEquality> v2 = ExpressionView.viewAsSimpleSelectEquality(testBuilder.parseExpression("(select ?ai 3) = 2"));

        assertThat(v1.get().isComparable(v2.get())).isTrue();
    }

    @Test
    public void testSimpleSelectEqualityComparable3() {
        Optional<ExpressionView.SimpleSelectEquality> v1 = ExpressionView.viewAsSimpleSelectEquality(testBuilder.parseExpression("(select ?ai ?a) = 1"));
        Optional<ExpressionView.SimpleSelectEquality> v2 = ExpressionView.viewAsSimpleSelectEquality(testBuilder.parseExpression("(select ?ai (?a + 1)) = 2"));

        assertThat(v1.get().isComparable(v2.get())).isTrue();
    }

    @Test
    public void testSimpleSelectEqualityComparable4() {
        Optional<ExpressionView.SimpleSelectEquality> v1 = ExpressionView.viewAsSimpleSelectEquality(testBuilder.parseExpression("(select ?ai ?a) = 1"));
        Optional<ExpressionView.SimpleSelectEquality> v2 = ExpressionView.viewAsSimpleSelectEquality(testBuilder.parseExpression("(select ?ai (?b + 1)) = 2"));

        assertThat(v1.get().isComparable(v2.get())).isFalse();
    }

    @Test
    public void testSimpleSelectEqualityComparable5() {
        Optional<ExpressionView.SimpleSelectEquality> v1 = ExpressionView.viewAsSimpleSelectEquality(testBuilder.parseExpression("(select ?ai ?a) = 1"));
        Optional<ExpressionView.SimpleSelectEquality> v2 = ExpressionView.viewAsSimpleSelectEquality(testBuilder.parseExpression("(select ?ai2 ?a) = 2"));

        assertThat(v1.get().isComparable(v2.get())).isFalse();
    }

    @Test
    public void testViewSimpleBound1() {
        Optional<ExpressionView.SimpleUpperBound> v1 = ExpressionView.viewAsSimpleUpperBound(testBuilder.parseExpression("?a < 3"));
        assertThat(v1).isPresent();
        assertThat(v1.get().getFreeVar()).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        assertThat(v1.get().getIntConst()).isEqualTo(new Expression.IntConst(BigInteger.valueOf(3)));
        assertThat(v1.get().isStrict()).isTrue();
    }

    @Test
    public void testViewSimpleBound2() {
        Optional<ExpressionView.SimpleLowerBound> v1 = ExpressionView.viewAsSimpleLowerBound(testBuilder.parseExpression("?a > 4"));
        assertThat(v1).isPresent();
        assertThat(v1.get().getFreeVar()).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        assertThat(v1.get().getIntConst()).isEqualTo(new Expression.IntConst(BigInteger.valueOf(4)));
        assertThat(v1.get().isStrict()).isTrue();
    }

    @Test
    public void testViewSimpleBound3() {
        Optional<ExpressionView.SimpleUpperBound> v1 = ExpressionView.viewAsSimpleUpperBound(testBuilder.parseExpression("5 > ?a"));
        assertThat(v1).isPresent();
        assertThat(v1.get().getFreeVar()).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        assertThat(v1.get().getIntConst()).isEqualTo(new Expression.IntConst(BigInteger.valueOf(5)));
        assertThat(v1.get().isStrict()).isTrue();
    }

    @Test
    public void testViewSimpleBound4() {
        Optional<ExpressionView.SimpleLowerBound> v1 = ExpressionView.viewAsSimpleLowerBound(testBuilder.parseExpression("6 < ?a"));
        assertThat(v1).isPresent();
        assertThat(v1.get().getFreeVar()).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        assertThat(v1.get().getIntConst()).isEqualTo(new Expression.IntConst(BigInteger.valueOf(6)));
        assertThat(v1.get().isStrict()).isTrue();
    }

    @Test
    public void testViewSimpleBound5() {
        Optional<ExpressionView.SimpleUpperBound> v1 = ExpressionView.viewAsSimpleUpperBound(testBuilder.parseExpression("?a <= 7"));
        assertThat(v1).isPresent();
        assertThat(v1.get().getFreeVar()).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        assertThat(v1.get().getIntConst()).isEqualTo(new Expression.IntConst(BigInteger.valueOf(7)));
        assertThat(v1.get().isStrict()).isFalse();
    }

    @Test
    public void testViewSimpleBound6() {
        Optional<ExpressionView.SimpleLowerBound> v1 = ExpressionView.viewAsSimpleLowerBound(testBuilder.parseExpression("?a >= 1"));
        assertThat(v1).isPresent();
        assertThat(v1.get().getFreeVar()).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        assertThat(v1.get().getIntConst()).isEqualTo(new Expression.IntConst(BigInteger.valueOf(1)));
        assertThat(v1.get().isStrict()).isFalse();
    }

    @Test
    public void testViewSimpleBound7() {
        Optional<ExpressionView.SimpleUpperBound> v1 = ExpressionView.viewAsSimpleUpperBound(testBuilder.parseExpression("2 >= ?a"));
        assertThat(v1).isPresent();
        assertThat(v1.get().getFreeVar()).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        assertThat(v1.get().getIntConst()).isEqualTo(new Expression.IntConst(BigInteger.valueOf(2)));
        assertThat(v1.get().isStrict()).isFalse();
    }

    @Test
    public void testViewSimpleBound8() {
        Optional<ExpressionView.SimpleLowerBound> v1 = ExpressionView.viewAsSimpleLowerBound(testBuilder.parseExpression("9 <= ?a"));
        assertThat(v1).isPresent();
        assertThat(v1.get().getFreeVar()).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        assertThat(v1.get().getIntConst()).isEqualTo(new Expression.IntConst(BigInteger.valueOf(9)));
        assertThat(v1.get().isStrict()).isFalse();
    }

    @Test
    public void testViewSimpleBoundUpperBoundCompareTo1() {
        Optional<ExpressionView.SimpleUpperBound> v1 = ExpressionView.viewAsSimpleUpperBound(testBuilder.parseExpression("?a < 9"));
        Optional<ExpressionView.SimpleUpperBound> v2 = ExpressionView.viewAsSimpleUpperBound(testBuilder.parseExpression("?a <= 8"));
        Optional<ExpressionView.SimpleUpperBound> v3 = ExpressionView.viewAsSimpleUpperBound(testBuilder.parseExpression("9 > ?a"));
        Optional<ExpressionView.SimpleUpperBound> v4 = ExpressionView.viewAsSimpleUpperBound(testBuilder.parseExpression("8 >= ?a"));

        List<ExpressionView.SimpleUpperBound> bounds1 = Stream.of(v1, v2, v3, v4).map(Optional::get).collect(Collectors.toList());

        for(ExpressionView.SimpleUpperBound a : bounds1) {
            for(ExpressionView.SimpleUpperBound b : bounds1) {
                assertThat(a.compareTo(b)).isEqualTo(0);
            }
        }
    }

    @Test
    public void testViewSimpleBoundUpperCompareTo2() {
        Optional<ExpressionView.SimpleUpperBound> v1 = ExpressionView.viewAsSimpleUpperBound(testBuilder.parseExpression("?a < 9"));
        Optional<ExpressionView.SimpleUpperBound> v2 = ExpressionView.viewAsSimpleUpperBound(testBuilder.parseExpression("?a <= 8"));
        Optional<ExpressionView.SimpleUpperBound> v3 = ExpressionView.viewAsSimpleUpperBound(testBuilder.parseExpression("9 > ?a"));
        Optional<ExpressionView.SimpleUpperBound> v4 = ExpressionView.viewAsSimpleUpperBound(testBuilder.parseExpression("8 >= ?a"));

        Optional<ExpressionView.SimpleUpperBound> v5 = ExpressionView.viewAsSimpleUpperBound(testBuilder.parseExpression("?a < 8"));
        Optional<ExpressionView.SimpleUpperBound> v6 = ExpressionView.viewAsSimpleUpperBound(testBuilder.parseExpression("?a <= 7"));
        Optional<ExpressionView.SimpleUpperBound> v7 = ExpressionView.viewAsSimpleUpperBound(testBuilder.parseExpression("8 > ?a"));
        Optional<ExpressionView.SimpleUpperBound> v8 = ExpressionView.viewAsSimpleUpperBound(testBuilder.parseExpression("7 >= ?a"));

        List<ExpressionView.SimpleUpperBound> bounds1 = Stream.of(v1, v2, v3, v4).map(Optional::get).collect(Collectors.toList());
        List<ExpressionView.SimpleUpperBound> bounds2 = Stream.of(v5, v6, v7, v8).map(Optional::get).collect(Collectors.toList());

        for(ExpressionView.SimpleUpperBound a : bounds1) {
            for(ExpressionView.SimpleUpperBound b : bounds2) {
                assertThat(a.compareTo(b)).isEqualTo(-1);
            }
        }

        for(ExpressionView.SimpleUpperBound a : bounds2) {
            for(ExpressionView.SimpleUpperBound b : bounds1) {
                assertThat(a.compareTo(b)).isEqualTo(1);
            }
        }
    }

    @Test
    public void testViewSimpleBoundLowerBoundCompareTo1() {
        Optional<ExpressionView.SimpleLowerBound> v1 = ExpressionView.viewAsSimpleLowerBound(testBuilder.parseExpression("?a > 9"));
        Optional<ExpressionView.SimpleLowerBound> v2 = ExpressionView.viewAsSimpleLowerBound(testBuilder.parseExpression("?a >= 8"));
        Optional<ExpressionView.SimpleLowerBound> v3 = ExpressionView.viewAsSimpleLowerBound(testBuilder.parseExpression("9 < ?a"));
        Optional<ExpressionView.SimpleLowerBound> v4 = ExpressionView.viewAsSimpleLowerBound(testBuilder.parseExpression("8 <= ?a"));

        List<ExpressionView.SimpleLowerBound> bounds1 = Stream.of(v1, v2, v3, v4).map(Optional::get).collect(Collectors.toList());

        for(ExpressionView.SimpleLowerBound a : bounds1) {
            for(ExpressionView.SimpleLowerBound b : bounds1) {
                assertThat(a.compareTo(b)).isEqualTo(0);
            }
        }
    }

    @Test
    public void testViewSimpleBoundLowerBoundCompareTo2() {
        Optional<ExpressionView.SimpleLowerBound> v1 = ExpressionView.viewAsSimpleLowerBound(testBuilder.parseExpression("?a > 9"));
        Optional<ExpressionView.SimpleLowerBound> v2 = ExpressionView.viewAsSimpleLowerBound(testBuilder.parseExpression("?a >= 8"));
        Optional<ExpressionView.SimpleLowerBound> v3 = ExpressionView.viewAsSimpleLowerBound(testBuilder.parseExpression("9 < ?a"));
        Optional<ExpressionView.SimpleLowerBound> v4 = ExpressionView.viewAsSimpleLowerBound(testBuilder.parseExpression("8 <= ?a"));

        Optional<ExpressionView.SimpleLowerBound> v5 = ExpressionView.viewAsSimpleLowerBound(testBuilder.parseExpression("?a > 8"));
        Optional<ExpressionView.SimpleLowerBound> v6 = ExpressionView.viewAsSimpleLowerBound(testBuilder.parseExpression("?a >= 7"));
        Optional<ExpressionView.SimpleLowerBound> v7 = ExpressionView.viewAsSimpleLowerBound(testBuilder.parseExpression("8 < ?a"));
        Optional<ExpressionView.SimpleLowerBound> v8 = ExpressionView.viewAsSimpleLowerBound(testBuilder.parseExpression("7 <= ?a"));

        List<ExpressionView.SimpleLowerBound> bounds1 = Stream.of(v1, v2, v3, v4).map(Optional::get).collect(Collectors.toList());
        List<ExpressionView.SimpleLowerBound> bounds2 = Stream.of(v5, v6, v7, v8).map(Optional::get).collect(Collectors.toList());


        for(ExpressionView.SimpleLowerBound a : bounds1) {
            for(ExpressionView.SimpleLowerBound b : bounds2) {
                assertThat(a.compareTo(b)).isEqualTo(1);
            }
        }

        for(ExpressionView.SimpleLowerBound a : bounds2) {
            for(ExpressionView.SimpleLowerBound b : bounds1) {
                assertThat(a.compareTo(b)).isEqualTo(-1);
            }
        }
    }
}