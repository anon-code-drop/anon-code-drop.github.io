package secpriv.horst.translation;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import secpriv.horst.data.Expression;
import secpriv.horst.data.Proposition;
import secpriv.horst.data.Rule;
import secpriv.horst.tools.TestBuilder;
import secpriv.horst.translation.visitors.RenameFreeVariablesRuleVisitor;
import secpriv.horst.visitors.SExpressionRuleVisitor;
import secpriv.horst.visitors.VisitorState;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;

class MediumStepTransformerTest {
    private TestBuilder testBuilder;

    @BeforeEach
    public void setUp() {
        VisitorState state = new VisitorState();
        testBuilder = new TestBuilder(state);

        testBuilder.definePredicate("pred Aa{}: int;");
        testBuilder.definePredicate("pred Bb{}: int;");
        testBuilder.definePredicate("pred Cc{}: int;");
        testBuilder.definePredicate("pred Dd{}: int;");
    }

    @AfterEach
    void tearDown() {
        testBuilder = null;
    }

    @Test
    public void testExhaustiveMandatoryImplication1() {
        Rule r0a = testBuilder.defineRule("rule ra0 := clause [?x : int] ?x mod 2 = 0 => Aa(?x);");
        Rule r0b = testBuilder.defineRule("rule rb0 := clause [?x : int] ?x > 0 => Bb(?x);");
        Rule r1 = testBuilder.defineRule("rule r1 := clause [?x : int] Aa(?x), Bb(?x) => Cc(?x);");
        Rule q = testBuilder.defineQuery("query q [?x : int] Cc(?x), ?x = 4;");

        RenameFreeVariablesRuleVisitor renameFreeVariablesRuleVisitor = new RenameFreeVariablesRuleVisitor();
        List<Rule> rules = Stream.of(r0a, r0b, r1, q).map(r -> r.accept(renameFreeVariablesRuleVisitor)).collect(Collectors.toList());

        rules.forEach(r -> System.out.println(r.accept(new SExpressionRuleVisitor())));

        rules = MediumStepTransformer.foldToMediumStepsWithMagic(rules, PruneStrategy.Enum.none.strategy, PredicateInliningStrategy.Enum.linearExhaustive.strategy);

        assertThat(rules).hasSize(1);
        assertThat(rules).allSatisfy(r -> {
            assertThat(r.clauses).hasSize(1);
            assertThat(r.clauses.get(0).premises).hasSize(1);
            assertThat(r.clauses.get(0).premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p -> assertThat(p.expression).isEqualTo(Expression.BoolConst.TRUE));
            assertThat(r.clauses.get(0).conclusion.predicate.name).isEqualTo("q");
        });
    }

    @Test
    public void testExhaustiveMandatoryImplication2() {
        Rule r0a = testBuilder.defineRule("rule ra0 := clause [?x : int] ?x mod 2 = 0 => Aa(?x);");
        Rule r0b = testBuilder.defineRule("rule rb0 := clause [?x : int] ?x > 0 => Bb(?x);");
        Rule r1 = testBuilder.defineRule("rule r1 := clause [?x : int] Aa(?x), Bb(?x) => Cc(?x);");
        Rule q = testBuilder.defineQuery("query q [?x : int] Cc(?x), ?x = 3;");

        RenameFreeVariablesRuleVisitor renameFreeVariablesRuleVisitor = new RenameFreeVariablesRuleVisitor();
        List<Rule> rules = Stream.of(r0a, r0b, r1, q).map(r -> r.accept(renameFreeVariablesRuleVisitor)).collect(Collectors.toList());

        rules.forEach(r -> System.out.println(r.accept(new SExpressionRuleVisitor())));

        rules = MediumStepTransformer.foldToMediumStepsWithMagic(rules, PruneStrategy.Enum.none.strategy, PredicateInliningStrategy.Enum.linearExhaustive.strategy);

        assertThat(rules).isEmpty();
    }


    @Test
    public void testExhaustiveOptionalImplication1() {
        Rule r0a = testBuilder.defineRule("rule ra0 := clause [?x : int] ?x mod 2 = 0 => Aa(?x);");
        Rule r0b = testBuilder.defineRule("rule rb0 := clause [?x : int] ?x > 0 => Bb(?x);");
        Rule r1 = testBuilder.defineRule("rule r1 := clause [?x : int] Aa(?x) => Cc(?x);");
        Rule r2 = testBuilder.defineRule("rule r2 := clause [?x : int] Bb(?x) => Cc(?x);");
        Rule q = testBuilder.defineQuery("query q [?x : int] Cc(?x), ?x = 4;");

        RenameFreeVariablesRuleVisitor renameFreeVariablesRuleVisitor = new RenameFreeVariablesRuleVisitor();
        List<Rule> rules = Stream.of(r0a, r0b, r1, r2, q).map(r -> r.accept(renameFreeVariablesRuleVisitor)).collect(Collectors.toList());

        rules.forEach(r -> System.out.println(r.accept(new SExpressionRuleVisitor())));

        rules = MediumStepTransformer.foldToMediumStepsWithMagic(rules, PruneStrategy.Enum.none.strategy, PredicateInliningStrategy.Enum.exhaustive.strategy);

        assertThat(rules).hasSize(2);
        assertThat(rules).allSatisfy(r -> {
            assertThat(r.clauses).hasSize(1);
            assertThat(r.clauses.get(0).premises).hasSize(1);
            assertThat(r.clauses.get(0).premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p -> assertThat(p.expression).isEqualTo(Expression.BoolConst.TRUE));
            assertThat(r.clauses.get(0).conclusion.predicate.name).isEqualTo("q");
        });
    }

    @Test
    public void testExhaustiveOptionalImplication2() {
        Rule r0a = testBuilder.defineRule("rule ra0 := clause [?x : int] ?x mod 2 = 0 => Aa(?x);");
        Rule r0b = testBuilder.defineRule("rule rb0 := clause [?x : int] ?x > 0 => Bb(?x);");
        Rule r1 = testBuilder.defineRule("rule r1 := clause [?x : int] Aa(?x) => Cc(?x);");
        Rule r2 = testBuilder.defineRule("rule r2 := clause [?x : int] Bb(?x) => Cc(?x);");
        Rule q = testBuilder.defineQuery("query q [?x : int] Cc(?x), ?x = 3;");

        RenameFreeVariablesRuleVisitor renameFreeVariablesRuleVisitor = new RenameFreeVariablesRuleVisitor();
        List<Rule> rules = Stream.of(r0a, r0b, r1, r2, q).map(r -> r.accept(renameFreeVariablesRuleVisitor)).collect(Collectors.toList());

        rules.forEach(r -> System.out.println(r.accept(new SExpressionRuleVisitor())));

        rules = MediumStepTransformer.foldToMediumStepsWithMagic(rules, PruneStrategy.Enum.none.strategy, PredicateInliningStrategy.Enum.exhaustive.strategy);

        assertThat(rules).hasSize(1);
        assertThat(rules).allSatisfy(r -> {
            assertThat(r.clauses).hasSize(1);
            assertThat(r.clauses.get(0).premises).hasSize(1);
            assertThat(r.clauses.get(0).premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p -> assertThat(p.expression).isEqualTo(Expression.BoolConst.TRUE));
            assertThat(r.clauses.get(0).conclusion.predicate.name).isEqualTo("q");
        });
    }


    @Test
    public void testOneMandatoryPredicateUnreachableMakesQueryUnreachable() {
        Rule r0a = testBuilder.defineRule("rule ra0 := clause [?x : int] ?x mod 2 = 0 => Aa(?x);");
        Rule r0b = testBuilder.defineRule("rule rb0 := clause [?x : int] false => Bb(?x);");
        Rule r1 = testBuilder.defineRule("rule r1 := clause [?x : int] Aa(?x), Bb(?x) => Cc(?x);");
        Rule r2 = testBuilder.defineRule("rule r2 := clause [?x : int] Bb(?x) => Cc(?x);");
        Rule r3 = testBuilder.defineRule("rule r3 := clause [?x : int] Cc(?x) => Dd(?x);");
        Rule q = testBuilder.defineQuery("query q [?x : int] Cc(?x);");

        RenameFreeVariablesRuleVisitor renameFreeVariablesRuleVisitor = new RenameFreeVariablesRuleVisitor();
        List<Rule> rules = Stream.of(r0a, r0b, r1, r2, r3, q).map(r -> r.accept(renameFreeVariablesRuleVisitor)).collect(Collectors.toList());

        rules = MediumStepTransformer.foldToMediumStepsWithMagic(rules, PruneStrategy.Enum.none.strategy, PredicateInliningStrategy.Enum.linearExhaustive.strategy);

        assertThat(rules).isEmpty();
    }

    @Test
    public void testSamePredicateImpliedInDifferentPaths() {
        Rule r0 = testBuilder.defineRule("rule r0 := clause [?x : int] Dd(?x) => Aa(?x);");
        Rule r1 = testBuilder.defineRule("rule r1 := clause [?x : int, ?y : int] Aa(?x), ?y = ?x + 3 => Bb(?y);");
        Rule r2 = testBuilder.defineRule("rule r2 := clause [?x : int, ?y : int, ?z : int] Aa(?x), Bb(?y), ?y = ?x + 5, ?z = ?y + ?x + 2 => Cc(?z);");
        Rule q = testBuilder.defineQuery("query q [?x : int] Cc(?x);");

        List<Rule> rules = Arrays.asList(r0, r1, r2, q);

        PredicateInliningStrategy predicateInliningStrategy = new PredicateInliningStrategy.ExplicitEnumerationInliningStrategy(
                Arrays.asList(
                        r0.clauses.get(0).conclusion.predicate,
                        r1.clauses.get(0).conclusion.predicate,
                        r2.clauses.get(0).conclusion.predicate
                ));

        rules = MediumStepTransformer.foldToMediumStepsWithMagic(rules, PruneStrategy.Enum.none.strategy, predicateInliningStrategy);
        rules.forEach(r -> System.out.println(r.accept(new SExpressionRuleVisitor())));

        assertThat(rules).hasSize(1);
        assertThat(rules.get(0).clauses).hasSize(1);
        assertThat(rules.get(0).clauses.get(0).premises).anySatisfy(pp -> assertThat(pp).isInstanceOfSatisfying(Proposition.PredicateProposition.class, p -> assertThat(p.predicate.name).isEqualTo("Dd")));
        assertThat(rules.get(0).clauses.get(0).premises).anySatisfy(pp -> assertThat(pp).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p -> assertThat(p.expression).isInstanceOfSatisfying(Expression.ComparisonExpression.class, ce -> {
            assertThat(ce.operation).isEqualTo(Expression.CompOperation.EQ);
            assertThat(ce.expression1).isInstanceOf(Expression.BinaryIntExpression.class);
            assertThat(ce.expression2).isInstanceOf(Expression.BinaryIntExpression.class);
        })));
        assertThat(rules.get(0).clauses.get(0).conclusion.predicate.name).isEqualTo("q");

    }
}