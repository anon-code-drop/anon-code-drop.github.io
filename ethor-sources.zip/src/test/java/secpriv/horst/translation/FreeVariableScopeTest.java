package secpriv.horst.translation;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class FreeVariableScopeTest {
    private FreeVariableScope scope;

    @BeforeEach
    public void setUp() {
        scope = new FreeVariableScope();
    }

    @AfterEach
    public void tearDown() {
        scope = null;
    }

    @Test
    public void testAddScope1() {
        String variableName = "?a";
        String scopedVariableName = scope.addOrReplaceScope(variableName);

        assertThat(scopedVariableName).matches("\\?a\\[\\d+;\\d+\\]");
    }

    @Test
    public void testAddScope2() {
        String variableName = "?a";
        String scopedVariableName1 = scope.addOrReplaceScope(variableName);
        String scopedVariableName2 = scope.addOrReplaceScope(variableName);

        assertThat(scopedVariableName1).matches("\\?a\\[\\d+;\\d+\\]");
        assertThat(scopedVariableName1).isEqualTo(scopedVariableName2);
    }

    @Test
    public void testAddScope3() {
        String variableName = "?a";
        FreeVariableScope scope1 = new FreeVariableScope();
        FreeVariableScope scope2 = new FreeVariableScope();
        String scopedVariableName1 = scope1.addOrReplaceScope(variableName);
        String scopedVariableName2 = scope2.addOrReplaceScope(variableName);

        assertThat(scopedVariableName1).matches("\\?a\\[\\d+;\\d+\\]");
        assertThat(scopedVariableName2).matches("\\?a\\[\\d+;\\d+\\]");
        assertThat(scopedVariableName1).isNotEqualTo(scopedVariableName2);
    }

    @Test
    public void testReplaceScope1() {
        String oldScopedVariableName = "?a[10;0]";
        String scopedVariableName = scope.addOrReplaceScope(oldScopedVariableName);

        assertThat(scopedVariableName).isNotEqualTo(oldScopedVariableName);
        assertThat(scopedVariableName).matches("\\?a\\[\\d+;\\d+\\]");
    }

    @Test
    public void testReplaceScope2() {
        String oldScopedVariableName = "?a[8;0]";
        String scopedVariableName1 = scope.addOrReplaceScope(oldScopedVariableName);
        String scopedVariableName2 = scope.addOrReplaceScope(oldScopedVariableName);

        assertThat(scopedVariableName1).isNotEqualTo(oldScopedVariableName);
        assertThat(scopedVariableName2).isNotEqualTo(oldScopedVariableName);
        assertThat(scopedVariableName1).matches("\\?a\\[\\d+;\\d+\\]");
        assertThat(scopedVariableName1).isEqualTo(scopedVariableName2);
    }

    @Test
    public void testReplaceScope3() {
        String oldScopedVariableName = "?a[7;1]";
        FreeVariableScope scope1 = new FreeVariableScope();
        FreeVariableScope scope2 = new FreeVariableScope();
        String scopedVariableName1 = scope1.addOrReplaceScope(oldScopedVariableName);
        String scopedVariableName2 = scope2.addOrReplaceScope(oldScopedVariableName);

        assertThat(scopedVariableName1).isNotEqualTo(oldScopedVariableName);
        assertThat(scopedVariableName2).isNotEqualTo(oldScopedVariableName);
        assertThat(scopedVariableName1).matches("\\?a\\[\\d+;\\d+\\]");
        assertThat(scopedVariableName2).matches("\\?a\\[\\d+;\\d+\\]");
        assertThat(scopedVariableName1).isNotEqualTo(scopedVariableName2);
    }
}