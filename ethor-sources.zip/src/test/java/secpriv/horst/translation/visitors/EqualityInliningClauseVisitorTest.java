package secpriv.horst.translation.visitors;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import secpriv.horst.data.*;
import secpriv.horst.internals.error.handling.ExceptionThrowingErrorHandler;
import secpriv.horst.tools.TestBuilder;
import secpriv.horst.tools.TestRuleTypeOracle;
import secpriv.horst.translation.MediumStepTransformer;
import secpriv.horst.translation.PredicateInliningStrategy;
import secpriv.horst.translation.PruneStrategy;
import secpriv.horst.types.Type;
import secpriv.horst.visitors.SExpressionClauseVisitor;
import secpriv.horst.visitors.SExpressionRuleVisitor;
import secpriv.horst.visitors.VisitorState;

import java.math.BigInteger;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class EqualityInliningClauseVisitorTest {
    private TestBuilder testBuilder;
    private EqualityInliningClauseVisitor clauseVisitor;
    private Predicate ccPredicate;

    @BeforeEach
    public void setUp() {
        VisitorState state = new VisitorState();
        state.errorHandler = new ExceptionThrowingErrorHandler();
        testBuilder = new TestBuilder(state);
        testBuilder.definePredicate("pred Aa{}: int;");
        testBuilder.definePredicate("pred Bb{}: int;");
        ccPredicate = testBuilder.definePredicate("pred Cc{}: bool;");
        clauseVisitor = new EqualityInliningClauseVisitor();
    }

    @AfterEach
    public void tearDown() {
        testBuilder = null;
        ccPredicate = null;
        clauseVisitor = null;
    }

    @Test
    public void test1() {
        Rule r1 = testBuilder.defineRule("rule r := clause [?a: int, ?b: int, ?c:int] Bb(?a), ?a = ?b, ?c = ?b, ?a = 10 => Aa(?c);");

        Clause clause = r1.clauses.get(0).accept(clauseVisitor);

        assertThat(clause.premises).hasSize(2);
        assertThat(clause.freeVars).hasSize(1);
        assertThat(clause.conclusion.arguments.get(0)).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f ->
                assertThat(clause.freeVars).containsEntry(f.name, f.type)
        );
        assertThat(clause.premises.get(0)).isInstanceOfSatisfying(Proposition.PredicateProposition.class, p -> {
                    assertThat(p.arguments).hasSize(1);
//                    assertThat(p.arguments.get(0)).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
                }
        );
        assertThat(clause.premises.get(1)).isInstanceOfSatisfying(
                Proposition.ExpressionProposition.class, p ->
                        assertThat(p.expression).isInstanceOfSatisfying(
                                Expression.ComparisonExpression.class, c -> {
                                    assertThat(c.operation).isEqualTo(Expression.CompOperation.EQ);
//                                    assertThat(c.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
                                    assertThat(c.expression2).isEqualTo(new Expression.IntConst(BigInteger.TEN));
                                }));

    }


    @Test
    public void test2() {
        Rule r1 = testBuilder.defineRule("rule r := clause [?a: int, ?b: int, ?c:int] Bb(?a), ?a = 10, ?a = ?b, ?c = ?b  => Aa(?c);");

        Clause clause = r1.clauses.get(0).accept(clauseVisitor);

        System.out.println(clause.accept(new SExpressionClauseVisitor(0)));


        assertThat(clause.freeVars).hasSize(1);
        assertThat(clause.conclusion.arguments.get(0)).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f ->
                assertThat(clause.freeVars).containsEntry(f.name, f.type)
        );

        Expression.FreeVarExpression freevar = clause.freeVars.entrySet().stream().findAny().map(e -> new Expression.FreeVarExpression(e.getValue(), e.getKey())).get();

        assertThat(clause.premises).hasSize(2);
        assertThat(clause.premises).anySatisfy(pp -> assertThat(pp).isInstanceOfSatisfying(Proposition.PredicateProposition.class, p -> {
                    assertThat(p.arguments).hasSize(1);
                    assertThat(p.arguments.get(0)).isEqualTo(freevar);
                }
        ));
        assertThat(clause.premises).anySatisfy(pp -> assertThat(pp).isInstanceOfSatisfying(
                Proposition.ExpressionProposition.class, p ->
                        assertThat(p.expression).isInstanceOfSatisfying(
                                Expression.ComparisonExpression.class, c -> {
                                    assertThat(c.operation).isEqualTo(Expression.CompOperation.EQ);
                                    assertThat(c.expression1).isEqualTo((freevar));
                                    assertThat(c.expression2).isEqualTo(new Expression.IntConst(BigInteger.TEN));
                                })));
    }

    @Test
    public void testDisagreeingIntegerEqualities1() {
        Rule r1 = testBuilder.defineRule("rule r := clause [?a: int, ?b: int, ?c:int] Bb(?a), ?b = 10, ?b = 11 => Aa(?c);");

        Clause clause = r1.clauses.get(0).accept(clauseVisitor);

        System.out.println(clause.accept(new SExpressionClauseVisitor(0)));


        assertThat(clause.premises).hasSize(1);
        assertThat(clause.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, e ->
                assertThat(e.expression).isEqualTo(Expression.BoolConst.FALSE)
        );
    }


    @Disabled("disabled until array level equalities are considered for propagation")
    @Test
    public void testDisagreeingIntegerEqualities2() {
        Rule r1 = testBuilder.defineRule("rule r := clause [?a: array<int>, ?b: int, ?c:int] Bb(?b), ?c = 8, (select ?a ?b) = 10, (select ?a ?b) = 11 => Aa(?c);");

        Clause clause = r1.clauses.get(0).accept(clauseVisitor);

        assertThat(clause.premises).hasSize(1);
        assertThat(clause.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, e ->
                assertThat(e.expression).isEqualTo(Expression.BoolConst.FALSE)
        );
    }

    @Test
    public void testDisagreeingBooleanEqualities1() {
        Rule r1 = testBuilder.defineRule("rule r := clause [?a: int, ?b: bool, ?c:int] Bb(?a), ?b = true, ?b = false => Aa(?c);");

        Clause clause = r1.clauses.get(0).accept(clauseVisitor);

        assertThat(clause.premises).hasSize(1);
        assertThat(clause.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, e ->
                assertThat(e.expression).isEqualTo(Expression.BoolConst.FALSE)
        );
    }

    @Test
    public void testDisagreeingBooleanEqualities2() {
        Rule r1 = testBuilder.defineRule("rule r := clause [?a: int, ?b: bool, ?c:int] Bb(?a), ?b, ~?b, ?c = 10 => Aa(?c);");

        Clause clause = r1.clauses.get(0).accept(clauseVisitor);

        System.out.println(clause.accept(new SExpressionClauseVisitor(0)));

        assertThat(clause.premises).hasSize(1);
        assertThat(clause.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, e ->
                assertThat(e.expression).isEqualTo(Expression.BoolConst.FALSE)
        );
    }


    @Test
    public void testDisagreeingBooleanEqualities3() {
        Rule r1 = testBuilder.defineRule("rule r := clause [?a: int, ?b: bool, ?c:int] Bb(?a), ?b && ~?b, ?c = 10 => Aa(?c);");

        Clause clause = r1.clauses.get(0).accept(clauseVisitor);

        System.out.println(clause.accept(new SExpressionClauseVisitor(0)));

        assertThat(clause.premises).hasSize(1);
        assertThat(clause.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, e ->
                assertThat(e.expression).isEqualTo(Expression.BoolConst.FALSE)
        );
    }

    @Test
    public void test5() {
        Rule r1 = testBuilder.defineRule("rule r := clause [?a: int, ?b: int, ?c: int, ?d: int] Bb(?a), ?b = 10, ?d = 11, ?c = ?b + ?d => Aa(?c);");

        Clause clause = r1.clauses.get(0).accept(clauseVisitor);

        assertThat(clause.premises).hasSize(2);
        assertThat(clause.premises.get(0)).isInstanceOfSatisfying(Proposition.PredicateProposition.class, p ->
                assertThat(p.predicate.name).isEqualTo("Bb")
        );
        assertThat(clause.premises.get(1)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, e ->
                assertThat(e.expression).isInstanceOfSatisfying(Expression.ComparisonExpression.class, c -> {
                    assertThat(c.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?c"));
                    assertThat(c.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(21)));
                }));

    }

    @Test
    public void testRedundantBooleanFreeVarsGetSimplified() {
        Rule r1 = testBuilder.defineRule("rule r := clause [?a: int, ?b: bool] Bb(?a), ?b, ?b, ?b => Cc(?b);");

        Clause clause = r1.clauses.get(0).accept(clauseVisitor);

        assertThat(clause.premises).hasSize(2);
        assertThat(clause.premises.get(0)).isInstanceOfSatisfying(Proposition.PredicateProposition.class, p ->
                assertThat(p.predicate.name).isEqualTo("Bb")
        );
        assertThat(clause.premises.get(1)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, e ->
                assertThat(e.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> {
                    assertThat(f).isEqualTo(new Expression.FreeVarExpression(Type.Boolean, "?b"));
                }));

    }

    @Test
    public void test6() {
        Rule r1 = testBuilder.defineRule("rule r := clause [?a: int, ?b: int, ?c: int, ?d: int, ?e : array<int>] Bb(?a), ?b = 10, ?d = 11, ?c = (select ?e (?d -1)), ?e = (store [3] ?b 5) => Aa(?c);");

        Clause clause = r1.clauses.get(0).accept(clauseVisitor);

        System.out.println(clause.accept(new SExpressionClauseVisitor(0)));

        assertThat(clause.premises).hasSize(2);
        assertThat(clause.premises.get(0)).isInstanceOfSatisfying(Proposition.PredicateProposition.class, p ->
                assertThat(p.predicate.name).isEqualTo("Bb")
        );
        assertThat(clause.premises.get(1)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, e ->
                assertThat(e.expression).isInstanceOfSatisfying(Expression.ComparisonExpression.class, c -> {
                    assertThat(c.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?c"));
                    assertThat(c.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(5)));
                }));

    }

    @Test
    public void testConstraintsOnPremiseParameterGetInlined() {
        Rule r1 = testBuilder.defineRule("rule r := clause [?a: int, ?b: int, ?c: int, ?d: int, ?e : array<int>] Bb(?a), ?a = 10, ?d = 11, ?c = (select ?e (?d -1)), ?e = (store [3] ?a 8) => Aa(?c);");

        Clause clause = r1.clauses.get(0).accept(clauseVisitor);

        System.out.println(clause.accept(new SExpressionClauseVisitor(0)));

        assertThat(clause.premises).anySatisfy(pp ->
                assertThat(pp).isInstanceOfSatisfying(Proposition.PredicateProposition.class, p ->
                        assertThat(p.predicate.name).isEqualTo("Bb")
                ));
        assertThat(clause.premises).anySatisfy(pp ->
                assertThat(pp).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, e ->
                        assertThat(e.expression).isInstanceOfSatisfying(Expression.ComparisonExpression.class, c -> {
//                            assertThat(c.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
                            assertThat(c.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(10)));
                        })));
        assertThat(clause.premises).anySatisfy(pp ->
                assertThat(pp).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, e ->
                        assertThat(e.expression).isInstanceOfSatisfying(Expression.ComparisonExpression.class, c -> {
//                            assertThat(c.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?c"));
                            assertThat(c.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(8)));
                        })));
        assertThat(clause.premises).noneSatisfy(pp ->
                assertThat(pp).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, e ->
                        assertThat(e.expression).isInstanceOfSatisfying(Expression.ComparisonExpression.class, c ->
                                assertThat(c.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f ->
                                        assertThat(f.name).isEqualTo("?d")))));


        assertThat(clause.premises).hasSize(3);
    }

    @Test
    public void testConstraintOnPremiseParameterDoesNotGetDeleted() {
        Rule r1 = testBuilder.defineRule("rule r := clause [?a: int, ?b: int] Bb(?a), ?a = 10, ?b = 15 => Aa(?b);");

        Clause clause = r1.clauses.get(0).accept(clauseVisitor);

        assertThat(clause.premises).hasSize(3);
        assertThat(clause.premises).anySatisfy(pp ->
                assertThat(pp).isInstanceOfSatisfying(Proposition.PredicateProposition.class, p ->
                        assertThat(p.predicate.name).isEqualTo("Bb")
                ));
        assertThat(clause.premises).anySatisfy(p ->
                assertThat(p).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, e ->
                        assertThat(e.expression).isInstanceOfSatisfying(Expression.ComparisonExpression.class, c -> {
//                            assertThat(c.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
                            assertThat(c.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(10)));
                        })));
        assertThat(clause.premises).anySatisfy(p ->
                assertThat(p).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, e ->
                        assertThat(e.expression).isInstanceOfSatisfying(Expression.ComparisonExpression.class, c -> {
//                            assertThat(c.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?b"));
                            assertThat(c.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(15)));
                        })));
    }


    @Test
    public void testNonSimpleEqualityPropositionsArgumentsGetInlined() {
        Rule r1 = testBuilder.defineRule("rule r := clause [?a: int, ?b: int, ?c: int] Bb(?a), ?a = 10, ?b = 15, ?c > ?a+?b => Aa(?b);");

        Clause clause = r1.clauses.get(0).accept(clauseVisitor);

        assertThat(clause.premises).hasSize(4);
        assertThat(clause.premises.get(0)).isInstanceOfSatisfying(Proposition.PredicateProposition.class, p ->
                assertThat(p.predicate.name).isEqualTo("Bb")
        );

        assertThat(clause.premises).anySatisfy(pp ->
                assertThat(pp).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, e ->
                        assertThat(e.expression).isInstanceOfSatisfying(Expression.ComparisonExpression.class, c -> {
                            assertThat(c.operation).isEqualTo(Expression.CompOperation.GT);
                            assertThat(c.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?c"));
                            assertThat(c.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(25)));
                        })));
        assertThat(clause.premises).anySatisfy(pp ->
                assertThat(pp).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, e ->
                        assertThat(e.expression).isInstanceOfSatisfying(Expression.ComparisonExpression.class, c -> {
                            assertThat(c.operation).isEqualTo(Expression.CompOperation.EQ);
                            assertThat(c.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
                            assertThat(c.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(10)));
                        })));
        assertThat(clause.premises).anySatisfy(pp ->
                assertThat(pp).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, e ->
                        assertThat(e.expression).isInstanceOfSatisfying(Expression.ComparisonExpression.class, c -> {
                            assertThat(c.operation).isEqualTo(Expression.CompOperation.EQ);
                            assertThat(c.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?b"));
                            assertThat(c.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(15)));
                        })));
    }

    @Test
    public void testCyclicInline() {
        Rule r1 = testBuilder.defineRule("rule r := clause [?a:int, ?b:int] Bb(?a), ?a = ?b +1, ?b = ?a +1 => Aa(?b);");

        assertThatThrownBy(() -> r1.clauses.get(0).accept(clauseVisitor)).isInstanceOf(RuntimeException.class);
    }


    @Test
    public void testConstantFoldingVariableDeletion() {
        Rule r1 = testBuilder.defineRule("rule r := clause [?a:int, ?b:int, ?c:int, ?d:int] Bb(?a), Bb(?d), ?b = (?a = 0) ? (2) : (?d), ?c = ?b * 0 => Aa(?c);");

        Clause clause = r1.clauses.get(0).accept(clauseVisitor);

        System.out.println(clause.accept(new SExpressionClauseVisitor(0)));

        assertThat(clause.premises).anySatisfy(pp ->
                assertThat(pp).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, e ->
                        assertThat(e.expression).isInstanceOfSatisfying(Expression.ComparisonExpression.class, c -> {
                            assertThat(c.operation).isEqualTo(Expression.CompOperation.EQ);
//                            assertThat(c.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?c"));
                            assertThat(c.expression2).isEqualTo(new Expression.IntConst(BigInteger.ZERO));
                        })));

        assertThat(clause.premises).noneSatisfy(pp ->
                assertThat(pp).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, e ->
                        assertThat(e.expression).isInstanceOfSatisfying(Expression.ComparisonExpression.class, c -> {
                            assertThat(c.operation).isEqualTo(Expression.CompOperation.EQ);
                            assertThat(c.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?b"));
                        })));


        assertThat(clause.freeVars).doesNotContainKey("?b");
    }

    @Test
    public void testIncompatibleStoresDoesNotGetInlinedInSelect() {
        Predicate p1 = testBuilder.definePredicate("pred Aaa{}: array<int>*int;");
        Predicate p2 = testBuilder.definePredicate("pred Bbb{}: array<int>*int*int;");
        Rule r1 = testBuilder.defineRule("rule r := clause [?a:int, ?b:int, ?ai:array<int>, ?bi:array<int>, ?d:int] Bbb(?ai, ?a, ?b), ?bi = store ?ai ?a 15, ?d = select ?bi ?b => Aaa(?ai, ?d);");

        Clause clause = r1.clauses.get(0).accept(clauseVisitor);

        assertThat(clause.premises).hasSize(3);

        //TODO extend
    }

    @Test
    public void testCompatibleStoresDoesGetInlinedInSelect() {
        Predicate p1 = testBuilder.definePredicate("pred Aaa{}: array<int>*int;");
        Predicate p2 = testBuilder.definePredicate("pred Bbb{}: array<int>*int*int;");
        Rule r1 = testBuilder.defineRule("rule r := clause [?a:int, ?ai:array<int>, ?bi:array<int>, ?d:int] Bbb(?ai, ?a, ?a), ?bi = store ?ai ?a 15, ?d = select ?bi ?a => Aaa(?ai, ?d);");

        Clause clause = r1.clauses.get(0).accept(clauseVisitor);

        assertThat(clause.premises).hasSize(2);
    }

    @Disabled("disable until init clauses are introduced. also nothing useful is queried.")
    @Test
    public void testDisagreeingPushesUsableMaybe() {
        Predicate aaaPredicate = testBuilder.definePredicate("pred Aaa{}: array<int>;");
        Predicate p2 = testBuilder.definePredicate("pred Bbb{}: array<int>;");
        Predicate p3 = testBuilder.definePredicate("pred Ccc{}: array<int>;");
        Rule r1 = testBuilder.defineRule("rule r := clause [?a: array<int>, ?b: array<int>] Ccc(?a), ?b = store ?a 1 3 => Bbb(?b);");
        Rule r2 = testBuilder.defineRule("rule q := clause [?a: array<int>, ?b: array<int>] Bbb(?a), ?b = store ?a 1 5, (select ?a 1) = 8 => Aaa(?b);");

        RenameFreeVariablesRuleVisitor renameVisitor = new RenameFreeVariablesRuleVisitor();
        List<Rule> rules = Stream.of(r2, r1).map(r -> r.accept(renameVisitor)).collect(Collectors.toList());


        List<Rule> foldedRules = MediumStepTransformer.foldToMediumStepsWithMagic(rules, new TestRuleTypeOracle(Collections.singleton(aaaPredicate)), new PruneStrategy.NonePruneStrategy(), new PredicateInliningStrategy.LinearInliningStrategy());

        foldedRules.forEach(r -> System.out.println(r.accept(new SExpressionRuleVisitor())));
    }

    @Disabled("disable until init clauses are introduced")
    @Test
    public void testDisagreeingPushes() {
        Predicate p0 = testBuilder.definePredicate("pred Ooo{}: array<int>;");
        Predicate p1 = testBuilder.definePredicate("pred Aaa{}: array<int>;");
        Predicate p2 = testBuilder.definePredicate("pred Bbb{}: array<int>;");
        Predicate p3 = testBuilder.definePredicate("pred Ccc{}: array<int>;");
        Predicate p4 = testBuilder.definePredicate("pred Ddd{}: array<int>;");
        Predicate p5 = testBuilder.definePredicate("pred Eee{}: array<int>;");
        Predicate qqqPredicate = testBuilder.definePredicate("pred Qqq{}: array<int>;");
        Rule r01 = testBuilder.defineRule("rule start1 := clause [?a: array<int>, ?b: array<int>] Ooo(?a) => Aaa(?a);");
        Rule r02 = testBuilder.defineRule("rule start2 := clause [?a: array<int>, ?b: array<int>] Ooo(?a) => Bbb(?a);");
        Rule r1 = testBuilder.defineRule("rule r := clause [?a: array<int>, ?b: array<int>] Aaa(?a), ?b = store ?a 1 3 => Ccc(?b);");
        Rule r2 = testBuilder.defineRule("rule p := clause [?a: array<int>, ?b: array<int>] Bbb(?a), ?b = store ?a 1 5 => Ccc(?b);");
        Rule r3 = testBuilder.defineRule("rule q := clause [?a: array<int>] Ccc(?a), (select ?a 1) = 3 => Ddd(?a);");
        Rule r4 = testBuilder.defineRule("rule s := clause [?a: array<int>] Ccc(?a), (select ?a 1) = 5 => Eee(?a);");
        Rule r5 = testBuilder.defineRule("rule q1 := clause [?a: array<int>] Ddd(?a) => Qqq(?a);");
        Rule r6 = testBuilder.defineRule("rule q2 := clause [?a: array<int>] Eee(?a) => Qqq(?a);");

        RenameFreeVariablesRuleVisitor renameVisitor = new RenameFreeVariablesRuleVisitor();
        List<Rule> rules = Stream.of(r01, r02, r1, r2, r3, r4, r5, r6).map(r -> r.accept(renameVisitor)).collect(Collectors.toList());


        List<Rule> foldedRules = MediumStepTransformer.foldToMediumStepsWithMagic(rules, new TestRuleTypeOracle(Collections.singleton(qqqPredicate)), new PruneStrategy.NonePruneStrategy(), new PredicateInliningStrategy.ExhaustiveInliningStrategy());

        foldedRules.forEach(r -> System.out.println(r.accept(new SExpressionRuleVisitor())));

        assertThat(foldedRules).hasSize(2);

        assertThat(foldedRules).anySatisfy(r -> {
            assertThat(r.clauses).hasSize(1);
            assertThat(r.clauses.get(0)).satisfies(clause -> {
                assertThat(clause.conclusion.predicate.name).isEqualTo("Qqq");
                assertThat(clause.conclusion.arguments).hasSize(1);
                assertThat(clause.conclusion.arguments.get(0)).isInstanceOfSatisfying(Expression.FreeVarExpression.class, fv -> {
                    assertThat(fv.type).isEqualTo(Type.Array.of(Type.Integer));
                });
                assertThat(clause.premises).hasSize(2);
                assertThat(clause.premises).anySatisfy(p ->
                        assertThat(p).isInstanceOfSatisfying(Proposition.PredicateProposition.class, pp -> {
                            assertThat(pp.predicate.name).isEqualTo("Ooo");
                        }));
                assertThat(clause.premises).anySatisfy(p ->
                        assertThat(p).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, ep -> {
                            assertThat(ep.expression).isInstanceOfSatisfying(Expression.ComparisonExpression.class, ce -> {
                                assertThat(ce.expression1).isInstanceOf(Expression.FreeVarExpression.class);
                                assertThat(ce.expression2).isInstanceOfSatisfying(Expression.StoreExpression.class, se -> {
                                    assertThat(se.expression1).isInstanceOf(Expression.FreeVarExpression.class);
                                    assertThat(se.expression2).isEqualTo(new Expression.IntConst(BigInteger.ONE));
                                    assertThat(se.expression3).isEqualTo(new Expression.IntConst(BigInteger.valueOf(5)));
                                });
                            });
                        }));
            });
        });

        assertThat(foldedRules).anySatisfy(r -> {
            assertThat(r.clauses).hasSize(1);
            assertThat(r.clauses.get(0)).satisfies(clause -> {
                assertThat(clause.conclusion.predicate.name).isEqualTo("Qqq");
                assertThat(clause.conclusion.arguments).hasSize(1);
                assertThat(clause.conclusion.arguments.get(0)).isInstanceOfSatisfying(Expression.FreeVarExpression.class, fv -> {
                    assertThat(fv.type).isEqualTo(Type.Array.of(Type.Integer));
                });
                assertThat(clause.premises).hasSize(2);
                assertThat(clause.premises).anySatisfy(p ->
                        assertThat(p).isInstanceOfSatisfying(Proposition.PredicateProposition.class, pp -> {
                            assertThat(pp.predicate.name).isEqualTo("Ooo");
                        }));
                assertThat(clause.premises).anySatisfy(p ->
                        assertThat(p).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, ep -> {
                            assertThat(ep.expression).isInstanceOfSatisfying(Expression.ComparisonExpression.class, ce -> {
                                assertThat(ce.expression1).isInstanceOf(Expression.FreeVarExpression.class);
                                assertThat(ce.expression2).isInstanceOfSatisfying(Expression.StoreExpression.class, se -> {
                                    assertThat(se.expression1).isInstanceOf(Expression.FreeVarExpression.class);
                                    assertThat(se.expression2).isEqualTo(new Expression.IntConst(BigInteger.ONE));
                                    assertThat(se.expression3).isEqualTo(new Expression.IntConst(BigInteger.valueOf(3)));
                                });
                            });
                        }));
            });
        });

        assertThat(foldedRules).allSatisfy(r -> assertThat(r.clauses.get(0).freeVars).hasSize(2));
    }

    @Disabled("ignore until model of query has changed. also nothing sensible is queried")
    @Test
    public void testMultipleFreeVarsSimple() {
        Predicate qqPredicate = testBuilder.definePredicate("pred Qq{}: int*bool;");
        Rule r1 = testBuilder.defineRule("rule r := clause [?a: int, ?b: int] Aa(?a), ?b = 3, ?b = ?a => Bb(?b);");
        Rule r2 = testBuilder.defineRule("rule p := clause [?a: int, ?e: bool] Bb(?a),?e = (?a = 3) => Qq(?a, ?e);");

        RenameFreeVariablesRuleVisitor renameVisitor = new RenameFreeVariablesRuleVisitor();
        List<Rule> rules = Stream.of(r1, r2).map(r -> r.accept(renameVisitor)).collect(Collectors.toList());


        List<Rule> foldedRules = MediumStepTransformer.foldToMediumStepsWithMagic(rules, new TestRuleTypeOracle(Collections.singleton(qqPredicate)), new PruneStrategy.NonePruneStrategy(), new PredicateInliningStrategy.LinearInliningStrategy());

        foldedRules.forEach(r -> System.out.println(r.accept(new SExpressionRuleVisitor())));
    }

    @Disabled("ignore until model of query has changed")
    @Test
    public void testUnfoldAnd() {
        testBuilder.definePredicate("pred Dd{}: int;");

        Rule r1 = testBuilder.defineRule("rule r := clause [?a: int, ?b: int, ?bi : array<bool>] Aa(?a), ?b = 3, ~((select ?bi 1) && (select ?bi 2) && (select ?bi 3) && (select ?bi 4)) => Bb(?b);");
        Rule r2 = testBuilder.defineRule("rule p := clause [?a: int] Bb(?a) => Dd(?a);");
        Rule r3 = testBuilder.defineRule("rule q := clause [?a: int, ?e: bool] Dd(?a), ?e = (?a = 3) => Cc(?e);");

        RenameFreeVariablesRuleVisitor renameVisitor = new RenameFreeVariablesRuleVisitor();
        List<Rule> rules = Stream.of(r1, r2, r3).map(r -> r.accept(renameVisitor)).collect(Collectors.toList());

        List<Rule> foldedRules = MediumStepTransformer.foldToMediumStepsWithMagic(rules, new TestRuleTypeOracle(Collections.singleton(ccPredicate)), new PruneStrategy.NonePruneStrategy(), new PredicateInliningStrategy.LinearInliningStrategy());

        foldedRules.forEach(r -> System.out.println(r.accept(new SExpressionRuleVisitor())));

        assertThat(foldedRules).hasSize(2);
    }

    @Disabled("ignore until model of query has changed")
    @Test
    public void testMultipleFreeVars() {
        Predicate qqPredicate = testBuilder.definePredicate("pred Qq{}: int*bool;");
        Rule r1 = testBuilder.defineRule("rule r := clause [?a: int, ?b: int] Aa(?a), ?b = 3 => Bb(?b);");
        Rule r2 = testBuilder.defineRule("rule p := clause [?a: int, ?b: int, ?c: int, ?d:int, ?e: bool] Bb(?a), ?a = ?b, ?b = ?c, ?c = ?d, ?e = (?d = 3) => Qq(?d, ?e);");

        RenameFreeVariablesRuleVisitor renameVisitor = new RenameFreeVariablesRuleVisitor();
        List<Rule> rules = Stream.of(r2, r1).map(r -> r.accept(renameVisitor)).collect(Collectors.toList());

        List<Rule> foldedRules = MediumStepTransformer.foldToMediumStepsWithMagic(rules, new TestRuleTypeOracle(Collections.singleton(qqPredicate)), new PruneStrategy.NonePruneStrategy(), new PredicateInliningStrategy.LinearInliningStrategy());

        foldedRules.forEach(r -> System.out.println(r.accept(new SExpressionRuleVisitor())));

        assertThat(foldedRules).hasSize(1);
        assertThat(foldedRules.get(0).clauses).hasSize(1);
        Clause clause = foldedRules.get(0).clauses.get(0);

        assertThat(true).isFalse(); //Check for Variable propagation

        assertThat(clause.freeVars).hasSize(2);
        assertThat(clause.conclusion.arguments).hasSize(2);
        assertThat(clause.conclusion.arguments.get(0)).isInstanceOf(Expression.FreeVarExpression.class);
        assertThat(clause.conclusion.arguments.get(1)).isInstanceOf(Expression.FreeVarExpression.class);

        Expression.FreeVarExpression intFreeVar = (Expression.FreeVarExpression) clause.conclusion.arguments.get(0);
        Expression.FreeVarExpression boolFreeVar = (Expression.FreeVarExpression) clause.conclusion.arguments.get(1);

        assertThat(clause.premises).anySatisfy(pp -> {
            assertThat(pp).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p -> {
                assertThat(p.expression).isInstanceOfSatisfying(Expression.ComparisonExpression.class, c -> {
                    assertThat(c.expression1).isEqualTo(intFreeVar);
                    assertThat(c.expression2).isEqualTo(new Expression.IntConst(BigInteger.TEN));
                    assertThat(c.operation).isEqualTo(Expression.CompOperation.EQ);
                });
            });
        });

        assertThat(clause.premises).anySatisfy(pp -> {
            assertThat(pp).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p -> {
                assertThat(p.expression).isEqualTo(Expression.BoolConst.TRUE);
            });
        });

    }

    @Test
    public void testBoundPropagation() {
        testBuilder.definePredicate("pred Aaa{}: int;");
        testBuilder.definePredicate("pred Bbb{}: int;");
        testBuilder.definePredicate("pred Ccc{}: int;");
        Predicate dddPredicate = testBuilder.definePredicate("pred Ddd{}: int;");

        Rule r1 = testBuilder.defineRule("rule r1 := clause [?a: int] Aaa(?a), ?a > 0, ?a < 100 => Bbb(?a + 1);");
        Rule r2 = testBuilder.defineRule("rule r2 := clause [?a: int] Bbb(?a), ?a > 0, ?a < 100 => Ccc(?a + 1);");
        Rule r3 = testBuilder.defineRule("rule r3 := clause [?a: int] Ccc(?a), ?a > 0, ?a < 100 => Ddd(?a + 1);");

        RenameFreeVariablesRuleVisitor renameVisitor = new RenameFreeVariablesRuleVisitor();
        SimplifyPredicateArgumentsRuleVisitor simplifyPredicateArgumentsRuleVisitor = new SimplifyPredicateArgumentsRuleVisitor();
        List<Rule> rules = Stream.of(r1, r2, r3).map(r -> r.accept(simplifyPredicateArgumentsRuleVisitor).accept(renameVisitor)).collect(Collectors.toList());

        List<Rule> foldedRules = MediumStepTransformer.foldToMediumStepsWithMagic(rules, new TestRuleTypeOracle(Collections.singleton(dddPredicate)), new PruneStrategy.NonePruneStrategy(), new PredicateInliningStrategy.LinearInliningStrategy());


        //TODO actually test something
        //foldedRules.forEach(r -> System.out.println(r.accept(new SExpressionRuleVisitor())));
    }
}