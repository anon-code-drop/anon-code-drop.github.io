package secpriv.horst.translation.visitors;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import secpriv.horst.data.Clause;
import secpriv.horst.data.Expression;
import secpriv.horst.data.Predicate;
import secpriv.horst.data.Proposition;
import secpriv.horst.internals.SelectorFunctionHelper;
import secpriv.horst.internals.SelectorFunctionInvoker;
import secpriv.horst.tools.TestBuilder;
import secpriv.horst.types.Type;
import secpriv.horst.visitors.SExpressionExpressionVisitor;
import secpriv.horst.visitors.VisitorState;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.*;

class TransformToConjunctiveNormalFormClauseVisitorTest {

    private TransformToConjunctiveNormalFormClauseVisitor transformToConjunctiveNormalFormClauseVisitor;
    private VisitorState state;
    private TestBuilder testBuilder;

    private Proposition.PredicateProposition conclusion;

    @BeforeEach
    void setUp() {
        transformToConjunctiveNormalFormClauseVisitor = new TransformToConjunctiveNormalFormClauseVisitor();
        state = new VisitorState();
        testBuilder = new TestBuilder(state);

        state.defineFreeVar("?a", Type.Boolean);
        state.defineFreeVar("?b", Type.Boolean);
        state.defineFreeVar("?c", Type.Boolean);
        state.defineFreeVar("?d", Type.Boolean);
        state.defineFreeVar("?e", Type.Boolean);
        state.defineFreeVar("?m", Type.Integer);
        state.defineFreeVar("?n", Type.Integer);
        state.defineFreeVar("?o", Type.Integer);
        state.defineFreeVar("?p", Type.Integer);


        Predicate predicate = Predicate.newPredicate("Abc", Collections.emptyList(), Collections.singletonList(Type.Boolean));
        conclusion = new Proposition.PredicateProposition(predicate, Collections.emptyList(), Collections.emptyList());

    }

    @AfterEach
    void tearDown() {
        transformToConjunctiveNormalFormClauseVisitor = null;
        state = null;
        testBuilder = null;
    }


    @Test
    void transform1varTautology() {
        // a || ~a = TRUE
        Expression expression = testBuilder.parseExpression("?a || ~?a");
        Proposition proposition = new Proposition.ExpressionProposition(expression);
        Clause clause = new Clause(Collections.singletonList(proposition), conclusion, Collections.emptyMap());

        Clause visited = transformToConjunctiveNormalFormClauseVisitor.visit(clause);

        assertThat(visited.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p ->
                assertThat(p.expression).isInstanceOfSatisfying(Expression.BoolConst.class, b -> assertThat(b.value).isEqualTo(true)));
    }

    @Test
    void transform1varContradiction() {
        // a || ~a = FALSE
        Expression expression = testBuilder.parseExpression("?a && ~?a");
        Proposition proposition = new Proposition.ExpressionProposition(expression);
        Clause clause = new Clause(Collections.singletonList(proposition), conclusion, Collections.emptyMap());

        Clause visited = transformToConjunctiveNormalFormClauseVisitor.visit(clause);

        assertThat(visited.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p ->
                assertThat(p.expression).isInstanceOfSatisfying(Expression.BoolConst.class, b -> assertThat(b.value).isEqualTo(false)));
    }

    @Test
    void transform1varWithNumbers()  {
        // ?m > 1 = ?m > 1
        Expression expression = testBuilder.parseExpression("?m > 1");
        Proposition proposition = new Proposition.ExpressionProposition(expression);
        Clause clause = new Clause(Collections.singletonList(proposition), conclusion, Collections.emptyMap());

        Clause visited = transformToConjunctiveNormalFormClauseVisitor.visit(clause);

        assertThat(visited.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p ->
                assertThat(p.expression).isInstanceOfSatisfying(Expression.ComparisonExpression.class, comp -> {
                    assertThat(comp.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?m"));
                    assertThat(comp.expression2).isInstanceOfSatisfying(Expression.IntConst.class, i -> assertThat(i.value).isEqualTo(BigInteger.ONE));
                    assertThat(comp.operation).isEqualTo(Expression.CompOperation.GT);
                }));
    }

    @Test
    void transform2varsNegation1() {
        // ~(?a || ?b) = ~?a && ~?b
        Expression expression = testBuilder.parseExpression("~(?a || ?b)");
        Proposition proposition = new Proposition.ExpressionProposition(expression);
        Clause clause = new Clause(Collections.singletonList(proposition), conclusion, Collections.emptyMap());

        Clause visited = transformToConjunctiveNormalFormClauseVisitor.visit(clause);

        assertThat(visited.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p ->
                assertThat(p.expression).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, e -> {
                    assertThat(e.expression1).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                            assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?b")));
                    assertThat(e.expression2).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                            assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?a")));
                    assertThat(e.operation).isEqualTo(Expression.BoolOperation.AND);
                }));
    }


    @Test
    void transform2varsNegation2() {
        // ~(?a && ?b) = ~?a || ~?b
        Expression expression = testBuilder.parseExpression("~(?a && ?b)");
        Proposition proposition = new Proposition.ExpressionProposition(expression);
        Clause clause = new Clause(Collections.singletonList(proposition), conclusion, Collections.emptyMap());

        Clause visited = transformToConjunctiveNormalFormClauseVisitor.visit(clause);

        assertThat(visited.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p ->
                assertThat(p.expression).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, e -> {
                    assertThat(e.expression1).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                            assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?a")));
                    assertThat(e.expression2).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                            assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?b")));
                    assertThat(e.operation).isEqualTo(Expression.BoolOperation.OR);
                }));
    }

    @Test
    void transform2VarsContradiction() {
        // (?a || ?b) && (~?a && ~?b) = FALSE
        Expression expression = testBuilder.parseExpression("(?a || ?b) && (~?a && ~?b)");
        Proposition proposition = new Proposition.ExpressionProposition(expression);
        Clause clause = new Clause(Collections.singletonList(proposition), conclusion, Collections.emptyMap());

        Clause visited = transformToConjunctiveNormalFormClauseVisitor.visit(clause);

        assertThat(visited.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p ->
                assertThat(p.expression).isInstanceOfSatisfying(Expression.BoolConst.class, b -> assertThat(b.value).isEqualTo(false)));
    }

    @Test
    void transform3vars1() {
        // (?a || ?b) && ?c = (a || b) && c
        Expression expression = testBuilder.parseExpression("(?a || ?b) && ?c");
        Proposition proposition = new Proposition.ExpressionProposition(expression);
        Clause clause = new Clause(Collections.singletonList(proposition), conclusion, Collections.emptyMap());

        Clause visited = transformToConjunctiveNormalFormClauseVisitor.visit(clause);

        assertThat(visited.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p ->
                assertThat(p.expression).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, e -> {
                    assertThat(e.expression1).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, bbe -> {
                        assertThat(bbe.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?a"));
                        assertThat(bbe.expression2).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?b"));
                        assertThat(bbe.operation).isEqualTo(Expression.BoolOperation.OR);
                    });
                    assertThat(e.expression2).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?c"));
                    assertThat(e.operation).isEqualTo(Expression.BoolOperation.AND);
                }));
    }

    @Test
    void transform3vars2() {
        // (?a || ?b) || ?c = ?a || ?b || ?c
        Expression expression = testBuilder.parseExpression("(?a || ?b) || ?c");
        Proposition proposition = new Proposition.ExpressionProposition(expression);
        Clause clause = new Clause(Collections.singletonList(proposition), conclusion, Collections.emptyMap());

        Clause visited = transformToConjunctiveNormalFormClauseVisitor.visit(clause);

        assertThat(visited.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p ->
                assertThat(p.expression).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, e -> {
                    assertThat(e.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?a"));
                    assertThat(e.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, bbe -> {
                        assertThat(bbe.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?b"));
                        assertThat(bbe.expression2).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?c"));
                        assertThat(bbe.operation).isEqualTo(Expression.BoolOperation.OR);
                    });
                    assertThat(e.operation).isEqualTo(Expression.BoolOperation.OR);
                }));
    }


    @Test
    void transform3vars3() {
        // ~(?a && ?b) && ~(?c && (~?a || ?b)) = (?a || ~?c) && (~?a || ~?b)
        Expression expression = testBuilder.parseExpression("~(?a && ?b) && ~(?c && (~?a || ?b))");
        Proposition proposition = new Proposition.ExpressionProposition(expression);
        Clause clause = new Clause(Collections.singletonList(proposition), conclusion, Collections.emptyMap());

        Clause visited = transformToConjunctiveNormalFormClauseVisitor.visit(clause);

        assertThat(visited.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p ->
                assertThat(p.expression).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, e -> {
                    assertThat(e.expression1).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, bbe -> {
                        assertThat(bbe.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?a"));
                        assertThat(bbe.expression2).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?c")));
                        assertThat(bbe.operation).isEqualTo(Expression.BoolOperation.OR);
                    });
                    assertThat(e.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, bbe -> {
                        assertThat(bbe.expression1).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?a")));
                        assertThat(bbe.expression2).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?b")));
                        assertThat(bbe.operation).isEqualTo(Expression.BoolOperation.OR);
                    });
                    assertThat(e.operation).isEqualTo(Expression.BoolOperation.AND);
                }));
    }

    @Test
    void transform4vars1() {
        // (?a && ~?c) || ~(?b && (?d || ~?a) = (?a || ~?b) && (~?b || ~?c || ~?d)
        Expression expression = testBuilder.parseExpression("(?a && ~?c) || ~(?b && (?d || ~?a))");
        Proposition proposition = new Proposition.ExpressionProposition(expression);
        Clause clause = new Clause(Collections.singletonList(proposition), conclusion, Collections.emptyMap());

        Clause visited = transformToConjunctiveNormalFormClauseVisitor.visit(clause);

        assertThat(visited.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p ->
                assertThat(p.expression).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, e -> {
                    assertThat(e.expression1).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, bbe -> {
                        assertThat(bbe.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?a"));
                        assertThat(bbe.expression2).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?b")));
                        assertThat(bbe.operation).isEqualTo(Expression.BoolOperation.OR);
                    });
                    assertThat(e.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, bbe -> {
                        assertThat(bbe.expression1).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?b")));
                        assertThat(bbe.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, bexp -> {
                            assertThat(bexp.expression1).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                    assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?c")));
                            assertThat(bexp.expression2).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                    assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?d")));
                            assertThat(bexp.operation).isEqualTo(Expression.BoolOperation.OR);
                        });
                        assertThat(bbe.operation).isEqualTo(Expression.BoolOperation.OR);
                    });
                    assertThat(e.operation).isEqualTo(Expression.BoolOperation.AND);
                }));
    }

    @Test
    void transform4vars2() {
        // ?a && (?b || (?c && (?d && ?a))) => ?a && (?b || ?c) && (?b || ?d)
        Expression expression = testBuilder.parseExpression("?a && (?b || (?c && (?d && ?a)))");
        Proposition proposition = new Proposition.ExpressionProposition(expression);
        Clause clause = new Clause(Collections.singletonList(proposition), conclusion, Collections.emptyMap());

        Clause visited = transformToConjunctiveNormalFormClauseVisitor.visit(clause);

        assertThat(visited.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p ->
                assertThat(p.expression).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, e -> {
                    assertThat(e.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f ->  assertThat(f.name).isEqualTo("?a"));
                    assertThat(e.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, bbe -> {
                        assertThat(bbe.expression1).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, left -> {
                            assertThat(left.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?b"));
                            assertThat(left.expression2).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?c"));
                            assertThat(left.operation).isEqualTo(Expression.BoolOperation.OR);
                        });
                        assertThat(bbe.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, right -> {
                            assertThat(right.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?b"));
                            assertThat(right.expression2).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?d"));
                            assertThat(right.operation).isEqualTo(Expression.BoolOperation.OR);
                        });
                        assertThat(bbe.operation).isEqualTo(Expression.BoolOperation.AND);
                    });
                    assertThat(e.operation).isEqualTo(Expression.BoolOperation.AND);
                }));
    }

    @Test
    void transform4vars3() {
        // ~?a || ((?a && ~?b) || ?d) || ?c = ~?a || ~?b || ?c || ?d
        Expression expression = testBuilder.parseExpression("~?a || ((?a && ~?b) || ?d) || ?c");
        Proposition proposition = new Proposition.ExpressionProposition(expression);
        Clause clause = new Clause(Collections.singletonList(proposition), conclusion, Collections.emptyMap());

        Clause visited = transformToConjunctiveNormalFormClauseVisitor.visit(clause);

        assertThat(visited.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p ->
                assertThat(p.expression).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, e -> {
                    assertThat(e.expression1).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, bbe -> {
                        assertThat(bbe.expression1).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?a")));
                        assertThat(bbe.expression2).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?b")));
                        assertThat(bbe.operation).isEqualTo(Expression.BoolOperation.OR);
                    });
                    assertThat(e.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, bbe -> {
                        assertThat(bbe.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?c"));
                        assertThat(bbe.expression2).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?d"));
                        assertThat(bbe.operation).isEqualTo(Expression.BoolOperation.OR);
                    });
                    assertThat(e.operation).isEqualTo(Expression.BoolOperation.OR);
                }));
    }

    @Test
    void transform4vars4() {
        // ~?a && (?c || ~?d) || ?b && (?a && ~?c) = (~?a || ?b) && (~?a || ~?c) && (?a || ?c || ~?d)
        Expression expression = testBuilder.parseExpression("~?a && (?c || ~?d) || ?b && (?a && ~?c)");
        Proposition proposition = new Proposition.ExpressionProposition(expression);
        Clause clause = new Clause(Collections.singletonList(proposition), conclusion, Collections.emptyMap());

        Clause visited = transformToConjunctiveNormalFormClauseVisitor.visit(clause);

        assertThat(visited.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p ->
                assertThat(p.expression).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, e -> {
                    assertThat(e.expression1).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, bbe -> {
                        assertThat(bbe.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?a"));
                        assertThat(bbe.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, bbexpression -> {
                            assertThat(bbexpression.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?c"));
                            assertThat(bbexpression.expression2).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                    assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?d")));
                            assertThat(bbexpression.operation).isEqualTo(Expression.BoolOperation.OR);
                        });
                    });
                    assertThat(e.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, bbe -> {
                        assertThat(bbe.expression1).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, left -> {
                            assertThat(left.expression1).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                    assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?a")));
                            assertThat(left.expression2).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?b"));
                            assertThat(left.operation).isEqualTo(Expression.BoolOperation.OR);
                        });
                        assertThat(bbe.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, right -> {
                            assertThat(right.expression1).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                    assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?a")));
                            assertThat(right.expression2).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                    assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?c")));
                            assertThat(right.operation).isEqualTo(Expression.BoolOperation.OR);
                        });
                        assertThat(bbe.operation).isEqualTo(Expression.BoolOperation.AND);
                    });
                    assertThat(e.operation).isEqualTo(Expression.BoolOperation.AND);
                }));
    }

    @Test
    void transform5vars1() {
        // ((~?e && ?a) || (~?d || ((?c && ?e) || ~?b)) && ?d = ?d && (?a || ~?b || e) && (~?b || ?c || ~?e)
        Expression expression = testBuilder.parseExpression("((~?e && ?a) || (~?d || ((?c && ?e) || ~?b))) && ?d");
        Proposition proposition = new Proposition.ExpressionProposition(expression);
        Clause clause = new Clause(Collections.singletonList(proposition), conclusion, Collections.emptyMap());

        Clause visited = transformToConjunctiveNormalFormClauseVisitor.visit(clause);

        assertThat(visited.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p ->
                assertThat(p.expression).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, ex -> {
                    assertThat(ex.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?d"));
                    assertThat(ex.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, bbe -> {
                        assertThat(bbe.expression1).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, left -> {
                            assertThat(left.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?a"));
                            assertThat(left.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, bbexpression -> {
                                assertThat(bbexpression.expression1).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                        assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?b")));
                                assertThat(bbexpression.expression2).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?e"));
                                assertThat(bbexpression.operation).isEqualTo(Expression.BoolOperation.OR);
                            });
                            assertThat(left.operation).isEqualTo(Expression.BoolOperation.OR);
                        });
                        assertThat(bbe.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, right -> {
                            assertThat(right.expression1).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                    assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?b")));
                            assertThat(right.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, bbexpression -> {
                                assertThat(bbexpression.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?c"));
                                assertThat(bbexpression.expression2).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                        assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?e")));
                                assertThat(bbexpression.operation).isEqualTo(Expression.BoolOperation.OR);
                            });
                            assertThat(right.operation).isEqualTo(Expression.BoolOperation.OR);
                        });
                        assertThat(bbe.operation).isEqualTo(Expression.BoolOperation.AND);
                    });
                    assertThat(ex.operation).isEqualTo(Expression.BoolOperation.AND);
                }));
    }

    @Test
    void transform5vars2() {
        // ?d && ~?a || (~?c || ?e) && ?b || ~?e && ?a =  (?a || ?b || ?d) && (?a | ~?c || ?d || ?e) && (~?a || ?b || ~?e)
        Expression expression = testBuilder.parseExpression("?d && ~?a || (~?c || ?e) && ?b || ~?e && ?a");
        Proposition proposition = new Proposition.ExpressionProposition(expression);
        Clause clause = new Clause(Collections.singletonList(proposition), conclusion, Collections.emptyMap());

        Clause visited = transformToConjunctiveNormalFormClauseVisitor.visit(clause);

        assertThat(visited.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p ->
                assertThat(p.expression).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, exp -> {
                    assertThat(exp.expression1).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, left -> {
                        assertThat(left.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?a"));
                        assertThat(left.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, rightPart -> {
                            assertThat(rightPart.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?b"));
                            assertThat(rightPart.expression2).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?d"));
                            assertThat(rightPart.operation).isEqualTo(Expression.BoolOperation.OR);
                        });

                    });
                    assertThat(exp.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, right -> {
                        assertThat(right.expression1).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, first -> {
                            assertThat(first.expression1).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, leftPart -> {
                                assertThat(leftPart.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?a"));
                                assertThat(leftPart.expression2).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                        assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?c")));
                                assertThat(leftPart.operation).isEqualTo(Expression.BoolOperation.OR);
                            });
                            assertThat(first.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, leftPart -> {
                                assertThat(leftPart.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?d"));
                                assertThat(leftPart.expression2).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?e"));
                                assertThat(leftPart.operation).isEqualTo(Expression.BoolOperation.OR);
                            });
                            assertThat(first.operation).isEqualTo(Expression.BoolOperation.OR);
                        });
                        assertThat(right.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, second -> {
                            assertThat(second.expression1).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                    assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?a")));
                            assertThat(second.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, rightPart -> {
                                assertThat(rightPart.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?b"));
                                assertThat(rightPart.expression2).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                        assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?e")));
                                assertThat(rightPart.operation).isEqualTo(Expression.BoolOperation.OR);
                            });
                            assertThat(second.operation).isEqualTo(Expression.BoolOperation.OR);
                        });
                        assertThat(right.operation).isEqualTo(Expression.BoolOperation.AND);
                    });
                    assertThat(exp.operation).isEqualTo(Expression.BoolOperation.AND);
                }));
    }

    @Test
    void transform5VarsTautology() {
        // ?d && ~?a || (?c || ?e) && ?b || ~?d || ?a = TRUE
        Expression expression = testBuilder.parseExpression("?d && ~?a || (?c || ?e) && ?b || ~?d || ?a");
        Proposition proposition = new Proposition.ExpressionProposition(expression);
        Clause clause = new Clause(Collections.singletonList(proposition), conclusion, Collections.emptyMap());

        Clause visited = transformToConjunctiveNormalFormClauseVisitor.visit(clause);

        assertThat(visited.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p ->
                assertThat(p.expression).isInstanceOfSatisfying(Expression.BoolConst.class, b -> assertThat(b.value).isEqualTo(true)));
    }

    @Test
    void transform2Premises() {
        Expression expression1 = testBuilder.parseExpression("~(?a && ?b) && ~(?c && (~?a || ?b))");
        Expression expression2 = testBuilder.parseExpression("?d && ~?a || (?c || ?e) && ?b || ~?d || ?a");
        Proposition proposition1 = new Proposition.ExpressionProposition(expression1);
        Proposition proposition2 = new Proposition.ExpressionProposition(expression2);
        ArrayList<Proposition> propositions = new ArrayList<>();
        propositions.add(proposition1);
        propositions.add(proposition2);
        Clause clause = new Clause(propositions, conclusion, Collections.emptyMap());

        Clause visited = transformToConjunctiveNormalFormClauseVisitor.visit(clause);

        assertThat(visited.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p ->
                assertThat(p.expression).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, e -> {
                    assertThat(e.expression1).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, bbe -> {
                        assertThat(bbe.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?a"));
                        assertThat(bbe.expression2).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?c")));
                        assertThat(bbe.operation).isEqualTo(Expression.BoolOperation.OR);
                    });
                    assertThat(e.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, bbe -> {
                        assertThat(bbe.expression1).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?a")));
                        assertThat(bbe.expression2).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?b")));
                        assertThat(bbe.operation).isEqualTo(Expression.BoolOperation.OR);
                    });
                    assertThat(e.operation).isEqualTo(Expression.BoolOperation.AND);
                }));
        assertThat(visited.premises.get(1)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p ->
                assertThat(p.expression).isInstanceOfSatisfying(Expression.BoolConst.class, b -> assertThat(b.value).isEqualTo(true)));
    }

    @Test
    void transform2PremisesMix() {
        Expression expression1 = testBuilder.parseExpression("~(?a || ?b)");
        Expression expression2 = testBuilder.parseExpression("(?n + 1) > 5");
        Proposition proposition1 = new Proposition.ExpressionProposition(expression1);
        Proposition proposition2 = new Proposition.ExpressionProposition(expression2);
        ArrayList<Proposition> propositions = new ArrayList<>();
        propositions.add(proposition1);
        propositions.add(proposition2);
        Clause clause = new Clause(propositions, conclusion, Collections.emptyMap());

        Clause visited = transformToConjunctiveNormalFormClauseVisitor.visit(clause);

        assertThat(visited.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p ->
                assertThat(p.expression).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, e -> {
                    assertThat(e.expression1).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                            assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?b")));
                    assertThat(e.expression2).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                            assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?a")));
                    assertThat(e.operation).isEqualTo(Expression.BoolOperation.AND);
                }));
        assertThat(visited.premises.get(1)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p ->
                assertThat(p.expression).isInstanceOfSatisfying(Expression.ComparisonExpression.class, comp -> {
                    assertThat(comp.expression1).isInstanceOfSatisfying(Expression.BinaryIntExpression.class, bin -> {
                        assertThat(bin.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?n"));
                        assertThat(bin.expression2).isInstanceOfSatisfying(Expression.IntConst.class, i -> assertThat(i.value).isEqualTo(BigInteger.ONE));
                        assertThat(bin.operation).isEqualTo(Expression.IntOperation.ADD);
                    });
                    assertThat(comp.expression2).isInstanceOfSatisfying(Expression.IntConst.class, i -> assertThat(i.value).isEqualTo(BigInteger.valueOf(5)));
                    assertThat(comp.operation).isEqualTo(Expression.CompOperation.GT);
                }));
    }


    @Test
    void transformPremisesMix() {
        Expression expression = testBuilder.parseExpression("~(?a || ?b) && (?o > 1)");
        Proposition proposition = new Proposition.ExpressionProposition(expression);
        Clause clause = new Clause(Collections.singletonList(proposition), conclusion, Collections.emptyMap());

        Clause visited = transformToConjunctiveNormalFormClauseVisitor.visit(clause);

        assertThat(visited.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p ->
                assertThat(p.expression).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, e -> {
                    assertThat(e.expression1).isInstanceOfSatisfying(Expression.ComparisonExpression.class, comp -> {
                        assertThat(comp.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?o"));
                        assertThat(comp.expression2).isInstanceOfSatisfying(Expression.IntConst.class, i -> assertThat(i.value).isEqualTo(BigInteger.ONE));
                        assertThat(comp.operation).isEqualTo(Expression.CompOperation.GT);
                    });
                    assertThat(e.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, bbe -> {
                        assertThat(bbe.expression1).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?b")));
                        assertThat(bbe.expression2).isInstanceOfSatisfying(Expression.NegationExpression.class, n ->
                                assertThat(n.expression).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?a")));
                        assertThat(bbe.operation).isEqualTo(Expression.BoolOperation.AND);
                    });
                    assertThat(e.operation).isEqualTo(Expression.BoolOperation.AND);
                }));
    }


    public class Provider {
        public Iterable<BigInteger> interval(BigInteger i) {
            List<BigInteger> ret = new ArrayList<>();

            for (int j = 0; j < i.intValue(); ++j) {
                ret.add(BigInteger.valueOf(j));
            }

            return ret;
        }
    }

    @Test
    void testSelectExpression() {
        // (A && B) || (C && D) = (A || C) && (A || D) && (B || C) && (B || D)
        // where A = (select ?arr 0), B = (select ?arr 1)) C = (select ?arr 2), D = (select ?arr 3)

        // setting up the selector functions and everything
        SelectorFunctionHelper selectorFunctionHelper = new SelectorFunctionHelper();
        selectorFunctionHelper.registerProvider(new Provider());

        testBuilder.setSelectorFunctionHelper(selectorFunctionHelper);
        testBuilder.defineSelectorFunction("sel interval: int -> [int];");

        // define the free variable of array type
        state.defineFreeVar("?arr", Type.Array.of(Type.Boolean));

        // here we say how many terms we want to have
        int parameter = 2;

        // this is the sum expression for the problematic term
        String s = "for (!i:int) in interval(" + parameter + "): || ((select ?arr (!i * 2)) && (select ?arr ((!i*2) + 1)))";

        // the sum expression gets instantiated and constants get folded
        InstantiateParametersExpressionVisitor instantiateParametersExpressionVisitor = new InstantiateParametersExpressionVisitor(Collections.emptyMap(), new SelectorFunctionInvoker(selectorFunctionHelper));

        Expression e = testBuilder.parseExpression(s);
        e = e.accept(instantiateParametersExpressionVisitor).accept(new ConstantFoldingExpressionVisitor());

        // here we can see the problematic term
        System.out.println(e.accept(new SExpressionExpressionVisitor(0)));

        // transform expression
        Proposition proposition = new Proposition.ExpressionProposition(e);
        Clause clause = new Clause(Collections.singletonList(proposition), conclusion, Collections.emptyMap());

        Clause visited = transformToConjunctiveNormalFormClauseVisitor.visit(clause);

        assertThat(visited.premises.get(0)).isInstanceOfSatisfying(Proposition.ExpressionProposition.class, p ->
                assertThat(p.expression).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, ex -> {
                    assertThat(ex.expression1).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, bbeLeft -> {
                        assertThat(bbeLeft.expression1).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, left -> {
                            assertThat(left.expression1).isInstanceOfSatisfying(Expression.SelectExpression.class, sel -> {
                                assertThat(sel.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?arr"));
                                assertThat(sel.expression2).isInstanceOfSatisfying(Expression.IntConst.class, i -> assertThat(i.value).isEqualTo(0));
                                assertThat(sel.getType()).isEqualTo(Type.Boolean);
                            });
                            assertThat(left.expression2).isInstanceOfSatisfying(Expression.SelectExpression.class, sel -> {
                                assertThat(sel.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?arr"));
                                assertThat(sel.expression2).isInstanceOfSatisfying(Expression.IntConst.class, i -> assertThat(i.value).isEqualTo(2));
                                assertThat(sel.getType()).isEqualTo(Type.Boolean);
                            });
                            assertThat(left.operation).isEqualTo(Expression.BoolOperation.OR);
                        });
                        assertThat(bbeLeft.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, right -> {
                            assertThat(right.expression1).isInstanceOfSatisfying(Expression.SelectExpression.class, sel -> {
                                assertThat(sel.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?arr"));
                                assertThat(sel.expression2).isInstanceOfSatisfying(Expression.IntConst.class, i -> assertThat(i.value).isEqualTo(0));
                                assertThat(sel.getType()).isEqualTo(Type.Boolean);
                            });
                            assertThat(right.expression2).isInstanceOfSatisfying(Expression.SelectExpression.class, sel -> {
                                assertThat(sel.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?arr"));
                                assertThat(sel.expression2).isInstanceOfSatisfying(Expression.IntConst.class, i -> assertThat(i.value).isEqualTo(3));
                                assertThat(sel.getType()).isEqualTo(Type.Boolean);
                            });
                            assertThat(right.operation).isEqualTo(Expression.BoolOperation.OR);
                        });
                        assertThat(bbeLeft.operation).isEqualTo(Expression.BoolOperation.AND);
                    });
                    assertThat(ex.expression1).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, bbeRight -> {
                        assertThat(bbeRight.expression1).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, left -> {
                            assertThat(left.expression1).isInstanceOfSatisfying(Expression.SelectExpression.class, sel -> {
                                assertThat(sel.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?arr"));
                                assertThat(sel.expression2).isInstanceOfSatisfying(Expression.IntConst.class, i -> assertThat(i.value).isEqualTo(0));
                                assertThat(sel.getType()).isEqualTo(Type.Boolean);
                            });
                            assertThat(left.expression2).isInstanceOfSatisfying(Expression.SelectExpression.class, sel -> {
                                assertThat(sel.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?arr"));
                                assertThat(sel.expression2).isInstanceOfSatisfying(Expression.IntConst.class, i -> assertThat(i.value).isEqualTo(2));
                                assertThat(sel.getType()).isEqualTo(Type.Boolean);
                            });
                            assertThat(left.operation).isEqualTo(Expression.BoolOperation.OR);
                        });
                        assertThat(bbeRight.expression2).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, right -> {
                            assertThat(right.expression1).isInstanceOfSatisfying(Expression.SelectExpression.class, sel -> {
                        assertThat(sel.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?arr"));
                                assertThat(sel.expression2).isInstanceOfSatisfying(Expression.IntConst.class, i -> assertThat(i.value).isEqualTo(0));
                                assertThat(sel.getType()).isEqualTo(Type.Boolean);
                            });
                            assertThat(right.expression2).isInstanceOfSatisfying(Expression.SelectExpression.class, sel -> {
                                assertThat(sel.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> assertThat(f.name).isEqualTo("?arr"));
                                assertThat(sel.expression2).isInstanceOfSatisfying(Expression.IntConst.class, i -> assertThat(i.value).isEqualTo(3));
                                assertThat(sel.getType()).isEqualTo(Type.Boolean);
                            });
                            assertThat(right.operation).isEqualTo(Expression.BoolOperation.OR);
                        });
                        assertThat(bbeRight.operation).isEqualTo(Expression.BoolOperation.AND);
                    });
                    assertThat(ex.operation).isEqualTo(Expression.BoolOperation.AND);
                }));
    }
}