package secpriv.horst.translation.visitors;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import secpriv.horst.data.Expression;
import secpriv.horst.data.ExpressionView;
import secpriv.horst.tools.TestBuilder;
import secpriv.horst.types.Type;
import secpriv.horst.visitors.SExpressionExpressionVisitor;
import secpriv.horst.visitors.VisitorState;

import java.math.BigInteger;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ConservativelyAllocatingConstantFoldingExpressionVisitorTest {
    private TestBuilder testBuilder;
    private ConservativelyAllocatingConstantFoldingExpressionVisitor expressionVisitor;
    private VisitorState state;

    @BeforeEach
    public void setUp() {
        state = new VisitorState();
        state.defineFreeVar("?a", Type.Integer);
        state.defineFreeVar("?i", Type.Integer);
        state.defineFreeVar("?b", Type.Boolean);
        state.defineFreeVar("?ai", Type.Array.of(Type.Integer));
        state.defineFreeVar("?ab", Type.Array.of(Type.Boolean));

        testBuilder = new TestBuilder(state);
        expressionVisitor = new ConservativelyAllocatingConstantFoldingExpressionVisitor();
    }

    @AfterEach
    public void tearDown() {
        state = null;
        testBuilder = null;
        expressionVisitor = null;
    }

    @Test
    public void testFoldSelectFromArrayConst1() {
        Expression e = testBuilder.parseExpression("(select [2] 3)");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isEqualTo(new Expression.IntConst(BigInteger.valueOf(2)));
    }


    @Test
    public void testFoldSelectFromArrayConst2() {
        Expression e = testBuilder.parseExpression("(select [3] (select [1] 3))");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isEqualTo(new Expression.IntConst(BigInteger.valueOf(3)));
    }

    @Test
    public void testFoldSelectFromStore1() {
        Expression e = testBuilder.parseExpression("(select (store [3] 1 5) (select [1] 3))");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isEqualTo(new Expression.IntConst(BigInteger.valueOf(5)));
    }

    @Test
    public void testFoldSelectFromStore2() {
        Expression e = testBuilder.parseExpression("(select (store [3] 1 5) (select [2] 3))");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isEqualTo(new Expression.IntConst(BigInteger.valueOf(3)));
    }


    @Test
    public void testFoldSelectFromStore3() {
        Expression e = testBuilder.parseExpression("(select (store [3] (?a - 1) 4) (select (store [1] 3 (?a - 1)) 3))");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isEqualTo(new Expression.IntConst(BigInteger.valueOf(4)));
    }


    @Test
    public void testFoldSelectFromSimpleStoreWithIncompatibleIndex() {
        Expression e = testBuilder.parseExpression("(select (store ?ai (?a - 1) 5) (?i -1))");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.SelectExpression.class, se -> {
            assertThat(se.expression1).isInstanceOfSatisfying(Expression.StoreExpression.class, st -> {
                assertThat(st.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Array.of(Type.Integer), "?ai"));
                assertThat(st.expression2).isInstanceOfSatisfying(Expression.BinaryIntExpression.class, sti -> {
                    assertThat(sti.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
                    assertThat(sti.expression2).isEqualTo(new Expression.IntConst(BigInteger.ONE));
                    assertThat(sti.operation).isEqualTo(Expression.IntOperation.SUB);
                });
                assertThat(st.expression3).isEqualTo(new Expression.IntConst(BigInteger.valueOf(5)));
            });
            assertThat(se.expression2).isInstanceOfSatisfying(Expression.BinaryIntExpression.class, sei -> {
                assertThat(sei.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?i"));
                assertThat(sei.expression2).isEqualTo(new Expression.IntConst(BigInteger.ONE));
                assertThat(sei.operation).isEqualTo(Expression.IntOperation.SUB);
            });
        });
    }

    @Test
    public void testFoldSelectFromComplexStoreWithIncompatibleIndex2() {
        Expression e = testBuilder.parseExpression("(select (store (store ?ai (?i -1) 3) (?a - 1) 5) (?i -1))");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.SelectExpression.class, se -> {
            assertThat(se.expression1).isInstanceOfSatisfying(Expression.StoreExpression.class, st1 -> {
                assertThat(st1.expression1).isInstanceOfSatisfying(Expression.StoreExpression.class, st2 -> {
                    assertThat(st2.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Array.of(Type.Integer), "?ai"));
                    assertThat(st2.expression2).isInstanceOfSatisfying(Expression.BinaryIntExpression.class, st2i -> {
                        assertThat(st2i.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?i"));
                        assertThat(st2i.expression2).isEqualTo(new Expression.IntConst(BigInteger.ONE));
                        assertThat(st2i.operation).isEqualTo(Expression.IntOperation.SUB);
                    });
                });
                assertThat(st1.expression2).isInstanceOfSatisfying(Expression.BinaryIntExpression.class, st1i -> {
                    assertThat(st1i.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
                    assertThat(st1i.expression2).isEqualTo(new Expression.IntConst(BigInteger.ONE));
                    assertThat(st1i.operation).isEqualTo(Expression.IntOperation.SUB);
                });
                assertThat(st1.expression3).isEqualTo(new Expression.IntConst(BigInteger.valueOf(5)));
            });
            assertThat(se.expression2).isInstanceOfSatisfying(Expression.BinaryIntExpression.class, sei -> {
                assertThat(sei.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?i"));
                assertThat(sei.expression2).isEqualTo(new Expression.IntConst(BigInteger.ONE));
                assertThat(sei.operation).isEqualTo(Expression.IntOperation.SUB);
            });
        });
    }
    @Test
    public void testFoldSelect1() {
        Expression e = testBuilder.parseExpression("(select (store ?ai (?i + 1) 3) (?i - ~1))");

        Expression result = e.accept(expressionVisitor);
        System.out.println(e.accept(new SExpressionExpressionVisitor(0)));

        assertThat(result).isEqualTo(new Expression.IntConst(BigInteger.valueOf(3)));

    }


    @Test
    public void testFoldIdempotentStore1() {
        Expression e = testBuilder.parseExpression("(store (store (store [3] 1 4) 2 3) 3 4)");

        Expression result = e.accept(expressionVisitor);

        System.out.println(result.accept(new SExpressionExpressionVisitor(0)));

        assertThat(result).isInstanceOfSatisfying(Expression.StoreExpression.class, s1 -> {
            assertThat(s1.expression1).isInstanceOfSatisfying(Expression.StoreExpression.class, s2 -> {
                assertThat(s2.expression1).isInstanceOfSatisfying(Expression.ArrayInitExpression.class, a -> {
                    assertThat(a.initializer).isEqualTo(new Expression.IntConst(BigInteger.valueOf(3)));
                });
                assertThat(s2.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(1)));
                assertThat(s2.expression3).isEqualTo(new Expression.IntConst(BigInteger.valueOf(4)));
            });
            assertThat(s1.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(3)));
            assertThat(s1.expression3).isEqualTo(new Expression.IntConst(BigInteger.valueOf(4)));

        });
    }

    @Test
    public void testFoldIdempotentStore2() {
        Expression e = testBuilder.parseExpression("(store (store (store [true] 1 true) 2 true) 3 true)");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ArrayInitExpression.class, a -> {
            assertThat(a.initializer).isEqualTo(Expression.BoolConst.TRUE);
        });

    }

    @Test
    public void testFoldIdempotentStore3() {
        Expression e = testBuilder.parseExpression("(store (store [true] 1 false) 1 true)");

        Expression result = e.accept(expressionVisitor);

        System.out.println(result.accept(new SExpressionExpressionVisitor(0)));

        assertThat(result).isInstanceOfSatisfying(Expression.ArrayInitExpression.class, a -> {
            assertThat(a.initializer).isEqualTo(Expression.BoolConst.TRUE);
        });

    }

    @Test
    public void testFoldIdempotentStore4() {
        Expression e = testBuilder.parseExpression("(store (store (store [2] 1 3) 2 5) 1 4)");

        Expression result = e.accept(expressionVisitor);
        System.out.println(result.accept(new SExpressionExpressionVisitor(0)));

        assertThat(result).isInstanceOfSatisfying(Expression.StoreExpression.class, s1 -> {
            assertThat(s1.expression1).isInstanceOfSatisfying(Expression.StoreExpression.class, s2 -> {
                assertThat(s2.expression1).isInstanceOfSatisfying(Expression.ArrayInitExpression.class, a -> {
                    assertThat(a.initializer).isEqualTo(new Expression.IntConst(BigInteger.valueOf(2)));
                });
                assertThat(s2.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(2)));
                assertThat(s2.expression3).isEqualTo(new Expression.IntConst(BigInteger.valueOf(5)));
            });
            assertThat(s1.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(1)));
            assertThat(s1.expression3).isEqualTo(new Expression.IntConst(BigInteger.valueOf(4)));

        });
    }


    @Test
    public void testStripUselessStores1() {
        Expression e = testBuilder.parseExpression("(select (store (store (store ?ai 1 3) 2 5) 5 4) 100)");

        Expression result = e.accept(expressionVisitor);
        System.out.println(result.accept(new SExpressionExpressionVisitor(0)));

        assertThat(result).isInstanceOfSatisfying(Expression.SelectExpression.class, s -> {
            assertThat(s.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> {
                assertThat(f.type).isEqualTo(Type.Array.of(Type.Integer));
                assertThat(f.name).isEqualTo("?ai");
            });
            assertThat(s.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(100)));
        });
    }


    @Test
    public void testStripUselessStores2() {
        Expression e = testBuilder.parseExpression("(select (store (store (store ?ab 1 false) 2 true) 5 false) 100)");

        Expression result = e.accept(expressionVisitor);
        System.out.println(result.accept(new SExpressionExpressionVisitor(0)));

        assertThat(result).isInstanceOfSatisfying(Expression.SelectExpression.class, s -> {
            assertThat(s.expression1).isInstanceOfSatisfying(Expression.FreeVarExpression.class, f -> {
                assertThat(f.type).isEqualTo(Type.Array.of(Type.Boolean));
                assertThat(f.name).isEqualTo("?ab");
            });
            assertThat(s.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(100)));
        });
    }


    @Test
    public void testSelectWithITE() {
        Expression e = testBuilder.parseExpression("(select ((?b) ? (store [1] 2 5) : (store [2] 6 10)) 6)");

        Expression result = e.accept(expressionVisitor);


        assertThat(result).isInstanceOfSatisfying(Expression.SelectExpression.class, s -> {
            assertThat(s.expression1).isInstanceOfSatisfying(Expression.ConditionalExpression.class, c -> {
                assertThat(c.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Boolean, "?b"));
                assertThat(c.expression2).isInstanceOfSatisfying(Expression.StoreExpression.class, ss -> {
                    assertThat(ss.expression1).isInstanceOfSatisfying(Expression.ArrayInitExpression.class, a -> assertThat(a.initializer).isEqualTo(new Expression.IntConst(BigInteger.ONE)));
                    assertThat(ss.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(2)));
                    assertThat(ss.expression3).isEqualTo(new Expression.IntConst(BigInteger.valueOf(5)));
                });
                assertThat(c.expression3).isInstanceOfSatisfying(Expression.StoreExpression.class, ss -> {
                    assertThat(ss.expression1).isInstanceOfSatisfying(Expression.ArrayInitExpression.class, a -> assertThat(a.initializer).isEqualTo(new Expression.IntConst(BigInteger.valueOf(2))));
                    assertThat(ss.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(6)));
                    assertThat(ss.expression3).isEqualTo(new Expression.IntConst(BigInteger.valueOf(10)));
                });
            });
            assertThat(s.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(6)));
        });
    }

    @Test
    public void optimizeNestedStoreEvenIfDifferentWrites() {
        Expression e = testBuilder.parseExpression("(store (store (store ?ab ?i + 1 (select [true] 1)) ?a + 2 true) ?i + 2 true)");
        // possible optimization
        // Expression e1 = testBuilder.parseExpression("(store (store (store ?ab ?i (select ?ab (?i - 2))) (?i + 1) true) (?i + 2) true))))");

        //TODO make assert more precise

        Expression result = e.accept(expressionVisitor);

        System.out.println(result.accept(new SExpressionExpressionVisitor(0)));

        assertThat(result).isInstanceOfSatisfying(Expression.StoreExpression.class, s1 -> {
            assertThat(s1.expression1).isInstanceOfSatisfying(Expression.StoreExpression.class, s2 -> {
                assertThat(s2.expression1).isInstanceOfSatisfying(Expression.StoreExpression.class, s3 -> {
                    assertThat(s3.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Array.of(Type.Boolean), "?ab"));
                    assertThat(s3.expression2).isInstanceOfSatisfying(Expression.BinaryIntExpression.class, i3 -> {
                        assertThat(i3.operation).isEqualTo(Expression.IntOperation.ADD);
                        assertThat(i3.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?i"));
                        assertThat(i3.expression2).isEqualTo(new Expression.IntConst(BigInteger.ONE));
                    });
                    assertThat(s3.expression3).isEqualTo(Expression.BoolConst.TRUE);
                });
            });

        });
    }

    private void testAdditiveFold(String s1, String s2) {
        Expression e1 = testBuilder.parseExpression(s1);
        Expression e2 = testBuilder.parseExpression(s2);

        ExpressionView.SimpleAdditiveTerm v1 = new ExpressionView.SimpleAdditiveTerm(e1.accept(expressionVisitor));
        ExpressionView.SimpleAdditiveTerm v2 = new ExpressionView.SimpleAdditiveTerm(e2.accept(expressionVisitor));

        assertThat(v1).isEqualTo(v2);
    }

    @Test
    public void foldAdditive1() {
        testAdditiveFold("((?a + 7) + 8)", "?a + 15");
    }

    @Test
    public void foldAdditive2() {
        testAdditiveFold("((?a + 5) - 4)", "?a + 1");
    }

    @Test
    public void foldAdditive3() {
        testAdditiveFold("((?a - 3) + 8)", "?a + 5");
    }

    @Test
    public void foldAdditive4() {
        testAdditiveFold("((?a - 7) - 4)", "?a - 11");
    }

    @Test
    public void foldAdditive5() {
        testAdditiveFold("((7 + ?a) + 6)", "?a + 13");
    }

    @Test
    public void foldAdditive6() {
        testAdditiveFold("((6 + ?a) - 3)", "?a + 3");
    }

    @Test
    public void foldAdditive7() {
        testAdditiveFold("((3 - ?a) + 8)", "11 - ?a");
    }

    @Test
    public void foldAdditive8() {
        testAdditiveFold("((8 - ?a) - 3)", "5 - ?a");
    }

    @Test
    public void foldAdditive9() {
        testAdditiveFold("(5 + (?a + 2))", "?a + 7");
    }

    @Test
    public void foldAdditive10() {
        testAdditiveFold("(4 - (?a + 3))", "1 - ?a");
    }

    @Test
    public void foldAdditive11() {
        testAdditiveFold("(7 + (?a - 5))", "?a + 2");
    }

    @Test
    public void foldAdditive12() {
        testAdditiveFold("(9 - (?a - 6))", "15 - ?a");
    }

    @Test
    public void foldAdditive13() {
        testAdditiveFold("(9 + (8 + ?a))", "?a + 17");
    }

    @Test
    public void foldAdditive14() {
        testAdditiveFold("(4 - (8 + ?a))", "(0 - 4) - ?a");
    }

    @Test
    public void foldAdditive14_2() {
        testAdditiveFold("(4 - (2 + ?a))", "2 - ?a");
    }

    @Test
    public void foldAdditive15() {
        testAdditiveFold("(3 + (7 - ?a))", "10 - ?a");
    }

    @Test
    public void foldAdditive16() {
        testAdditiveFold("(4 - (3 - ?a))", "1 + ?a");
    }

    @Test
    public void foldBooleanEquality1() {
        Expression e = testBuilder.parseExpression("?b = true");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isEqualTo(new Expression.FreeVarExpression(Type.Boolean, "?b"));
    }

    @Test
    public void foldBooleanEquality2() {
        Expression e = testBuilder.parseExpression("(?b && (?a = 4)) = true");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, be -> {
            assertThat(be.operation).isEqualTo(Expression.BoolOperation.AND);
            assertThat(be.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Boolean, "?b"));
            assertThat(be.expression2).isInstanceOfSatisfying(Expression.ComparisonExpression.class, ce -> {
                assertThat(ce.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
                assertThat(ce.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(4)));
                assertThat(ce.operation).isEqualTo(Expression.CompOperation.EQ);

            });
        });
    }

    @Test
    public void foldBooleanEquality3() {
        Expression e = testBuilder.parseExpression("?b = false");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.NegationExpression.class, ne ->
                assertThat(ne.expression).isEqualTo(new Expression.FreeVarExpression(Type.Boolean, "?b")));
    }

    @Test
    public void foldBooleanEquality4() {
        Expression e = testBuilder.parseExpression("(?b && (?a = 4)) = false");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.NegationExpression.class, ne ->
                assertThat(ne.expression).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, be -> {
                    assertThat(be.operation).isEqualTo(Expression.BoolOperation.AND);
                    assertThat(be.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Boolean, "?b"));
                    assertThat(be.expression2).isInstanceOfSatisfying(Expression.ComparisonExpression.class, ce -> {
                        assertThat(ce.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
                        assertThat(ce.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(4)));
                        assertThat(ce.operation).isEqualTo(Expression.CompOperation.EQ);

                    });
                }));
    }

    @Test
    public void testLiftITEEqualities2() {
        Expression e = testBuilder.parseExpression("4 = ((?b) ? (?a) : (?i))");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ConditionalExpression.class, ce -> {
            assertThat(ce.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Boolean, "?b"));
            assertThat(ce.expression2).isInstanceOfSatisfying(Expression.ComparisonExpression.class, pe -> {
                assertThat(pe.operation).isEqualTo(Expression.CompOperation.EQ);
                assertThat(pe.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
                assertThat(pe.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(4)));
            });
            assertThat(ce.expression3).isInstanceOfSatisfying(Expression.ComparisonExpression.class, pe -> {
                assertThat(pe.operation).isEqualTo(Expression.CompOperation.EQ);
                assertThat(pe.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?i"));
                assertThat(pe.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(4)));
            });
        });
    }

    @Test
    public void testLiftITEEqualities1() {
        Expression e = testBuilder.parseExpression("((?b) ? (?a) : (?i)) = 3");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ConditionalExpression.class, ce -> {
            assertThat(ce.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Boolean, "?b"));
            assertThat(ce.expression2).isInstanceOfSatisfying(Expression.ComparisonExpression.class, pe -> {
                assertThat(pe.operation).isEqualTo(Expression.CompOperation.EQ);
                assertThat(pe.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
                assertThat(pe.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(3)));
            });
            assertThat(ce.expression3).isInstanceOfSatisfying(Expression.ComparisonExpression.class, pe -> {
                assertThat(pe.operation).isEqualTo(Expression.CompOperation.EQ);
                assertThat(pe.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?i"));
                assertThat(pe.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(3)));
            });
        });
    }

    @Test
    public void testConditionUsedInConditionalBranches1() {
        Expression e = testBuilder.parseExpression("(?b) ? ((?b) ? (5) : (3)) : ((?b) ? (2) : (7))");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ConditionalExpression.class, ce -> {
            assertThat(ce.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Boolean, "?b"));
            assertThat(ce.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(5)));
            assertThat(ce.expression3).isEqualTo(new Expression.IntConst(BigInteger.valueOf(7)));
        });
    }

    @Test
    public void testConditionUsedInConditionalBranches2() {
        Expression e = testBuilder.parseExpression("(?a = 4) ? (?a = 4) : (?a = 5)");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.BinaryBoolExpression.class, ce -> {
            assertThat(ce.expression1).isInstanceOfSatisfying(Expression.ComparisonExpression.class, cmp -> {
                assertThat(cmp.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
                assertThat(cmp.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(4)));
                assertThat(cmp.operation).isEqualTo(Expression.CompOperation.EQ);
            });
            assertThat(ce.expression2).isInstanceOfSatisfying(Expression.ComparisonExpression.class, cmp -> {
                assertThat(cmp.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
                assertThat(cmp.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(5)));
                assertThat(cmp.operation).isEqualTo(Expression.CompOperation.EQ);
            });
        });
    }

    @Test
    public void testSimpleComparision1() {
        Expression e = testBuilder.parseExpression("?a + 4 < 3");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.LT);
            assertThat(co.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
            assertThat(co.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(-1)));
        });
    }

    @Test
    public void testSimpleComparision2() {
        Expression e = testBuilder.parseExpression("?a + 5 <= 2");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.LE);
            assertThat(co.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
            assertThat(co.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(-3)));
        });
    }

    @Test
    public void testSimpleComparision3() {
        Expression e = testBuilder.parseExpression("?a - 3 < 2");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.LT);
            assertThat(co.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
            assertThat(co.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(5)));
        });
    }

    @Test
    public void testSimpleComparision4() {
        Expression e = testBuilder.parseExpression("?a - 7 <= ~1");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.LE);
            assertThat(co.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
            assertThat(co.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(6)));
        });
    }

    @Test
    public void testSimpleComparision5() {
        Expression e = testBuilder.parseExpression("?a + 4 > 3");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.GT);
            assertThat(co.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
            assertThat(co.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(-1)));
        });
    }

    @Test
    public void testSimpleComparision6() {
        Expression e = testBuilder.parseExpression("?a + 5 >= 2");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.GE);
            assertThat(co.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
            assertThat(co.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(-3)));
        });
    }

    @Test
    public void testSimpleComparision7() {
        Expression e = testBuilder.parseExpression("?a - 3 > 2");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.GT);
            assertThat(co.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
            assertThat(co.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(5)));
        });
    }

    @Test
    public void testSimpleComparision8() {
        Expression e = testBuilder.parseExpression("?a - 7 >= ~1");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.GE);
            assertThat(co.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
            assertThat(co.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(6)));
        });
    }

    @Test
    public void testSimpleComparision9() {
        Expression e = testBuilder.parseExpression("3 < ?a + 4");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.LT);
            assertThat(co.expression1).isEqualTo(new Expression.IntConst(BigInteger.valueOf(-1)));
            assertThat(co.expression2).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        });
    }

    @Test
    public void testSimpleComparision10() {
        Expression e = testBuilder.parseExpression("2 <= ?a + 5");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.LE);
            assertThat(co.expression1).isEqualTo(new Expression.IntConst(BigInteger.valueOf(-3)));
            assertThat(co.expression2).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        });
    }

    @Test
    public void testSimpleComparision11() {
        Expression e = testBuilder.parseExpression("2 < ?a - 3");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.LT);
            assertThat(co.expression1).isEqualTo(new Expression.IntConst(BigInteger.valueOf(5)));
            assertThat(co.expression2).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        });
    }

    @Test
    public void testSimpleComparision12() {
        Expression e = testBuilder.parseExpression("~1 <= ?a - 7");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.LE);
            assertThat(co.expression1).isEqualTo(new Expression.IntConst(BigInteger.valueOf(6)));
            assertThat(co.expression2).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        });
    }

    @Test
    public void testSimpleComparision13() {
        Expression e = testBuilder.parseExpression("3 > ?a + 4");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.GT);
            assertThat(co.expression1).isEqualTo(new Expression.IntConst(BigInteger.valueOf(-1)));
            assertThat(co.expression2).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        });
    }

    @Test
    public void testSimpleComparision14() {
        Expression e = testBuilder.parseExpression("2 >= ?a + 5");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.GE);
            assertThat(co.expression1).isEqualTo(new Expression.IntConst(BigInteger.valueOf(-3)));
            assertThat(co.expression2).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        });
    }

    @Test
    public void testSimpleComparision15() {
        Expression e = testBuilder.parseExpression("2 > ?a - 3");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.GT);
            assertThat(co.expression1).isEqualTo(new Expression.IntConst(BigInteger.valueOf(5)));
            assertThat(co.expression2).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        });
    }

    @Test
    public void testSimpleComparision16() {
        Expression e = testBuilder.parseExpression("~1 >= ?a - 7");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.GE);
            assertThat(co.expression1).isEqualTo(new Expression.IntConst(BigInteger.valueOf(6)));
            assertThat(co.expression2).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        });
    }

    @Test
    public void testSimpleComparision17() {
        Expression e = testBuilder.parseExpression("5 + ?a < 4");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.LT);
            assertThat(co.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
            assertThat(co.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(-1)));
        });
    }

    @Test
    public void testSimpleComparision18() {
        Expression e = testBuilder.parseExpression("5 + ?a <= 3");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.LE);
            assertThat(co.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
            assertThat(co.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(-2)));
        });
    }

    @Test
    public void testSimpleComparision19() {
        Expression e = testBuilder.parseExpression("3 - ?a < 2");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.GT);
            assertThat(co.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
            assertThat(co.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(1)));
        });
    }


    @Test
    public void testSimpleComparision20() {
        Expression e = testBuilder.parseExpression("7 - ?a  <= ~1");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.GE);
            assertThat(co.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
            assertThat(co.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(8)));
        });
    }

    @Test
    public void testSimpleComparision21() {
        Expression e = testBuilder.parseExpression("5 + ?a > 4");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.GT);
            assertThat(co.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
            assertThat(co.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(-1)));
        });
    }

    @Test
    public void testSimpleComparision22() {
        Expression e = testBuilder.parseExpression("4 + ?a >= 1");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.GE);
            assertThat(co.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
            assertThat(co.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(-3)));
        });
    }

    @Test
    public void testSimpleComparision23() {
        Expression e = testBuilder.parseExpression("3 - ?a > 2");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.LT);
            assertThat(co.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
            assertThat(co.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(1)));
        });
    }

    @Test
    public void testSimpleComparision24() {
        Expression e = testBuilder.parseExpression("7 - ?a >= ~1");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.LE);
            assertThat(co.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
            assertThat(co.expression2).isEqualTo(new Expression.IntConst(BigInteger.valueOf(8)));
        });
    }

    @Test
    public void testSimpleComparision25() {
        Expression e = testBuilder.parseExpression("4 < 5 + ?a");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.LT);
            assertThat(co.expression1).isEqualTo(new Expression.IntConst(BigInteger.valueOf(-1)));
            assertThat(co.expression2).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        });
    }

    @Test
    public void testSimpleComparision26() {
        Expression e = testBuilder.parseExpression("1 <= 4 + ?a");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.LE);
            assertThat(co.expression1).isEqualTo(new Expression.IntConst(BigInteger.valueOf(-3)));
            assertThat(co.expression2).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        });
    }

    @Test
    public void testSimpleComparision27() {
        Expression e = testBuilder.parseExpression("2 < 3 - ?a");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.GT);
            assertThat(co.expression1).isEqualTo(new Expression.IntConst(BigInteger.valueOf(1)));
            assertThat(co.expression2).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        });
    }

    @Test
    public void testSimpleComparision28() {
        Expression e = testBuilder.parseExpression("~1 <= 7 - ?a");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.GE);
            assertThat(co.expression1).isEqualTo(new Expression.IntConst(BigInteger.valueOf(8)));
            assertThat(co.expression2).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        });
    }

    @Test
    public void testSimpleComparision29() {
        Expression e = testBuilder.parseExpression("4 > 5 + ?a");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.GT);
            assertThat(co.expression1).isEqualTo(new Expression.IntConst(BigInteger.valueOf(-1)));
            assertThat(co.expression2).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        });
    }

    @Test
    public void testSimpleComparision30() {
        Expression e = testBuilder.parseExpression("2 >= 5 + ?a");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.GE);
            assertThat(co.expression1).isEqualTo(new Expression.IntConst(BigInteger.valueOf(-3)));
            assertThat(co.expression2).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        });
    }

    @Test
    public void testSimpleComparision31() {
        Expression e = testBuilder.parseExpression("2 > 3 - ?a");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.LT);
            assertThat(co.expression1).isEqualTo(new Expression.IntConst(BigInteger.valueOf(1)));
            assertThat(co.expression2).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        });
    }

    @Test
    public void testSimpleComparision32() {
        Expression e = testBuilder.parseExpression("~1 >= 7 - ?a");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.ComparisonExpression.class, co -> {
            assertThat(co.operation).isEqualTo(Expression.CompOperation.LE);
            assertThat(co.expression1).isEqualTo(new Expression.IntConst(BigInteger.valueOf(8)));
            assertThat(co.expression2).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?a"));
        });
    }

    @Test
    public void testCannotFoldSeparatedConstants() {
        // This test just encodes the status quo, ((?a + ?a) + 7) would also be a good result
        // it mainly exists because it triggered an exception in a buggy version
        Expression e = testBuilder.parseExpression("(((?a + 5) + ?a) + 2)");

        Expression result = e.accept(expressionVisitor);

        assertThat(result).isEqualTo(result);
    }

}