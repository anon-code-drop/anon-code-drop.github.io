package secpriv.horst.translation.visitors;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import secpriv.horst.data.Expression;
import secpriv.horst.tools.TestBuilder;
import secpriv.horst.types.Type;
import secpriv.horst.visitors.VisitorState;

import java.math.BigInteger;
import java.util.Collections;

import static org.assertj.core.api.Assertions.*;

class ContextSensitiveInlineEqualitiesExpressionVisitorTest {

    private TestBuilder testBuilder;
    private VisitorState state;

    @BeforeEach
    public void setUp() {
        state = new VisitorState();
        state.defineFreeVar("?i", Type.Integer);
        state.defineFreeVar("?j", Type.Integer);
        state.defineFreeVar("?ai", Type.Array.of(Type.Integer));
        testBuilder = new TestBuilder(state);
    }

    @AfterEach
    public void tearDown() {
        testBuilder = null;
        state = null;
    }


    @Test
    public void testInlineStoreWithComparableIndex() {
        Expression context = testBuilder.parseExpression("(select ?ai (?i -1))");
        Expression inline = testBuilder.parseExpression("(store [0] (?i -1) 1)");

        ContextSensitiveInlineEqualitiesExpressionVisitor expressionVisitor = new ContextSensitiveInlineEqualitiesExpressionVisitor(Collections.singletonMap(new Expression.FreeVarExpression(Type.Array.of(Type.Integer), "?ai"), inline));

        Expression result = context.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.SelectExpression.class, se -> {
            assertThat(se.expression1).isInstanceOfSatisfying(Expression.StoreExpression.class, st -> {
                assertThat(st.expression1).isInstanceOfSatisfying(Expression.ArrayInitExpression.class, ai -> assertThat(ai.initializer).isEqualTo(new Expression.IntConst(BigInteger.ZERO)));
                assertThat(st.expression2).isInstanceOfSatisfying(Expression.BinaryIntExpression.class, sti -> {
                    assertThat(sti.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?i"));
                    assertThat(sti.expression2).isEqualTo(new Expression.IntConst(BigInteger.ONE));
                    assertThat(sti.operation).isEqualTo(Expression.IntOperation.SUB);
                });
                assertThat(st.expression3).isEqualTo(new Expression.IntConst(BigInteger.ONE));
            });
            assertThat(se.expression2).isInstanceOfSatisfying(Expression.BinaryIntExpression.class, sei -> {
                assertThat(sei.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?i"));
                assertThat(sei.expression2).isEqualTo(new Expression.IntConst(BigInteger.ONE));
                assertThat(sei.operation).isEqualTo(Expression.IntOperation.SUB);
            });
        });
        assertThat(expressionVisitor.hasSkippedInlines()).isFalse();
    }

    @Test
    public void testDontInlineStoreIncomparableSameIndex() {
        Expression context = testBuilder.parseExpression("(select ?ai (?i -1))");
        Expression inline = testBuilder.parseExpression("(store [0] (?j -1) 1)");

        ContextSensitiveInlineEqualitiesExpressionVisitor expressionVisitor = new ContextSensitiveInlineEqualitiesExpressionVisitor(Collections.singletonMap(new Expression.FreeVarExpression(Type.Array.of(Type.Integer), "?ai"), inline));

        Expression result = context.accept(expressionVisitor);

        assertThat(result).isInstanceOfSatisfying(Expression.SelectExpression.class, se -> {
            assertThat(se.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Array.of(Type.Integer), "?ai"));
            assertThat(se.expression2).isInstanceOfSatisfying(Expression.BinaryIntExpression.class, sei -> {
                assertThat(sei.expression1).isEqualTo(new Expression.FreeVarExpression(Type.Integer, "?i"));
                assertThat(sei.expression2).isEqualTo(new Expression.IntConst(BigInteger.ONE));
                assertThat(sei.operation).isEqualTo(Expression.IntOperation.SUB);
            });
        });
        assertThat(expressionVisitor.hasSkippedInlines()).isTrue();
    }
}