package secpriv.horst.translation.visitors;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import secpriv.horst.data.Clause;
import secpriv.horst.data.Proposition;
import secpriv.horst.data.Rule;
import secpriv.horst.internals.IntervalProvider;
import secpriv.horst.internals.SelectorFunctionHelper;
import secpriv.horst.internals.SelectorFunctionInvoker;
import secpriv.horst.tools.TestBuilder;
import secpriv.horst.translation.TranslationPipeline;
import secpriv.horst.visitors.SExpressionClauseVisitor;
import secpriv.horst.visitors.VisitorState;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;

class ClauseMergerTest {
    private ClauseMerger clauseMerger;
    private TestBuilder testBuilder;
    private TranslationPipeline pipeline;

    @BeforeEach
    public void setUp() {
        clauseMerger = new ClauseMerger();
        testBuilder = new TestBuilder(new VisitorState());
        SelectorFunctionHelper selectorFunctionHelper = new SelectorFunctionHelper();
        selectorFunctionHelper.registerProvider(new IntervalProvider());
        testBuilder.setSelectorFunctionHelper(selectorFunctionHelper);

        pipeline = TranslationPipeline.builder()
                .addFlatMappingStep(new InstantiateParametersRuleVisitor(new SelectorFunctionInvoker(selectorFunctionHelper)))
                .addStep(new SimplifyPredicateArgumentsRuleVisitor())
                .addStep(new RenameFreeVariablesRuleVisitor()).build();
    }

    @AfterEach
    public void tearDown() {
        clauseMerger = null;
        testBuilder = null;
        pipeline = null;
    }


    @Test
    public void testSimplestMerge() {
        testBuilder.definePredicate("pred Bb{}: int;");
        testBuilder.definePredicate("pred Cc{}: int;");

        Rule r3 = testBuilder.defineRule("rule r3 := clause [?x : bool] Bb(0) => Cc(0);");
        Rule q = testBuilder.defineQuery("query q Cc(0);");

        List<Rule> rules = pipeline.apply(Arrays.asList(r3, q));

        List<Clause> clauses = rules.stream().flatMap(r -> r.clauses.stream()).collect(Collectors.toList());

        assertThat(clauses).hasSize(2);

        Clause mergedClause = clauseMerger.merge(clauses);

        assertThat(mergedClause.conclusion.predicate.name).isEqualTo("q");
        assertThat(mergedClause.premises).hasSize(4);
        assertThat(mergedClause.premises).anySatisfy(p -> assertThat(p).isInstanceOfSatisfying(Proposition.PredicateProposition.class, pr -> assertThat(pr.predicate.name).isEqualTo("Bb")));
        assertThat(mergedClause.premises).noneSatisfy(p -> assertThat(p).isInstanceOfSatisfying(Proposition.PredicateProposition.class, pr -> assertThat(pr.predicate.name).isEqualTo("Cc")));
    }

    @Test
    public void testSimpleMerge() {
        testBuilder.defineSelectorFunction("sel interval: int*int -> [int];");
        testBuilder.definePredicate("pred Oo{int}: int*int;");
        Rule rule = testBuilder.defineRule("rule testRule := for (!i:int) in interval(0,5) \n" +
                "clause [?x:int, ?y:int] Oo{!i}(?x,?y), ?x > !i, ?x > ?y => Oo{!i+1}(?x,?y);");

        List<Rule> rules = pipeline.apply(Collections.singletonList(rule));

        assertThat(rules).hasSize(5);
        List<Clause> clauses = rules.stream().map(r -> r.clauses.get(0)).collect(Collectors.toList());

        Clause mergedClause = clauseMerger.merge(clauses);

        assertThat(mergedClause.freeVars).hasSize(2);
        assertThat(mergedClause.premises).hasSize(11);
        assertThat(mergedClause.premises).anySatisfy(p -> assertThat(p).isInstanceOfSatisfying(Proposition.PredicateProposition.class, pr -> assertThat(pr.predicate.name).isEqualTo("Oo_0")));
        assertThat(mergedClause.premises).noneSatisfy(p -> assertThat(p).isInstanceOfSatisfying(Proposition.PredicateProposition.class, pr -> assertThat(pr.predicate.name).isNotEqualTo("Oo_0")));

        assertThat(mergedClause.conclusion.predicate.name).isEqualTo("Oo_5");
    }
}