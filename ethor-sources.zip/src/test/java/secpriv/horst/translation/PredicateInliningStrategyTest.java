package secpriv.horst.translation;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import secpriv.horst.data.Predicate;
import secpriv.horst.data.Rule;
import secpriv.horst.tools.TestBuilder;
import secpriv.horst.visitors.VisitorState;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.*;

class PredicateInliningStrategyTest {
    private TestBuilder testBuilder;
    private Predicate aaPredicate;
    private Predicate bbPredicate;
    private Predicate ccPredicate;
    private Predicate ddPredicate;
    private Predicate eePredicate;
    private Predicate ffPredicate;
    private Predicate ggPredicate;

    @BeforeEach
    void setUp() {
        testBuilder = new TestBuilder(new VisitorState());
        aaPredicate = testBuilder.definePredicate("pred Aa{}: int;");
        bbPredicate = testBuilder.definePredicate("pred Bb{}: int;");
        ccPredicate = testBuilder.definePredicate("pred Cc{}: int;");
        ddPredicate = testBuilder.definePredicate("pred Dd{}: int;");
        eePredicate = testBuilder.definePredicate("pred Ee{}: int;");
        ffPredicate = testBuilder.definePredicate("pred Ff{}: int;");
        ggPredicate = testBuilder.definePredicate("pred Gg{}: int;");
    }

    @AfterEach
    void tearDown() {
        testBuilder = null;
    }

    @Test
    void testLinearDeletionStrategy1() {
        List<Rule> rules = new ArrayList<>();
        rules.add(testBuilder.defineRule("rule r0 := clause [?a: int] true   => Aa(?a);"));
        rules.add(testBuilder.defineRule("rule r1 := clause [?a: int] Aa(?a) => Bb(?a);"));
        rules.add(testBuilder.defineRule("rule r2 := clause [?a: int] Bb(?a) => Cc(?a);"));
        rules.add(testBuilder.defineRule("rule r3 := clause [?a: int] Cc(?a) => Dd(?a);"));
        rules.add(testBuilder.defineRule("rule r4 := clause [?a: int] Dd(?a) => Ee(?a);"));
        rules.add(testBuilder.defineRule("rule r5 := clause [?a: int] Ee(?a) => Ff(?a);"));
        rules.add(testBuilder.defineRule("rule r6 := clause [?a: int] Ff(?a) => Gg(?a);"));

        PredicateInliningStrategy.LinearInliningStrategy deletionStrategy = new PredicateInliningStrategy.LinearInliningStrategy();

        List<Predicate> deletionCandidates = deletionStrategy.getInlineCandidates(rules);

        assertThat(deletionCandidates).containsExactly(bbPredicate, ccPredicate, ddPredicate, eePredicate, ffPredicate);
    }

    @Test
    void testLinearDeletionStrategy2() {
        List<Rule> rules = new ArrayList<>();
        rules.add(testBuilder.defineRule("rule r0 := clause [?a: int] true   => Aa(?a);"));
        rules.add(testBuilder.defineRule("rule r1 := clause [?a: int] Aa(?a) => Bb(?a);"));
        rules.add(testBuilder.defineRule("rule r2 := clause [?a: int] Bb(?a) => Cc(?a);"));
        rules.add(testBuilder.defineRule("rule r3 := clause [?a: int] Aa(?a) => Dd(?a);"));
        rules.add(testBuilder.defineRule("rule r4 := clause [?a: int] Dd(?a) => Ee(?a);"));
        rules.add(testBuilder.defineRule("rule r5 := clause [?a: int] Cc(?a) => Ee(?a);"));
        rules.add(testBuilder.defineRule("rule r6 := clause [?a: int] Ee(?a) => Ff(?a);"));
        rules.add(testBuilder.defineRule("rule r7 := clause [?a: int] Ff(?a) => Gg(?a);"));

        PredicateInliningStrategy.LinearInliningStrategy deletionStrategy = new PredicateInliningStrategy.LinearInliningStrategy();

        List<Predicate> deletionCandidates = deletionStrategy.getInlineCandidates(rules);

        deletionCandidates.forEach(p -> System.out.println(p.name));

        assertThat(deletionCandidates).containsExactlyInAnyOrder(bbPredicate, ccPredicate, ddPredicate, ffPredicate);
    }

    @Test
    void testExhaustiveDeletionStrategy1() {
        List<Rule> rules = new ArrayList<>();
        rules.add(testBuilder.defineRule("rule r0 := clause [?a: int] true   => Aa(?a);"));
        rules.add(testBuilder.defineRule("rule r1 := clause [?a: int] Aa(?a) => Bb(?a);"));
        rules.add(testBuilder.defineRule("rule r2 := clause [?a: int] Bb(?a) => Cc(?a);"));
        rules.add(testBuilder.defineRule("rule r3 := clause [?a: int] Aa(?a) => Dd(?a);"));
        rules.add(testBuilder.defineRule("rule r4 := clause [?a: int] Dd(?a) => Ee(?a);"));
        rules.add(testBuilder.defineRule("rule r5 := clause [?a: int] Cc(?a) => Ee(?a);"));
        rules.add(testBuilder.defineRule("rule r6 := clause [?a: int] Ee(?a) => Ff(?a);"));
        rules.add(testBuilder.defineRule("rule r7 := clause [?a: int] Ff(?a) => Gg(?a);"));

        PredicateInliningStrategy.ExhaustiveInliningStrategy deletionStrategy = new PredicateInliningStrategy.ExhaustiveInliningStrategy();

        List<Predicate> deletionCandidates = deletionStrategy.getInlineCandidates(rules);

        deletionCandidates.forEach(p -> System.out.println(p.name));

        assertThat(deletionCandidates).containsSubsequence(aaPredicate, bbPredicate);
        assertThat(deletionCandidates).containsSubsequence(bbPredicate, ccPredicate);
        assertThat(deletionCandidates).containsSubsequence(aaPredicate, ddPredicate);
        assertThat(deletionCandidates).containsSubsequence(ddPredicate, eePredicate);
        assertThat(deletionCandidates).containsSubsequence(ccPredicate, eePredicate);
        assertThat(deletionCandidates).containsSubsequence(eePredicate, ffPredicate);
        assertThat(deletionCandidates).containsSubsequence(ffPredicate, ggPredicate);
    }

    @Test
    void testExhaustiveDeletionStrategy2() {
        List<Rule> rules = new ArrayList<>();
        rules.add(testBuilder.defineRule("rule r0 := clause [?a: int] true   => Aa(?a);"));
        rules.add(testBuilder.defineRule("rule r1 := clause [?a: int] Aa(?a) => Bb(?a);"));
        rules.add(testBuilder.defineRule("rule r2 := clause [?a: int] Bb(?a) => Cc(?a);"));
        rules.add(testBuilder.defineRule("rule r3 := clause [?a: int] Aa(?a) => Dd(?a);"));
        rules.add(testBuilder.defineRule("rule r4 := clause [?a: int] Dd(?a) => Ee(?a);"));
        rules.add(testBuilder.defineRule("rule r5 := clause [?a: int] Cc(?a) => Ee(?a);"));
        rules.add(testBuilder.defineRule("rule r6 := clause [?a: int] Ee(?a) => Ff(?a);"));
        rules.add(testBuilder.defineRule("rule r7 := clause [?a: int] Ff(?a) => Gg(?a);"));
        rules.add(testBuilder.defineRule("rule r8 := clause [?a: int] Gg(?a) => Aa(?a);"));

        PredicateInliningStrategy.ExhaustiveInliningStrategy deletionStrategy = new PredicateInliningStrategy.ExhaustiveInliningStrategy();

        List<Predicate> deletionCandidates = deletionStrategy.getInlineCandidates(rules);

        deletionCandidates.forEach(p -> System.out.println(p.name));

        assertThat(deletionCandidates).containsSubsequence(aaPredicate, bbPredicate);
        assertThat(deletionCandidates).containsSubsequence(bbPredicate, ccPredicate);
        assertThat(deletionCandidates).containsSubsequence(aaPredicate, ddPredicate);
        assertThat(deletionCandidates).containsSubsequence(ddPredicate, eePredicate);
        assertThat(deletionCandidates).containsSubsequence(ccPredicate, eePredicate);
        assertThat(deletionCandidates).containsSubsequence(eePredicate, ffPredicate);
        assertThat(deletionCandidates).containsSubsequence(ffPredicate, ggPredicate);
    }
}