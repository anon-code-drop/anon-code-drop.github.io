package secpriv.horst.tools;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import secpriv.horst.data.BaseTypeValue;
import secpriv.horst.data.Rule;
import secpriv.horst.data.tuples.Tuple2;
import secpriv.horst.internals.SelectorFunctionHelper;
import secpriv.horst.internals.SelectorFunctionInvoker;
import secpriv.horst.translation.visitors.InstantiateParametersRuleVisitor;
import secpriv.horst.visitors.VisitorState;

import java.math.BigInteger;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.*;

class QueryNameParserTest {
    private QueryNameParser parser;
    private TestBuilder testBuilder;
    private InstantiateParametersRuleVisitor instantiateParametersRuleVisitor;
    private SelectorFunctionInvoker selectorFunctionInvoker;

    public class Provider {
        public Iterable<BigInteger> oneToFive() {
            return Stream.of(1, 2, 3, 4, 5).map(BigInteger::valueOf).collect(Collectors.toList());
        }

        public Iterable<Boolean> allBools() {
            return Arrays.asList(false, true);
        }

        public Iterable<Tuple2<BigInteger, Boolean>> intPlusParity(BigInteger b) {
            ArrayList<Tuple2<BigInteger, Boolean>> ret = new ArrayList<>();

            for (int i = 0; i < b.intValue(); ++i) {
                ret.add(new Tuple2<>(BigInteger.valueOf(i), i % 2 == 0));
            }
            return ret;
        }
    }

    @BeforeEach
    public void setUp() {
        VisitorState state = new VisitorState();
        testBuilder = new TestBuilder(state);
        SelectorFunctionHelper selectorFunctionHelper = new SelectorFunctionHelper();
        selectorFunctionHelper.registerProvider(new Provider());
        state.setSelectorFunctionHelper(selectorFunctionHelper);
        selectorFunctionInvoker = new SelectorFunctionInvoker(selectorFunctionHelper);
        instantiateParametersRuleVisitor = new InstantiateParametersRuleVisitor(selectorFunctionInvoker);

        testBuilder.defineSelectorFunction("sel oneToFive: unit -> [int];");
        testBuilder.defineSelectorFunction("sel allBools: unit -> [bool];");
        testBuilder.defineSelectorFunction("sel intPlusParity: int -> [int*bool];");

        testBuilder.definePredicate("pred FunnyFun{} : int;");
    }

    @AfterEach
    public void tearDown() {
        parser = null;
        parser = null;
        instantiateParametersRuleVisitor = null;
        selectorFunctionInvoker = null;
    }

    @Test
    public void unitRuleCanBeUsedButThrowsWhenAskedToGetParameter() {
        String s = "rule unitRule :=   \n" +
                "clause [?i : int]  \n" +
                "FunnyFun(?i)       \n" +
                "=> FunnyFun(?i+1)  \n" +
                ";";

        Rule rule = testBuilder.defineRule(s);
        parser = new QueryNameParser(Collections.singletonList(rule));

        for(Rule instantiatedRule : rule.accept(instantiateParametersRuleVisitor)) {
            assertThatThrownBy(() -> parser.getIntParameter(instantiatedRule.name, "!a")).isInstanceOf(IllegalArgumentException.class);
        }
    }

    @Test
    public void ruleHasToBeRegistered() {
        String s = "rule unitRule :=   \n" +
                "clause [?i : int]  \n" +
                "FunnyFun(?i)       \n" +
                "=> FunnyFun(?i+1)  \n" +
                ";";

        Rule rule = testBuilder.defineRule(s);
        parser = new QueryNameParser(Collections.singletonList(rule));

        assertThatThrownBy(() -> parser.getIntParameter("imNotRegistered", "!a")).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void testGetBoolParameter() {
        String s = "rule boolRule :=   \n" +
                "for (!a:bool) in allBools()\n" +
                "clause [?i : int]  \n" +
                "!a,                \n" +
                "FunnyFun(?i)       \n" +
                "=> FunnyFun(?i+1)  \n" +
                ";";
        Rule rule = testBuilder.defineRule(s);
        parser = new QueryNameParser(Collections.singletonList(rule));

        List<Rule> instantiatedRules = rule.accept(instantiateParametersRuleVisitor);

        assertThat(parser.getBoolParameter(instantiatedRules.get(0).name, "!a")).isFalse();
        assertThat(parser.getBoolParameter(instantiatedRules.get(1).name, "!a")).isTrue();

        assertThatThrownBy(() -> parser.getIntParameter(instantiatedRules.get(0).name, "!a")).isInstanceOf(NumberFormatException.class);
        assertThatThrownBy(() -> parser.getIntParameter(instantiatedRules.get(1).name, "!a")).isInstanceOf(NumberFormatException.class);
    }

    @Test
    public void testGetIntParameter() {
        String s = "rule intRule :=   \n" +
                "for (!a:int) in oneToFive()\n" +
                "clause [?i : int]  \n" +
                "!a = 1,                \n" +
                "FunnyFun(?i)       \n" +
                "=> FunnyFun(?i+1)  \n" +
                ";";
        Rule rule = testBuilder.defineRule(s);
        parser = new QueryNameParser(Collections.singletonList(rule));

        List<Rule> instantiatedRules = rule.accept(instantiateParametersRuleVisitor);

        for(int i = 1; i <=5; ++i) {
            assertThat(parser.getIntParameter(instantiatedRules.get(i-1).name, "!a")).isEqualTo(i);
        }

        for(int i = 1; i <=5; ++i) {
            assertThatThrownBy(() -> parser.getBoolParameter(instantiatedRules.get(0).name, "!a")).isInstanceOf(IllegalArgumentException.class);
        }
    }

    @Test
    public void testCompoundInvocation() {
        String s = "rule compoundRule :=   \n" +
                "for (!a:int) in oneToFive(),\n" +
                "(!b:bool) in allBools(),\n" +
                "(!i:int, !p:bool) in intPlusParity(5)\n" +
                "clause [?i : int]  \n" +
                "!a = 1,                \n" +
                "FunnyFun(?i)       \n" +
                "=> FunnyFun(?i+1)  \n" +
                ";";

        Rule rule = testBuilder.defineRule(s);
        parser = new QueryNameParser(Collections.singletonList(rule));

        List<Rule> instantiatedRules = rule.accept(instantiateParametersRuleVisitor);

        class AssertionBaseTypeVisitor implements BaseTypeValue.Visitor<Void> {
            private final String ruleName;
            private final String parameterName;

            private AssertionBaseTypeVisitor(String ruleName, String parameterName) {
                this.ruleName = ruleName;
                this.parameterName = parameterName;
            }

            @Override
            public Void visit(BaseTypeValue.BaseTypeIntegerValue baseTypeValue) {
                assertThat(parser.getIntParameter(ruleName, parameterName)).isEqualTo(baseTypeValue.value);
                return null;
            }

            @Override
            public Void visit(BaseTypeValue.BaseTypeBooleanValue baseTypeValue) {
                assertThat(parser.getBoolParameter(ruleName, parameterName)).isEqualTo(baseTypeValue.value);
                return null;
            }

            @Override
            public Void visit(BaseTypeValue.BaseTypeArrayValue baseTypeValue) {
                throw  new UnsupportedOperationException();
            }
        }

        int i = 0;

        for(Map<String, BaseTypeValue> mapping : selectorFunctionInvoker.invoke(rule.selectorFunctionInvocation)) {
            for(Map.Entry<String, BaseTypeValue> entry : mapping.entrySet()) {
                entry.getValue().accept(new AssertionBaseTypeVisitor(instantiatedRules.get(i).name, entry.getKey()));
            }
            ++i;
        }
    }
}