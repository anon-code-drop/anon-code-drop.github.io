package secpriv.horst.evm;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigInteger;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class JumpMapTest {
    private JumpMap jumpMap;

    @BeforeEach
    public void setUp() {
        Map<BigInteger, List<BigInteger>> possibleJumps = new HashMap<>();
        Map<BigInteger, List<BigInteger>> provenJumps = new HashMap<>();
        for (int i = 1; i < 4; ++i) {
            int finalI = i;
            possibleJumps.put(BigInteger.valueOf(i), Stream.of(1, 3, 5, 7).map(j -> j * finalI).map(BigInteger::valueOf).collect(Collectors.toList()));
        }

        possibleJumps.put(BigInteger.valueOf(55), Collections.singletonList(BigInteger.valueOf(77)));
        provenJumps.put(BigInteger.valueOf(55), Collections.singletonList(BigInteger.valueOf(77)));

        jumpMap = new JumpMap(possibleJumps, provenJumps);
    }

    @AfterEach
    public void tearDown() {
        jumpMap = null;
    }

    @Test
    public void testSimpleUndeterminedCount() {
        assertThat(jumpMap.getUndeterminedCount()).isEqualTo(12);
    }

    @Test
    public void testIsJumpUniquelyDetermined1() {
        assertThat(jumpMap.isJumpUniquelyDetermined(BigInteger.valueOf(55))).isTrue();
    }

    @Test
    public void testIsJumpUniquelyDetermined2() {
        assertThat(jumpMap.isJumpUniquelyDetermined(BigInteger.valueOf(3))).isFalse();
    }

    @Test
    public void testIsJumpUniquelyDetermined3() {
        assertThatThrownBy(() -> jumpMap.isJumpUniquelyDetermined(BigInteger.valueOf(22))).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void testUndeterminedCountAfterRemovedPossibility() {
        jumpMap.removePossibility(BigInteger.valueOf(1), BigInteger.valueOf(1));
        assertThat(jumpMap.getUndeterminedCount()).isEqualTo(11);
    }

    @Test
    public void testUndeterminedCountAfterUniquenessProof() {
        jumpMap.addProve(BigInteger.valueOf(2), BigInteger.valueOf(2));
        jumpMap.addUniquenessProof(BigInteger.valueOf(2));
        assertThat(jumpMap.getUndeterminedCount()).isEqualTo(8);
    }

    @Test
    public void testUniquenessProofThrowsIfNothingIsProven() {
        assertThatThrownBy(() -> jumpMap.addUniquenessProof(BigInteger.valueOf(2))).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void testAddProveThrowsOnImpossible1() {
        assertThatThrownBy(() -> jumpMap.addProve(BigInteger.valueOf(2), BigInteger.valueOf(100))).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void testAddProveThrowsOnImpossible2() {
        assertThatThrownBy(() -> jumpMap.addProve(BigInteger.valueOf(100), BigInteger.valueOf(100))).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void testIsJumpProven1() {
        assertThat(jumpMap.isJumpProven(BigInteger.valueOf(55), BigInteger.valueOf(77))).isTrue();
    }

    @Test
    public void testIsJumpProven2() {
        assertThat(jumpMap.isJumpProven(BigInteger.valueOf(1), BigInteger.valueOf(1))).isFalse();
    }

    @Test
    public void testUniquenessCandidates1() {
        Collection<BigInteger> candidates = jumpMap.getUniquenessTestCandidates();
        assertThat(candidates).isEmpty();
    }

    @Test
    public void testUniquenessCandidates2() {
        jumpMap.addProve(BigInteger.valueOf(1), BigInteger.valueOf(7));
        Collection<BigInteger> candidates = jumpMap.getUniquenessTestCandidates();
        assertThat(candidates).hasSize(1);
        assertThat(candidates.stream().findFirst().get()).isEqualTo(BigInteger.ONE);
    }

    @Test
    public void testUniquenessCandidates3() {
        jumpMap.addProve(BigInteger.valueOf(1), BigInteger.valueOf(7));
        jumpMap.addUniquenessProof(BigInteger.valueOf(1));
        Collection<BigInteger> candidates = jumpMap.getUniquenessTestCandidates();
        assertThat(candidates).isEmpty();
    }

    @Test
    public void testUniquenessCandidates4() {
        jumpMap.addProve(BigInteger.valueOf(1), BigInteger.valueOf(7));
        jumpMap.removePossibility(BigInteger.valueOf(1), BigInteger.valueOf(3));
        jumpMap.removePossibility(BigInteger.valueOf(1), BigInteger.valueOf(1));
        Collection<BigInteger> candidates = jumpMap.getUniquenessTestCandidates();
        assertThat(candidates).hasSize(1);
        assertThat(candidates.stream().findFirst().get()).isEqualTo(BigInteger.ONE);

        jumpMap.addAmbiguityProof(BigInteger.valueOf(1));

        candidates = jumpMap.getUniquenessTestCandidates();
        assertThat(candidates).isEmpty();

        jumpMap.addProve(BigInteger.valueOf(1), BigInteger.valueOf(5));
        candidates = jumpMap.getUniquenessTestCandidates();
        assertThat(candidates).isEmpty();
    }

    @Test
    public void testUniquenessCandidates5() {
        jumpMap.addProve(BigInteger.valueOf(1), BigInteger.valueOf(7));
        jumpMap.removePossibility(BigInteger.valueOf(1), BigInteger.valueOf(3));
        jumpMap.removePossibility(BigInteger.valueOf(1), BigInteger.valueOf(1));
        Collection<BigInteger> candidates = jumpMap.getUniquenessTestCandidates();
        assertThat(candidates).hasSize(1);
        assertThat(candidates.stream().findFirst().get()).isEqualTo(BigInteger.ONE);

        jumpMap.addAmbiguityProof(BigInteger.valueOf(1));

        candidates = jumpMap.getUniquenessTestCandidates();
        assertThat(candidates).isEmpty();

        jumpMap.removePossibility(BigInteger.valueOf(1), BigInteger.valueOf(5));
        candidates = jumpMap.getUniquenessTestCandidates();
        assertThat(candidates).isEmpty();
    }

    @Test
    public void testUniquenessCandidates6() {
        jumpMap.addProve(BigInteger.valueOf(1), BigInteger.valueOf(7));
        jumpMap.removePossibility(BigInteger.valueOf(1), BigInteger.valueOf(3));
        Collection<BigInteger> candidates = jumpMap.getUniquenessTestCandidates();
        assertThat(candidates).hasSize(1);
        assertThat(candidates.stream().findFirst().get()).isEqualTo(BigInteger.ONE);

        jumpMap.addAmbiguityProof(BigInteger.valueOf(1));

        candidates = jumpMap.getUniquenessTestCandidates();
        assertThat(candidates).isEmpty();

        jumpMap.removePossibility(BigInteger.valueOf(1), BigInteger.valueOf(1));

        candidates = jumpMap.getUniquenessTestCandidates();
        assertThat(candidates).isEmpty();

        jumpMap.removePossibility(BigInteger.valueOf(1), BigInteger.valueOf(5));
        candidates = jumpMap.getUniquenessTestCandidates();
        assertThat(candidates).isEmpty();
    }

    @Test
    public void testUniquenessCandidates7() {
        jumpMap.addProve(BigInteger.valueOf(1), BigInteger.valueOf(7));
        jumpMap.removePossibility(BigInteger.valueOf(1), BigInteger.valueOf(3));
        Collection<BigInteger> candidates = jumpMap.getUniquenessTestCandidates();
        assertThat(candidates).hasSize(1);
        assertThat(candidates.stream().findFirst().get()).isEqualTo(BigInteger.ONE);

        jumpMap.addAmbiguityProof(BigInteger.valueOf(1));

        candidates = jumpMap.getUniquenessTestCandidates();
        assertThat(candidates).isEmpty();

        jumpMap.addProve(BigInteger.valueOf(1), BigInteger.valueOf(1));

        candidates = jumpMap.getUniquenessTestCandidates();
        assertThat(candidates).hasSize(1);
        assertThat(candidates.stream().findFirst().get()).isEqualTo(BigInteger.ONE);

        jumpMap.removePossibility(BigInteger.valueOf(1), BigInteger.valueOf(5));
        candidates = jumpMap.getUniquenessTestCandidates();
        assertThat(candidates).isEmpty();
    }

    @Test
    void testConstructorDoesNotThrowValidInvariants() {
        Map<BigInteger, List<BigInteger>> possibleJumps = new HashMap<>();
        Map<BigInteger, List<BigInteger>> provenJumps = new HashMap<>();

        provenJumps.put(BigInteger.ONE, Collections.singletonList(BigInteger.ONE));
        possibleJumps.put(BigInteger.ONE, Stream.of(BigInteger.ONE, BigInteger.TEN).collect(Collectors.toList()));

        assertThatCode(() -> new JumpMap(possibleJumps, provenJumps)).doesNotThrowAnyException();;
    }

    @Test
    void testConstructorDoesNotThrowDifferentlyOrderedLists() {
        Map<BigInteger, List<BigInteger>> possibleJumps = new HashMap<>();
        Map<BigInteger, List<BigInteger>> provenJumps = new HashMap<>();

        possibleJumps.put(BigInteger.ONE, Stream.of(BigInteger.ONE, BigInteger.TEN).collect(Collectors.toList()));
        provenJumps.put(BigInteger.ONE, Stream.of(BigInteger.TEN, BigInteger.ONE).collect(Collectors.toList()));

        assertThatCode(() -> new JumpMap(possibleJumps, provenJumps)).doesNotThrowAnyException();;
    }
}