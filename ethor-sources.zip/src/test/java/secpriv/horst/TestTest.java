package secpriv.horst;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.*;

class TestTest {
    @Test
    public void test() {
        assertThat(2).isBetween(1,3);
    }
}