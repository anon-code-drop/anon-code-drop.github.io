package secpriv.horst.internals.error.handling;

import secpriv.horst.internals.error.objects.Error;

public interface ErrorHandler {

     void handleError(Error error);
}
