package secpriv.horst.visitors;

import secpriv.horst.data.Rule;

public interface RuleTypeOracle {
    boolean isTest(Rule rule);

    boolean isQueryOrTest(Rule rule);

    boolean isExpectedTestResult(Rule test, VisitorState.TestResult result);
}
