package secpriv.horst.visitors;

import secpriv.horst.data.*;
import secpriv.horst.parser.ASBaseVisitor;
import secpriv.horst.parser.ASParser;
import secpriv.horst.types.Type;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static secpriv.horst.tools.OptionalHelper.listOfNonEmptyListsToNonEmptyList;

public class TestOrQueryVisitor extends ASBaseVisitor<Optional<Rule>> {
    private final VisitorState state;

    public TestOrQueryVisitor(VisitorState state) {
        this.state = state;
    }

    private Optional<Rule> queryBodyToRule(ASParser.QueryBodyContext ctx, String id) {
        Map<String, Type> freeVars = Collections.emptyMap();

        if (ctx.freeVars() != null) {
            Optional<Map<String, Type>> optFreeVars = ctx.freeVars().accept(new FreeVarsVisitor(state));
            if (!optFreeVars.isPresent()) {
                return Optional.empty();
            } else {
                freeVars = optFreeVars.get();
            }
        }

        CompoundSelectorFunctionInvocation selectorFunctionInvocation = CompoundSelectorFunctionInvocation.UnitInvocation;
        VisitorState childState = new VisitorState(state);

        if (ctx.selectorExp() != null) {
            Optional<CompoundSelectorFunctionInvocation> optSelectorExp = ctx.selectorExp().accept(new CompoundSelectorFunctionInvocationVisitor(childState));

            if (!optSelectorExp.isPresent()) {
                return Optional.empty();
            }
            selectorFunctionInvocation = optSelectorExp.get();
        }

        for (String k : freeVars.keySet()) {
            childState.defineFreeVar(k, freeVars.get(k));
        }

        PropositionVisitor propositionVisitor = new PropositionVisitor(childState);

        List<List<Proposition>> listOfLists = ctx.prems().prop().stream().map(propositionVisitor::visit).collect(Collectors.toList());
        List<Proposition> premises = listOfNonEmptyListsToNonEmptyList(listOfLists);

        if (premises.isEmpty()) {
            //TODO handle error?
            return Optional.empty();
        }

        List<Type> parameterTypes = selectorFunctionInvocation.parameters().stream().map(Expression.VariableReferenceExpression::getType).collect(Collectors.toList());
        Predicate queryPredicate = new Predicate(id, parameterTypes, Collections.emptyList());
        if (!state.definePredicate(queryPredicate)) {
            //TODO report error
            return Optional.empty();
        }

        Clause queryAsClause = new Clause(premises, new Proposition.PredicateProposition(queryPredicate, Collections.unmodifiableList(selectorFunctionInvocation.parameters()), Collections.emptyList()), freeVars);
        return Optional.of(new Rule(id, selectorFunctionInvocation, Collections.singletonList(queryAsClause)));
    }

    @Override
    public Optional<Rule> visitQuery(ASParser.QueryContext ctx) {
        String queryId = ctx.queryID().ID().getText();
        return  queryBodyToRule(ctx.queryBody(), queryId);
    }

    @Override
    public Optional<Rule> visitTest(ASParser.TestContext ctx) {
        String testId = ctx.testID().ID().getText();
        return queryBodyToRule(ctx.queryBody(), testId);
    }

}
