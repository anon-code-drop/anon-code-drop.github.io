package secpriv.horst.data;

import secpriv.horst.translation.visitors.DefaultValueExpressionVisitor;
import secpriv.horst.types.Type;

import java.math.BigInteger;
import java.util.*;

public abstract class ExpressionView {
    public final Expression expression;

    private ExpressionView(Expression expression) {
        this.expression = Objects.requireNonNull(expression, "Cannot view null as Expression!");
    }

    public static Optional<Equality> viewAsEquality(Expression expression) {
        Optional<SimpleEquality> ret1 = viewAsSimpleEquality(expression);
        if (ret1.isPresent()) {
            return Optional.of(ret1.get());
        }


        Optional<SimpleSelectEquality> ret2 = viewAsSimpleSelectEquality(expression);
        if (ret2.isPresent()) {
            return Optional.of(ret2.get());
        }

        return Optional.empty();
    }

    public static boolean isSimpleAdditiveTerm(Expression expression) {
        if (expression instanceof Expression.IntConst) {
            return true;
        }

        if (expression instanceof Expression.FreeVarExpression) {
            return true;
        }

        if (!(expression instanceof Expression.BinaryIntExpression)) {
            return false;
        }
        if (((Expression.BinaryIntExpression) expression).operation != Expression.IntOperation.ADD &&
                ((Expression.BinaryIntExpression) expression).operation != Expression.IntOperation.SUB) {
            return false;
        }
        if (((Expression.BinaryIntExpression) expression).expression1 instanceof Expression.IntConst == ((Expression.BinaryIntExpression) expression).expression2 instanceof Expression.IntConst) {
            return false;
        }
        return ((Expression.BinaryIntExpression) expression).expression1 instanceof Expression.FreeVarExpression != ((Expression.BinaryIntExpression) expression).expression2 instanceof Expression.FreeVarExpression;
    }

    public static class SimpleAdditiveTerm extends ExpressionView {
        private static final Expression.FreeVarExpression NO_FREEVAR = new Expression.FreeVarExpression(Type.Integer, "NOFREEVAR");

        public SimpleAdditiveTerm(Expression expression) {
            super(expression);

            if (!isSimpleAdditiveTerm(expression)) {
                throw new IllegalArgumentException("Viewed expression must be binary int expression of IntConst and FreeVar, joined with + or -!");
            }
        }

        public boolean isComparable(SimpleAdditiveTerm e) {
            Optional<Expression.FreeVarExpression> optFreeVar1 = this.maybeGetFreeVar();
            Optional<Expression.FreeVarExpression> optFreeVar2 = e.maybeGetFreeVar();

            if (optFreeVar1.isPresent() && optFreeVar2.isPresent()) {
                return optFreeVar1.get().equals(optFreeVar2.get());
            }

            return !optFreeVar1.isPresent() && !optFreeVar2.isPresent();
        }


        //TODO improve
        @Override
        public String toString() {
            if (isFreeVarNegated()) {
                return getSummand().value + " " + getOperation() + " " + getFreeVar().name;
            } else {
                return getFreeVar().name + " " + getOperation() + " " + getSummand().value;
            }
        }

        public Expression.FreeVarExpression getFreeVar() {
            if (expression instanceof Expression.BinaryIntExpression) {
                Expression.BinaryIntExpression expression = ((Expression.BinaryIntExpression) this.expression);

                return (Expression.FreeVarExpression) (expression.expression1 instanceof Expression.FreeVarExpression ? expression.expression1 : expression.expression2);
            }
            if (expression instanceof Expression.FreeVarExpression) {
                return (Expression.FreeVarExpression) expression;
            }

            if (expression instanceof Expression.IntConst) {
                return NO_FREEVAR;
            }

            throw new RuntimeException("Unreachable code!");
        }


        public Expression.IntConst getSummand() {
            if (expression instanceof Expression.BinaryIntExpression) {
                Expression.BinaryIntExpression expression = ((Expression.BinaryIntExpression) this.expression);

                return (Expression.IntConst) (expression.expression1 instanceof Expression.IntConst ? expression.expression1 : expression.expression2);
            }
            if (expression instanceof Expression.FreeVarExpression) {
                return new Expression.IntConst(BigInteger.ZERO);
            }
            if (expression instanceof Expression.IntConst) {
                return (Expression.IntConst) expression;
            }

            throw new RuntimeException("Unreachable code!");
        }

        public Expression.IntOperation getOperation() {
            if (expression instanceof Expression.BinaryIntExpression) {
                return ((Expression.BinaryIntExpression) expression).operation;
            }
            return Expression.IntOperation.ADD;
        }

        public boolean isFreeVarNegated() {
            if (expression instanceof Expression.BinaryIntExpression) {
                if (((Expression.BinaryIntExpression) expression).operation == Expression.IntOperation.SUB) {
                    return ((Expression.BinaryIntExpression) expression).expression2 instanceof Expression.FreeVarExpression;
                }
            }

            return false;
        }

        public BigInteger getNormalizedSummand() {
            if (expression instanceof Expression.BinaryIntExpression) {
                Expression.BinaryIntExpression expression = ((Expression.BinaryIntExpression) this.expression);

                if(expression.expression1 instanceof Expression.IntConst) {
                    return ((Expression.IntConst) expression.expression1).value;
                } else {
                    BigInteger tmp = ((Expression.IntConst) expression.expression2).value;

                    return getOperation() == Expression.IntOperation.ADD ? tmp : tmp.negate();
                }
            }

            if (expression instanceof Expression.FreeVarExpression) {
                return BigInteger.ZERO;
            }
            if (expression instanceof Expression.IntConst) {
                return  ((Expression.IntConst) expression).value;
            }

            throw new RuntimeException("Unreachable code!");
        }


        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }

            if (this.getClass() != o.getClass()) {
                return false;
            }

            SimpleAdditiveTerm oSimpleAdditiveTerm = (SimpleAdditiveTerm) o;

            return (isFreeVarNegated() == oSimpleAdditiveTerm.isFreeVarNegated()) && getNormalizedSummand().equals(oSimpleAdditiveTerm.getNormalizedSummand()) && getFreeVar().equals(oSimpleAdditiveTerm.getFreeVar());
        }

        @Override
        public int hashCode() {
            return Objects.hash(getNormalizedSummand(), this.getFreeVar(), this.isFreeVarNegated());
        }

        public Optional<Expression.FreeVarExpression> maybeGetFreeVar() {
            return getFreeVar().equals(NO_FREEVAR) ? Optional.empty() : Optional.of(getFreeVar());
        }
    }

    public static abstract class SimpleEquality extends ExpressionView implements Equality {
        private SimpleEquality(Expression expression) {
            super(expression);
        }

        public abstract Expression.FreeVarExpression getFreeVar();

        public abstract Expression getValue();

        public Expression getEquality() {
            return expression;
        }

        @Override
        public boolean isComparable(Equality e) {
            return ExpressionView.viewAsSimpleEquality(e.getEquality()).map(s -> s.getFreeVar().equals(this.getFreeVar())).orElse(false);
        }

        private static class ComparisonEquality extends SimpleEquality {
            private ComparisonEquality(Expression expression) {
                super(expression);
            }

            public Expression.FreeVarExpression getFreeVar() {
                Expression.ComparisonExpression comparisonExpression = (Expression.ComparisonExpression) expression;
                return (Expression.FreeVarExpression) (comparisonExpression.expression1 instanceof Expression.FreeVarExpression ?
                        comparisonExpression.expression1 : comparisonExpression.expression2);
            }

            public Expression getValue() {
                Expression.ComparisonExpression comparisonExpression = (Expression.ComparisonExpression) expression;
                return comparisonExpression.expression1 instanceof Expression.FreeVarExpression ?
                        comparisonExpression.expression2 : comparisonExpression.expression1;
            }
        }

        private static class BooleanEquality extends SimpleEquality {
            private BooleanEquality(Expression expression) {
                super(expression);
            }

            public Expression.FreeVarExpression getFreeVar() {
                if (expression instanceof Expression.NegationExpression) {
                    return (Expression.FreeVarExpression) ((Expression.NegationExpression) expression).expression;
                }
                return (Expression.FreeVarExpression) expression;
            }

            public Expression getValue() {
                return expression instanceof Expression.NegationExpression ? Expression.BoolConst.FALSE : Expression.BoolConst.TRUE;
            }
        }
    }

    public static class FreeVarEquality extends ExpressionView {
        private FreeVarEquality(Expression expression) {
            super(expression);
            if (!ExpressionView.isFreeVarEquality(expression)) {
                throw new IllegalArgumentException("Expression has to be of the form free variable = free variable!");
            }
        }

        public Expression.FreeVarExpression getFirstFreeVar() {
            Expression.ComparisonExpression comparisonExpression = (Expression.ComparisonExpression) expression;
            return (Expression.FreeVarExpression) comparisonExpression.expression1;
        }

        public Expression.FreeVarExpression getSecondFreeVar() {
            Expression.ComparisonExpression comparisonExpression = (Expression.ComparisonExpression) expression;
            return (Expression.FreeVarExpression) comparisonExpression.expression2;
        }
    }

    private static boolean isSimpleEquality(Expression expression) {
        if (expression instanceof Expression.ComparisonExpression) {
            Expression.ComparisonExpression comparisionExpression = (Expression.ComparisonExpression) expression;
            if (comparisionExpression.operation == Expression.CompOperation.EQ) {
                return comparisionExpression.expression1 instanceof Expression.FreeVarExpression ^ comparisionExpression.expression2 instanceof Expression.FreeVarExpression;
            }
        }

        return false;
    }

    private static boolean isFreeVarEquality(Expression expression) {
        if (expression instanceof Expression.ComparisonExpression) {
            Expression.ComparisonExpression comparisionExpression = (Expression.ComparisonExpression) expression;
            if (comparisionExpression.operation == Expression.CompOperation.EQ) {
                boolean ret = comparisionExpression.expression1 instanceof Expression.FreeVarExpression && comparisionExpression.expression2 instanceof Expression.FreeVarExpression;

                return ret;
            }
        }

        return false;
    }

    public static Optional<SimpleEquality> viewAsSimpleEquality(Expression expression) {
        class ViewAsSimpleEqualityVisitor extends DefaultValueExpressionVisitor<Optional<SimpleEquality>> {
            private ViewAsSimpleEqualityVisitor() {
                super(Optional.empty());
            }

            @Override
            public Optional<SimpleEquality> visit(Expression.FreeVarExpression expression) {
                if (expression.getType() == Type.Boolean) {
                    return Optional.of(new SimpleEquality.BooleanEquality(expression));
                }
                return Optional.empty();
            }

            @Override
            public Optional<SimpleEquality> visit(Expression.NegationExpression expression) {
                if (expression.expression instanceof Expression.FreeVarExpression) {
                    return Optional.of(new SimpleEquality.BooleanEquality(expression));
                }
                return Optional.empty();
            }

            @Override
            public Optional<SimpleEquality> visit(Expression.ComparisonExpression expression) {
                if (expression.operation == Expression.CompOperation.EQ) {
                    if (expression.expression1 instanceof Expression.FreeVarExpression ^ expression.expression2 instanceof Expression.FreeVarExpression) {
                        return Optional.of(new SimpleEquality.ComparisonEquality(expression));
                    }
                }
                return Optional.empty();
            }
        }

        return expression.accept(new ViewAsSimpleEqualityVisitor());
    }

    public static Optional<FreeVarEquality> viewAsFreeVarEquality(Expression expression) {
        if (isFreeVarEquality(expression)) {
            return Optional.of(new FreeVarEquality(expression));
        }
        return Optional.empty();
    }

    public static abstract class SimpleArray extends ExpressionView {
        private SimpleArray(Expression expression) {
            super(expression);
        }

        public abstract Optional<SimpleArray> write(Expression viewedExpression, SimpleAdditiveTerm index, Expression value);

        public abstract Expression optimize();

        abstract Expression optimize(Set<SimpleAdditiveTerm> writes);

        public abstract Optional<Expression> getDefaultValue();

        public abstract Expression select(SimpleAdditiveTerm indexView);

        public abstract boolean isIndexCompatible(SimpleAdditiveTerm simpleAdditiveTerm);

        public abstract boolean isIndexCompatible(SimpleArray otherArray);

        private static class SimpleBaseArray extends SimpleArray {
            public SimpleBaseArray(Expression expression) {
                super(expression);
            }

            @Override
            public Optional<SimpleArray> write(Expression viewedExpression, SimpleAdditiveTerm index, Expression value) {
                return Optional.of(new SimpleWriteArray(viewedExpression, this, index, value));
            }

            @Override
            public Expression optimize() {
                return expression;
            }

            @Override
            Expression optimize(Set<SimpleAdditiveTerm> writes) {
                return expression;
            }

            @Override
            public Optional<Expression> getDefaultValue() {
                if (expression instanceof Expression.ArrayInitExpression) {
                    return Optional.of(((Expression.ArrayInitExpression) expression).initializer);
                }
                return Optional.empty();
            }

            @Override
            public Expression select(SimpleAdditiveTerm indexView) {
                return getDefaultValue().orElse(new Expression.SelectExpression(expression, indexView.expression));
            }

            @Override
            public boolean isIndexCompatible(SimpleAdditiveTerm simpleAdditiveTerm) {
                return true;
            }

            @Override
            public boolean isIndexCompatible(SimpleArray otherArray) {
                return true;
            }
        }

        private static class SimpleWriteArray extends SimpleArray {
            final SimpleArray base;
            final SimpleAdditiveTerm index;
            final Expression value;

            private SimpleWriteArray(Expression expression, SimpleArray base, SimpleAdditiveTerm index, Expression value) {
                super(expression);
                this.base = Objects.requireNonNull(base);
                this.index = Objects.requireNonNull(index);
                this.value = Objects.requireNonNull(value);
            }

            @Override
            public Optional<SimpleArray> write(Expression viewedExpression, SimpleAdditiveTerm index, Expression value) {
                if (this.index.isComparable(index)) {
                    return Optional.of(new SimpleWriteArray(viewedExpression, this, index, value));
                }
                return Optional.empty();
            }

            @Override
            public Expression optimize() {
                Set<SimpleAdditiveTerm> writes = new HashSet<>();
                return this.optimize(writes);
            }

            @Override
            Expression optimize(Set<SimpleAdditiveTerm> writes) {
                // if a write further above in the expression tree occurs, ignore this write
                if (!writes.contains(index)) {
                    writes.add(index);
                    Expression ret = base.optimize(writes);

                    // if a write writes the same value as the default value, ignore this write
                    if (getDefaultValue().map(v -> !v.equals(value)).orElse(true)) {
                        return new Expression.StoreExpression(ret, index.expression, value);
                    } else {
                        return ret;
                    }
                }

                return base.optimize(writes);
            }

            @Override
            public Optional<Expression> getDefaultValue() {
                return base.getDefaultValue();
            }

            @Override
            public Expression select(SimpleAdditiveTerm indexView) {
                if (indexView.equals(index)) {
                    return value;
                }
                return base.select(indexView);
            }

            @Override
            public boolean isIndexCompatible(SimpleAdditiveTerm simpleAdditiveTerm) {
                return index.isComparable(simpleAdditiveTerm);
            }

            @Override
            public boolean isIndexCompatible(SimpleArray otherArray) {
                return otherArray.isIndexCompatible(index);
            }
        }
    }

    public static class SimpleSelect extends ExpressionView {
        private SimpleSelect(Expression expression) {
            super(expression);
            if (!isSimpleSelect(expression)) {
                throw new IllegalArgumentException();
            }
        }

        private static boolean isSimpleSelect(Expression expression) {
            if (expression instanceof Expression.SelectExpression) {
                if (((Expression.SelectExpression) expression).expression1 instanceof Expression.FreeVarExpression) {
                    return isSimpleAdditiveTerm(((Expression.SelectExpression) expression).expression2);
                }
            }
            return false;
        }

        public Expression.FreeVarExpression getBase() {
            return (Expression.FreeVarExpression) ((Expression.SelectExpression) expression).expression1;
        }

        public SimpleAdditiveTerm getIndex() {
            return viewAsSimpleAdditiveTerm(((Expression.SelectExpression) expression).expression2).get();
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }

            if (o.getClass() != getClass()) {
                return false;
            }

            SimpleSelect oStimpleSelect = (SimpleSelect) o;
            return oStimpleSelect.getBase().equals(getBase()) && oStimpleSelect.getIndex().equals(getIndex());
        }

        public boolean isComparable(SimpleSelect other) {
            return this.getIndex().isComparable(other.getIndex()) && this.getBase().equals(other.getBase());
        }
    }

    public interface Equality {
        Expression getValue();

        Expression getEquality();

        boolean isComparable(Equality e);
    }

    public static class SimpleSelectEquality extends ExpressionView implements Equality {
        private SimpleSelectEquality(Expression expression) {
            super(expression);
            if (!isSimpleSelectEquality(expression)) {
                throw new IllegalArgumentException();
            }
        }


        private static boolean isSimpleSelectEquality(Expression expression) {
            if (expression instanceof Expression.ComparisonExpression) {
                if (((Expression.ComparisonExpression) expression).operation == Expression.CompOperation.EQ) {
                    Expression expression1 = ((Expression.ComparisonExpression) expression).expression1;
                    Expression expression2 = ((Expression.ComparisonExpression) expression).expression2;

                    return (SimpleSelect.isSimpleSelect(expression1) ^ SimpleSelect.isSimpleSelect(expression2));
                }
            }
            return false;
        }

        public SimpleSelect getSelect() {
            Expression expression1 = ((Expression.ComparisonExpression) expression).expression1;
            Expression expression2 = ((Expression.ComparisonExpression) expression).expression2;
            return SimpleSelect.viewAsSimpleSelect(expression1).orElseGet(() -> ExpressionView.viewAsSimpleSelect(expression2).get());
        }

        @Override
        public Expression getValue() {
            Expression expression1 = ((Expression.ComparisonExpression) expression).expression1;
            Expression expression2 = ((Expression.ComparisonExpression) expression).expression2;
            return SimpleSelect.isSimpleSelect(expression1) ? expression2 : expression1;
        }

        @Override
        public Expression getEquality() {
            return expression;
        }

        @Override
        public boolean isComparable(Equality e) {
            return ExpressionView.viewAsSimpleSelectEquality(e.getEquality()).map(s -> s.getSelect().isComparable(this.getSelect())).orElse(false);
        }
    }


    public static Optional<SimpleSelect> viewAsSimpleSelect(Expression expression) {
        if (SimpleSelect.isSimpleSelect(expression)) {
            return Optional.of(new SimpleSelect(expression));
        }
        return Optional.empty();
    }


    public static Optional<SimpleSelectEquality> viewAsSimpleSelectEquality(Expression expression) {
        if (SimpleSelectEquality.isSimpleSelectEquality(expression)) {
            return Optional.of(new SimpleSelectEquality(expression));
        }
        return Optional.empty();
    }


    public static Optional<SimpleArray> viewAsSimpleArray(Expression expression) {
        class IsSimpleArrayExpressionVisitor extends DefaultValueExpressionVisitor<Optional<SimpleArray>> {
            private IsSimpleArrayExpressionVisitor() {
                super(Optional.empty());
            }

            @Override
            public Optional<SimpleArray> visit(Expression.ArrayInitExpression expression) {
                return Optional.of(new SimpleArray.SimpleBaseArray(expression));
            }

            @Override
            public Optional<SimpleArray> visit(Expression.FreeVarExpression expression) {
                return Optional.of(new SimpleArray.SimpleBaseArray(expression));
            }

            @Override
            public Optional<SimpleArray> visit(Expression.StoreExpression expression) {
                Optional<SimpleAdditiveTerm> optIndexView = viewAsSimpleAdditiveTerm(expression.expression2);
                return optIndexView.flatMap(
                        indexView -> {
                            Optional<SimpleArray> optArray = viewAsSimpleArray(expression.expression1);
                            return optArray.flatMap(array -> array.write(expression, indexView, expression.expression3));
                        }
                );
            }
        }

        return expression.accept(new IsSimpleArrayExpressionVisitor());
    }

    public static Optional<SimpleAdditiveTerm> viewAsSimpleAdditiveTerm(Expression expression) {
        if (isSimpleAdditiveTerm(expression)) {
            return Optional.of(new SimpleAdditiveTerm(expression));
        }
        return Optional.empty();
    }

    public static abstract class SimpleBound extends ExpressionView {
        private SimpleBound(Expression expression) {
            super(expression);
        }

        public boolean isStrict() {
            return isStrict(((Expression.ComparisonExpression) expression).operation);
        }

        private static boolean isStrict(Expression.CompOperation operation) {
            return operation == Expression.CompOperation.GT || operation == Expression.CompOperation.LT;
        }

        public Expression.IntConst getIntConst() {
            Expression.ComparisonExpression comparisonExpression = (Expression.ComparisonExpression) expression;
            return (Expression.IntConst) (comparisonExpression.expression1 instanceof Expression.IntConst ? comparisonExpression.expression1 : comparisonExpression.expression2);
        }

        public Expression.FreeVarExpression getFreeVar() {
            Expression.ComparisonExpression comparisonExpression = (Expression.ComparisonExpression) expression;
            return (Expression.FreeVarExpression) (comparisonExpression.expression1 instanceof Expression.FreeVarExpression ? comparisonExpression.expression1 : comparisonExpression.expression2);
        }
    }

    public static class SimpleLowerBound extends SimpleBound implements Comparable<SimpleLowerBound> {
        private SimpleLowerBound(Expression expression) {
            super(expression);
        }

        @Override
        // bigger means: more strict
        public int compareTo(SimpleLowerBound o) {

            if (o.isStrict() == this.isStrict()) {
                return this.getIntConst().value.compareTo(o.getIntConst().value);
            }

            if (o.isStrict() && !this.isStrict()) {
                return this.getIntConst().value.add(BigInteger.ONE).compareTo(o.getIntConst().value);
            }

            if (!o.isStrict() && this.isStrict()) {
                return this.getIntConst().value.compareTo(o.getIntConst().value.add(BigInteger.ONE));
            }

            throw new RuntimeException("Unreachable Code!");
        }
    }

    public static class SimpleUpperBound extends SimpleBound implements Comparable<SimpleUpperBound> {
        private SimpleUpperBound(Expression expression) {
            super(expression);
        }

        @Override
        // bigger means: more strict
        public int compareTo(SimpleUpperBound o) {
            if (o.isStrict() == this.isStrict()) {
                return o.getIntConst().value.compareTo(this.getIntConst().value);
            }

            if (o.isStrict() && !this.isStrict()) {
                return o.getIntConst().value.compareTo(this.getIntConst().value.add(BigInteger.ONE));
            }

            if (!o.isStrict() && this.isStrict()) {
                return o.getIntConst().value.add(BigInteger.ONE).compareTo(this.getIntConst().value);
            }

            throw new RuntimeException("Unreachable Code!");
        }
    }

    public static Optional<SimpleLowerBound> viewAsSimpleLowerBound(Expression expression) {
        if (isSimpleLowerBound(expression)) {
            return Optional.of(new SimpleLowerBound(expression));
        }
        return Optional.empty();
    }

    private static boolean isSimpleLowerBound(Expression expression) {
        if(!isSimpleBound(expression)) {
            return false;
        }

        Expression.ComparisonExpression comparisonExpression = (Expression.ComparisonExpression) expression;

        if (comparisonExpression.expression1 instanceof Expression.FreeVarExpression) {
            return comparisonExpression.operation == Expression.CompOperation.GT || comparisonExpression.operation == Expression.CompOperation.GE;
        }
        return comparisonExpression.operation == Expression.CompOperation.LT || comparisonExpression.operation == Expression.CompOperation.LE;
    }

    public static Optional<SimpleUpperBound> viewAsSimpleUpperBound(Expression expression) {
        if (isSimpleUpperBound(expression)) {
            return Optional.of(new SimpleUpperBound(expression));
        }
        return Optional.empty();
    }

    private static boolean isSimpleUpperBound(Expression expression) {
        if(!isSimpleBound(expression)) {
            return false;
        }

        Expression.ComparisonExpression comparisonExpression = (Expression.ComparisonExpression) expression;

        if (comparisonExpression.expression2 instanceof Expression.FreeVarExpression) {
            return comparisonExpression.operation == Expression.CompOperation.GT || comparisonExpression.operation == Expression.CompOperation.GE;
        }
        return comparisonExpression.operation == Expression.CompOperation.LT || comparisonExpression.operation == Expression.CompOperation.LE;
    }

    public static boolean isSimpleBound(Expression expression) {
        if (!(expression instanceof Expression.ComparisonExpression)) {
            return false;
        }

        Expression.ComparisonExpression comparisonExpression = (Expression.ComparisonExpression) expression;

        if (comparisonExpression.operation == Expression.CompOperation.EQ || comparisonExpression.operation == Expression.CompOperation.NEQ) {
            return false;
        }

        return (comparisonExpression.expression1 instanceof Expression.IntConst ^ comparisonExpression.expression2 instanceof Expression.IntConst) &&
                (comparisonExpression.expression1 instanceof Expression.FreeVarExpression ^ comparisonExpression.expression2 instanceof Expression.FreeVarExpression);
    }
}
