package secpriv.horst.data;

import java.util.Optional;
import java.util.function.Function;

public class PropositionView <E extends ExpressionView> {
    private final E expressionView;
    public final Proposition proposition;

    private PropositionView(E expressionView, Proposition proposition) {
        this.expressionView = expressionView;
        this.proposition = proposition;
    }

    public static <E extends ExpressionView> Optional<PropositionView<E>> viewAs(Proposition proposition, Function<Expression, Optional<E>> viewer) {
        return expressionFromProposition(proposition).flatMap(viewer).map(v -> new PropositionView<>(v, proposition));
    }

    public static Optional<Expression> expressionFromProposition(Proposition proposition) {
        class PropositionToExpressionVisitor implements Proposition.Visitor<Optional<Expression>> {

            @Override
            public Optional<Expression> visit(Proposition.PredicateProposition proposition) {
                return Optional.empty();
            }

            @Override
            public Optional<Expression> visit(Proposition.ExpressionProposition proposition) {
                return Optional.of(proposition.expression);
            }
        }
        return proposition.accept(new PropositionToExpressionVisitor());
    }

    public E getExpressionView() {
        return expressionView;
    }
}
