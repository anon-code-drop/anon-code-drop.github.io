package secpriv.horst.data;

import com.microsoft.z3.Status;
import secpriv.horst.types.Type;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

public abstract class Predicate {
    public final String name;
    public final List<Type> parameterTypes;
    public final List<Type> argumentsTypes;

    private Predicate(String name, List<Type> parameterTypes, List<Type> argumentsTypes) {
        this.name = Objects.requireNonNull(name, "Name may not be null!");
        this.parameterTypes = Collections.unmodifiableList(Objects.requireNonNull(parameterTypes, "ParameterTypes may not be null!"));
        this.argumentsTypes = Collections.unmodifiableList(Objects.requireNonNull(argumentsTypes, "ArgumentTypes may not be null!"));
    }

    public static Predicate newPredicate(String name, List<Type> parameterTypes, List<Type> argumentsTypes) {
        return new RegularPredicate(name, parameterTypes, argumentsTypes);
    }

    public static Predicate newQuery(String name, List<Type> parameterTypes) {
        return new QueryPredicate(name, parameterTypes);
    }

    public interface Visitor<E> {
        E visit(RegularPredicate predicate);

        E visit(QueryPredicate predicate);

        E visit(TestPredicate predicate);
    }

    public enum TestResult {
        SAT, UNSAT;

        public static TestResult fromZ3Result(Status result) {
            switch (result) {
                case SATISFIABLE:
                    return SAT;
                case UNSATISFIABLE:
                    return UNSAT;
            }
            throw new IllegalArgumentException("Provided " + result + " but only " + Status.SATISFIABLE + " and " + Status.UNSATISFIABLE + " are valid Arguments!");
        }
    }

    public abstract <E> E accept(Visitor<E> visitor);


    public abstract Predicate changeArgumentTypes(List<Type> argumentsTypes);

    public abstract Predicate instantiate(String instantiatedName);

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Predicate predicate = (Predicate) o;
        return Objects.equals(name, predicate.name) &&
                Objects.equals(parameterTypes, predicate.parameterTypes) &&
                Objects.equals(argumentsTypes, predicate.argumentsTypes);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, parameterTypes, argumentsTypes);
    }

    public static class RegularPredicate extends Predicate {
        private RegularPredicate(String name, List<Type> parameterTypes, List<Type> argumentsTypes) {
            super(name, parameterTypes, argumentsTypes);
        }

        @Override
        public <E> E accept(Visitor<E> visitor) {
            return visitor.visit(this);
        }

        @Override
        public Predicate changeArgumentTypes(List<Type> argumentsTypes) {
            return new RegularPredicate(this.name, this.parameterTypes, argumentsTypes);
        }

        @Override
        public Predicate instantiate(String instantiatedName) {
            return new RegularPredicate(instantiatedName, Collections.emptyList(), this.argumentsTypes);
        }
    }

    public static class QueryPredicate extends Predicate {
        private QueryPredicate(String name, List<Type> parameterTypes) {
            super(name, parameterTypes, Collections.emptyList());
        }

        @Override
        public <E> E accept(Visitor<E> visitor) {
            return visitor.visit(this);
        }

        @Override
        public Predicate changeArgumentTypes(List<Type> argumentsTypes) {
            return this;
        }

        @Override
        public Predicate instantiate(String instantiatedName) {
            return new QueryPredicate(instantiatedName, Collections.emptyList());
        }

        public TestPredicate expectResult(TestResult expectedResult) {
            return new TestPredicate(this.name, this.parameterTypes, expectedResult);
        }
    }

    public static class TestPredicate extends Predicate {
        public final TestResult expectedResult;

        private TestPredicate(String name, List<Type> parameterTypes, TestResult expectedResult) {
            super(name, parameterTypes, Collections.emptyList());
            this.expectedResult = expectedResult;
        }

        @Override
        public <E> E accept(Visitor<E> visitor) {
            return visitor.visit(this);
        }

        @Override
        public Predicate changeArgumentTypes(List<Type> argumentsTypes) {
            return this;
        }

        @Override
        public Predicate instantiate(String instantiatedName) {
            return new TestPredicate(instantiatedName, Collections.emptyList(), this.expectedResult);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            if (!super.equals(o)) return false;
            TestPredicate that = (TestPredicate) o;
            return expectedResult == that.expectedResult;
        }

        @Override
        public int hashCode() {
            return Objects.hash(super.hashCode(), expectedResult);
        }
    }
}
