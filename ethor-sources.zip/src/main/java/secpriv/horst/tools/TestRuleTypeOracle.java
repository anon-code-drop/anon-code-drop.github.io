package secpriv.horst.tools;

import secpriv.horst.data.Predicate;
import secpriv.horst.data.Rule;
import secpriv.horst.visitors.RuleTypeOracle;
import secpriv.horst.visitors.VisitorState;

import java.util.Collections;
import java.util.Objects;
import java.util.Set;

public class TestRuleTypeOracle implements RuleTypeOracle {
    private final Set<Predicate> queryPredicates;

    public TestRuleTypeOracle(Set<Predicate> queryPredicates) {
        this.queryPredicates = Collections.unmodifiableSet(Objects.requireNonNull(queryPredicates, "queryPredicates may not be null!"));
    }

    @Override
    public boolean isTest(Rule rule) {
        return false;
    }

    @Override
    public boolean isQueryOrTest(Rule rule) {
        return rule.clauses.stream().anyMatch(c -> queryPredicates.contains(c.conclusion.predicate));
    }

    @Override
    public boolean isExpectedTestResult(Rule test, VisitorState.TestResult result) {
        return false;
    }
}
