package secpriv.horst.tools;

import secpriv.horst.data.Expression;
import secpriv.horst.data.Rule;
import secpriv.horst.types.Type;

import java.math.BigInteger;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class QueryNameParser {
    private final Map<String, Pattern> patternMap = new HashMap<>();
    private final Map<String, Map<String, Integer>> positionMap = new HashMap<>();
    private static TypeToRegexPatternVisitor typeToRegexPatternVisitor = new TypeToRegexPatternVisitor();

    private static class TypeToRegexPatternVisitor implements Type.Visitor<String> {
        @Override
        public String visit(Type.BooleanType type) {
            return "(true|false)";
        }

        @Override
        public String visit(Type.IntegerType type) {
            return "(-?\\d+)";
        }

        @Override
        public String visit(Type.CustomType type) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String visit(Type.ArrayType type) {
            throw new UnsupportedOperationException();
        }
    }

    public QueryNameParser(List<Rule> rules) {
        populatePatternAndPositionMap(rules);
    }

    @SafeVarargs
    public QueryNameParser(List<Rule>... ruleLists) {
        for (List<Rule> rules : ruleLists) {
            populatePatternAndPositionMap(rules);
        }
    }

    private void populatePatternAndPositionMap(List<Rule> rules) {
        for (Rule rule : rules) {
            int i = 0;
            StringBuilder rulePattern = new StringBuilder();
            rulePattern.append("^");
            rulePattern.append(rule.name);
            Map<String, Integer> positions = new HashMap<>();
            for (Expression.ParVarExpression p : rule.selectorFunctionInvocation.parameters()) {
                rulePattern.append("_");
                rulePattern.append(p.getType().accept(typeToRegexPatternVisitor));

                positions.put(p.name, i + 1);

                ++i;
            }
            rulePattern.append("$");
            patternMap.put(rule.name, Pattern.compile(rulePattern.toString()));
            positionMap.put(rule.name, Collections.unmodifiableMap(positions));
        }
    }

    private String getParameterString(String queryName, String parameterName) {
        for (Map.Entry<String, Pattern> entry : patternMap.entrySet()) {
            Pattern pattern = entry.getValue();
            String ruleName = entry.getKey();
            Matcher matcher = pattern.matcher(queryName);
            if (matcher.matches()) {
                if (positionMap.get(ruleName).containsKey(parameterName)) {
                    return matcher.group(positionMap.get(ruleName).get(parameterName));
                } else {
                    throw new IllegalArgumentException("Rule '" + ruleName + "' has no parameter " + parameterName + "!");
                }
            }
        }
        throw new IllegalArgumentException("Query '" + queryName + "' does not match any registered rules!");
    }

    public BigInteger getIntParameter(String queryName, String parameterName) {
        return new BigInteger(getParameterString(queryName, parameterName));
    }

    public boolean getBoolParameter(String queryName, String parameterName) {
        switch (getParameterString(queryName, parameterName)) {
            case "true":
                return true;
            case "false":
                return false;
        }
        throw new IllegalArgumentException("Parameter '" + parameterName + "' exists but was neither 'true' nor 'false'!");
    }

}
