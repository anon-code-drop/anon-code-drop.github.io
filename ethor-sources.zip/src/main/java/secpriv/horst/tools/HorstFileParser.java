package secpriv.horst.tools;

import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import secpriv.horst.parser.ASLexer;
import secpriv.horst.parser.ASParser;
import secpriv.horst.visitors.ProgramVisitor;
import secpriv.horst.visitors.VisitorState;

import java.io.IOException;

public class HorstFileParser {
    public static VisitorState parseAllHorstFiles(VisitorState state, String[] horstFiles) {
        try {
            for (String horstFile : horstFiles) {
                ASLexer lexer = new ASLexer(CharStreams.fromFileName(horstFile));
                CommonTokenStream tokens = new CommonTokenStream(lexer);
                ASParser parser = new ASParser(tokens);

                ProgramVisitor visitor = new ProgramVisitor(state);
                state = visitor.visit(parser.abstractProgram()).get();
            }
            return state;
        } catch (IOException e) {
            throw new RuntimeException("Error while parsing Horst files", e);
        }
    }
}
