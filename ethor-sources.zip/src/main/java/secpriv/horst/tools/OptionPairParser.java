package secpriv.horst.tools;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.HashMap;

public class OptionPairParser {
    private static Logger logger = LogManager.getLogger(OptionPairParser.class);

    public static HashMap<String, String> parseOptionPairs(String[] params) {
        HashMap<String, String> parsedOptionPairs = new HashMap<>();
        if (params != null) {
            for (String paramPair : params) {
                String[] splitPair = paramPair.split("=");
                if (splitPair.length != 2) {
                    logger.warn("z3 parameter '{}' was malformed and therefore ignored!", paramPair);
                } else {
                    parsedOptionPairs.put(splitPair[0], splitPair[1]);
                }
            }
        }
        return parsedOptionPairs;
    }

}
