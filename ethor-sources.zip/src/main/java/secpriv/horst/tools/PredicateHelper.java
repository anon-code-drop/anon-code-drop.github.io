package secpriv.horst.tools;

import secpriv.horst.data.Predicate;
import secpriv.horst.data.Rule;

import java.util.stream.Stream;

public class PredicateHelper {
    private PredicateHelper() {
    }

    private static class IsQueryOrTestPredicate implements Predicate.Visitor<Boolean> {
        private static IsQueryOrTestPredicate instance = new IsQueryOrTestPredicate();

        @Override
        public Boolean visit(Predicate.RegularPredicate predicate) {
            return false;
        }

        @Override
        public Boolean visit(Predicate.QueryPredicate predicate) {
            return true;
        }

        @Override
        public Boolean visit(Predicate.TestPredicate predicate) {
            return true;
        }
    }

    public static Stream<Predicate> queryOrTestStream(Rule rule) {
        return rule.clauses.stream().map(c -> c.conclusion.predicate).filter(PredicateHelper::isQueryOrTest);
    }

    public static boolean isQueryOrTest(Rule rule) {
        return isQueryOrTest(rule.clauses.get(0).conclusion.predicate);
    }

    public static boolean isQueryOrTest(Predicate predicate) {
        return predicate.accept(IsQueryOrTestPredicate.instance);
    }
}
