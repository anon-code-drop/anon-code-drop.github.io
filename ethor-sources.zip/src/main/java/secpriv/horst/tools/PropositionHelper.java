package secpriv.horst.tools;

import secpriv.horst.data.Proposition;

public class PropositionHelper {
    private PropositionHelper() {
    }

    private static class IsPredicatePropositionPropositionVisitor implements Proposition.Visitor<Boolean> {
        private static IsPredicatePropositionPropositionVisitor instance = new IsPredicatePropositionPropositionVisitor();

        @Override
        public Boolean visit(Proposition.PredicateProposition proposition) {
            return true;
        }

        @Override
        public Boolean visit(Proposition.ExpressionProposition proposition) {
            return false;
        }
    }

    public static boolean isPredicateProposition(Proposition proposition) {
        return proposition.accept(IsPredicatePropositionPropositionVisitor.instance);
    }
}
