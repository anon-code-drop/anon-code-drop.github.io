package secpriv.horst.translation;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import secpriv.horst.data.Clause;
import secpriv.horst.data.CompoundSelectorFunctionInvocation;
import secpriv.horst.data.Predicate;
import secpriv.horst.data.Rule;
import secpriv.horst.data.tuples.Tuple2;
import secpriv.horst.tools.CartesianHelper;
import secpriv.horst.tools.SmtLibGenerator;
import secpriv.horst.translation.visitors.*;
import secpriv.horst.visitors.RuleTypeOracle;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MediumStepTransformer {
    private static final Logger logger = LogManager.getLogger(MediumStepTransformer.class);

    public static List<Rule> foldToMediumSteps(List<Rule> allRules, RuleTypeOracle oracle) {
        allRules = (new PruneStrategy.DeleteLeavesPruneStrategy()).pruneRules(allRules, oracle);
        allRules = LinearClauseFolder.foldLinearClausesRules(allRules);

        return allRules;
    }

    public static List<Rule> foldToMediumStepsWithMagic(List<Rule> allRules, RuleTypeOracle oracle, PruneStrategy pruneStrategy, PredicateInliningStrategy predicateInliningStrategy) {
        allRules = applyPruning(allRules, oracle, pruneStrategy);

        if (allRules.isEmpty()) {
            return allRules;
        }

        List<Predicate> inlineCandidates = predicateInliningStrategy.getInlineCandidates(allRules);

        if(inlineCandidates.isEmpty()) {
            return allRules;
        }

        allRules = allRules.stream().map(r -> r.accept(new UnfoldAndRuleVisitor()).accept(new ConservativelyAllocatingConstantFoldingRuleVisitor())).collect(Collectors.toList());

        allRules = inlinePredicates(allRules, oracle, inlineCandidates);

        allRules = allRules.stream().map(r -> r.accept(new EqualityInliningRuleVisitor()).accept(new RemoveTruePremiseRuleVisitor())).collect(Collectors.toList());

        return allRules;
    }

    private static List<Rule> applyPruning(List<Rule> allRules, RuleTypeOracle oracle, PruneStrategy strategy) {
        logger.info("Start Pruning.");
        List<Rule> prunedRules = strategy.pruneRules(allRules, oracle);
        logger.info("Finished Pruning. Removed {} clauses.", () -> getClauseCount(allRules) - getClauseCount(prunedRules));

        return prunedRules;
    }

    private static int getClauseCount(List<Rule> rules) {
        return rules.stream().mapToInt(r -> r.clauses.size()).sum();
    }


    private static List<Rule> inlinePredicates(List<Rule> allRules, RuleTypeOracle oracle, List<Predicate> inlineCandidates) {
        {
            List<Rule> finalAllRules = allRules;
            logger.info("Start inlining. Clause count {}.", () -> getClauseCount(finalAllRules));
        }
        Set<Rule> queryRules = allRules.stream().filter(oracle::isQueryOrTest).collect(Collectors.toSet());
        Set<Predicate> queryPredicates = queryRules.stream().flatMap(r -> r.clauses.stream()).map(c -> c.conclusion.predicate).collect(Collectors.toSet());

        PredicateOccurrenceMap predicateOccurrenceMap = new PredicateOccurrenceMap(allRules);

        Map<Clause, Tuple2<Rule, Integer>> clauseToRuleMap = SmtLibGenerator.generateClauseToRuleMap(allRules);

        int i = 0;


        for (Predicate p : inlineCandidates) {
            if (queryPredicates.contains(p)) {
                continue;
            }
            if (Thread.currentThread().isInterrupted()) {
                return Collections.emptyList();
            }

            List<Clause> predicateInPremise = predicateOccurrenceMap.getOccurrencesAsPremise(p);

            if (predicateInPremise.stream().anyMatch(c -> queryRules.contains(clauseToRuleMap.get(c).v0))) {
                // We do not inline predicates, that directly imply query predicates.
                // This mainly because we don't want to change the number of queries.
                // Consider a => c, b => c and c => q, where q is a query
                // removing c would lead to a => q and b => b, thus duplicating the
                // number of rules considered queries. Maybe the solution for this is
                // a predicate-as-query model...
                continue;
            }

            allRules = inlinePredicate(allRules, p, i, oracle);
            i++;
        }
        {
            List<Rule> finalAllRules = allRules;
            logger.info("Finished inlining. New clause count {}.", () -> getClauseCount(finalAllRules));
        }

        return allRules;
    }

    private static List<Rule> inlinePredicate(final List<Rule> rules, Predicate inlinedPredicate, int numberOfInlinedPredicatesSoFar, RuleTypeOracle oracle) {
        logger.trace("Inlining {}. Old clause count {}.", () -> inlinedPredicate.name, () -> getClauseCount(rules));

        PredicateOccurrenceMap predicateOccurrenceMap = new PredicateOccurrenceMap(rules);
        List<Clause> predicateInPremise = predicateOccurrenceMap.getOccurrencesAsPremise(inlinedPredicate);
        List<Clause> predicateInConclusion = predicateOccurrenceMap.getOccurrencesAsConclusion(inlinedPredicate);

        //Check for self referential clauses
        if (predicateInConclusion.stream().anyMatch(predicateInPremise::contains)) {
            logger.trace("Did not inline {} because it was part of an self referential clause!", inlinedPredicate.name);
            return rules;
        }

        List<Rule> inlinedPredicateRules = rules;

        int i = 0;
        for (Tuple2<Clause, Clause> mergePair : CartesianHelper.product(predicateInConclusion, predicateInPremise)) {
            ClauseMerger clauseMerger = new ClauseMerger();
            Clause mergedClause = clauseMerger.merge(Stream.of(mergePair.v0, mergePair.v1).collect(Collectors.toList()));
            mergedClause = mergedClause.accept(new EqualityInliningClauseVisitor());
            String ruleName = "r_" + numberOfInlinedPredicatesSoFar + "_" + (i++);
            inlinedPredicateRules.add(new Rule(ruleName, CompoundSelectorFunctionInvocation.UnitInvocation, Collections.singletonList(mergedClause)));

            logger.trace("Generated new rule {}.", ruleName);
        }

        inlinedPredicateRules = deleteInlinedRules(inlinedPredicateRules, predicateInPremise, predicateInConclusion);

        inlinedPredicateRules = inlinedPredicateRules.stream().map(r -> r.accept(new FilterUnapplicableClausesRuleVisitor(oracle))).collect(Collectors.toList());
        inlinedPredicateRules = inlinedPredicateRules.stream().filter(r -> !r.clauses.isEmpty()).collect(Collectors.toList());


        List<Rule> finalInlinedPredicateRules = inlinedPredicateRules;
        logger.trace("Finished inlining {}. New clause count {}.", () -> inlinedPredicate.name, () -> getClauseCount(finalInlinedPredicateRules));

        return inlinedPredicateRules;
    }

    private static List<Rule> deleteInlinedRules(List<Rule> rules, List<Clause> predicateInPremise, List<Clause> predicateInConclusion) {
        Set<Clause> deletionCandidates = new HashSet<>();
        deletionCandidates.addAll(predicateInConclusion);
        deletionCandidates.addAll(predicateInPremise);

        FilterClauseRuleVisitor filterClauseRuleVisitor = new FilterClauseRuleVisitor(deletionCandidates);

        return rules.stream().map(r -> r.accept(filterClauseRuleVisitor)).filter(Optional::isPresent).map(Optional::get).collect(Collectors.toList());
    }
}
