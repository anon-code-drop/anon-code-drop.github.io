package secpriv.horst.translation;

import org.jgrapht.Graph;
import org.jgrapht.traverse.AbstractGraphIterator;

import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class OptimalInlineOrderGraphIterator<V, E> extends AbstractGraphIterator<V, E> {
    private final Set<V> visitedVertices;
    private final Set<V> encounteredVertices;
    private final Comparator<V> comparator;

    public OptimalInlineOrderGraphIterator(Graph<V, E> graph, V startVertex) {
        super(graph);

        visitedVertices = new HashSet<>();
        encounteredVertices = new HashSet<>();
        encounteredVertices.add(startVertex);
        Comparator<V> tmpComparatorToHelpJavasTypeSystem = Comparator.comparing(v -> graph.incomingEdgesOf(v).stream().filter(e -> !visitedVertices.contains(graph.getEdgeSource(e))).count());
        comparator = tmpComparatorToHelpJavasTypeSystem.thenComparing(graph::inDegreeOf);
    }

    public OptimalInlineOrderGraphIterator(Graph<V, E> graph, Set<V> startVertices, Comparator<V> tieBreaker) {
        super(graph);

        visitedVertices = new HashSet<>();
        encounteredVertices = new HashSet<>();
        encounteredVertices.addAll(startVertices);
        Comparator<V> tmpComparatorToHelpJavasTypeSystem = Comparator.comparing(v -> graph.incomingEdgesOf(v).stream().filter(e -> !visitedVertices.contains(graph.getEdgeSource(e))).count());
        comparator = tmpComparatorToHelpJavasTypeSystem.thenComparing(tieBreaker);
    }


    @Override
    public boolean hasNext() {
        return encounteredVertices.size() > 0;
    }

    @Override
    public V next() {
        V next = encounteredVertices.stream().min(comparator).get();

        visitedVertices.add(next);
        encounteredVertices.remove(next);

        List<V> neighbours = graph.outgoingEdgesOf(next).stream().map(graph::getEdgeTarget).filter(t -> !visitedVertices.contains(t)).distinct().collect(Collectors.toList());
        encounteredVertices.addAll(neighbours);

        return next;
    }
}
