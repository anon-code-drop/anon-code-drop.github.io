package secpriv.horst.translation.visitors;

public class ConservativelyAllocatingConstantFoldingClauseVisitor extends PropositionMappingClauseVisitor {

    public ConservativelyAllocatingConstantFoldingClauseVisitor() {
        super(new ConservativelyAllocatingConstantFoldingPropositionVisitor());
    }
}
