package secpriv.horst.translation.visitors;

public class EqualityInliningRuleVisitor extends ClauseMappingRuleVisitor {
    public EqualityInliningRuleVisitor() {
        super(new EqualityInliningClauseVisitor());
    }
}
