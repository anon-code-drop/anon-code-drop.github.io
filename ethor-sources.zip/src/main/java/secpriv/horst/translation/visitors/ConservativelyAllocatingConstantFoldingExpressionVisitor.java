package secpriv.horst.translation.visitors;

import secpriv.horst.data.Expression;
import secpriv.horst.data.ExpressionView;
import secpriv.horst.types.Type;

import java.math.BigInteger;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class ConservativelyAllocatingConstantFoldingExpressionVisitor implements Expression.Visitor<Expression> {
    private final Map<Expression.FreeVarExpression, Expression> freeVarMapping;

    public ConservativelyAllocatingConstantFoldingExpressionVisitor() {
        this(Collections.emptyMap());
    }

    public ConservativelyAllocatingConstantFoldingExpressionVisitor(Map<Expression.FreeVarExpression, Expression> freeVarMapping) {
        this.freeVarMapping = Collections.unmodifiableMap(freeVarMapping);
    }

    @Override
    public Expression visit(Expression.IntConst expression) {
        return expression;
    }

    @Override
    public Expression visit(Expression.BoolConst expression) {
        return expression;
    }

    @Override
    public Expression visit(Expression.ArrayInitExpression expression) {
        Expression tmp = expression.initializer.accept(this);

        if (tmp == expression.initializer) {
            return expression;
        }
        return new Expression.ArrayInitExpression(tmp);
    }

    @Override
    public Expression visit(Expression.VarExpression expression) {
        throw new UnsupportedOperationException("VarExpression should have already been inlined/translated.");
    }

    @Override
    public Expression visit(Expression.FreeVarExpression expression) {
        return freeVarMapping.getOrDefault(expression, expression);
    }

    @Override
    public Expression visit(Expression.ParVarExpression expression) {
        throw new UnsupportedOperationException("ParVarExpression should have already been instantiated.");
    }


    private BigInteger evaluateIntExpression(BigInteger v1, BigInteger v2, Expression.IntOperation operation) {
        switch (operation) {
            case MUL:
                return v1.multiply(v2);
            case ADD:
                return v1.add(v2);
            case DIV:
                return v1.divide(v2);
            case MOD:
                return v1.mod(v2);
            case SUB:
                return v1.subtract(v2);
        }

        throw new IllegalArgumentException("Cannot evaluate operation " + operation + "!");
    }

    @Override
    public Expression visit(Expression.BinaryIntExpression expression) {
        Expression tmp1 = expression.expression1.accept(this);
        Expression tmp2 = expression.expression2.accept(this);

        if (tmp1 instanceof Expression.IntConst && tmp2 instanceof Expression.IntConst) {
            if (((Expression.IntConst) tmp2).value.equals(BigInteger.ZERO) && (expression.operation == Expression.IntOperation.MOD || expression.operation == Expression.IntOperation.DIV)) {
                return expression;
            } else {
                return new Expression.IntConst(evaluateIntExpression(((Expression.IntConst) tmp1).value, ((Expression.IntConst) tmp2).value, expression.operation));
            }
        }

        if ((tmp1 instanceof Expression.IntConst ^ tmp2 instanceof Expression.IntConst)) {
            Expression.IntOperation operation = expression.operation;
            if (tmp2 instanceof Expression.IntConst && (operation == Expression.IntOperation.DIV || operation == Expression.IntOperation.MOD)) {
                Expression.IntConst constExp = (Expression.IntConst) tmp2;
                if (operation == Expression.IntOperation.DIV) {
                    if (constExp.value.equals(BigInteger.ONE)) {
                        return tmp1;
                    }
                } else {
                    if (constExp.value.equals(BigInteger.ONE)) {
                        return new Expression.IntConst(BigInteger.ZERO);
                    }
                }
            } else {
                Expression.IntConst constExp = (Expression.IntConst) (tmp1 instanceof Expression.IntConst ? tmp1 : tmp2);
                Expression nonConstExp = tmp1 instanceof Expression.IntConst ? tmp2 : tmp1;

                boolean isConstEqualToOne = constExp.value.equals(BigInteger.ONE);

                if (operation == Expression.IntOperation.ADD) {
                    if (constExp.value.equals(BigInteger.ZERO)) {
                        return nonConstExp;
                    }
                } else if (operation == Expression.IntOperation.MUL) {
                    if (constExp.value.equals(BigInteger.ZERO)) {
                        return constExp;
                    }
                    if (isConstEqualToOne) {
                        return nonConstExp;
                    }
                }

                // TODO extend!!
                if (nonConstExp instanceof Expression.BinaryIntExpression) {
                    if (((Expression.BinaryIntExpression) nonConstExp).expression1 instanceof Expression.FreeVarExpression ^ ((Expression.BinaryIntExpression) nonConstExp).expression2 instanceof Expression.FreeVarExpression) {
                        return optimizeNestedBinaryIntExpressionWithOneConst(expression, tmp1, tmp2);
                    }
                }
            }
        }

        if (tmp1 == expression.expression1 && tmp2 == expression.expression2) {
            return expression;
        }

        return new Expression.BinaryIntExpression(tmp1, tmp2, expression.operation);
    }

    private Expression optimizeNestedBinaryIntExpressionWithOneConst(Expression.BinaryIntExpression expression, Expression tmp1, Expression tmp2) {
        if (expression.operation == Expression.IntOperation.ADD || expression.operation == Expression.IntOperation.SUB) {
            BigInteger i1;
            BigInteger i2;
            boolean freeVarNegated;
            Expression.FreeVarExpression freeVar;
            if (tmp1 instanceof Expression.IntConst) {
                i1 = ((Expression.IntConst) tmp1).value;

                Expression.BinaryIntExpression binaryChild = (Expression.BinaryIntExpression) tmp2;

                if (binaryChild.expression1 instanceof Expression.IntConst) {
                    freeVar = (Expression.FreeVarExpression) binaryChild.expression2;
                    if (expression.operation == Expression.IntOperation.ADD) {
                        i2 = ((Expression.IntConst) binaryChild.expression1).value;
                        freeVarNegated = binaryChild.operation == Expression.IntOperation.SUB;
                    } else {
                        i2 = ((Expression.IntConst) binaryChild.expression1).value.negate();
                        freeVarNegated = binaryChild.operation == Expression.IntOperation.ADD;
                    }
                } else {
                    freeVar = (Expression.FreeVarExpression) binaryChild.expression1;
                    if (expression.operation == Expression.IntOperation.ADD) {
                        freeVarNegated = false;
                        i2 = binaryChild.operation == Expression.IntOperation.ADD ? ((Expression.IntConst) binaryChild.expression2).value : ((Expression.IntConst) binaryChild.expression2).value.negate();
                    } else {
                        freeVarNegated = true;
                        i2 = binaryChild.operation == Expression.IntOperation.SUB ? ((Expression.IntConst) binaryChild.expression2).value : ((Expression.IntConst) binaryChild.expression2).value.negate();
                    }
                }
            } else {
                if (expression.operation == Expression.IntOperation.ADD) {
                    i1 = ((Expression.IntConst) tmp2).value;
                } else {
                    i1 = ((Expression.IntConst) tmp2).value.negate();
                }

                Expression.BinaryIntExpression binaryChild = (Expression.BinaryIntExpression) tmp1;

                if (binaryChild.expression1 instanceof Expression.IntConst) {
                    freeVar = (Expression.FreeVarExpression) binaryChild.expression2;
                    if (binaryChild.operation == Expression.IntOperation.ADD) {
                        i2 = ((Expression.IntConst) binaryChild.expression1).value;
                        freeVarNegated = false;
                    } else {
                        i2 = ((Expression.IntConst) binaryChild.expression1).value;
                        freeVarNegated = true;
                    }
                } else {
                    freeVar = (Expression.FreeVarExpression) binaryChild.expression1;
                    if (binaryChild.operation == Expression.IntOperation.ADD) {
                        i2 = ((Expression.IntConst) binaryChild.expression2).value;
                        freeVarNegated = false;
                    } else {
                        i2 = ((Expression.IntConst) binaryChild.expression2).value.negate();
                        freeVarNegated = false;
                    }
                }
            }

            BigInteger sum = i1.add(i2);

            if (freeVarNegated) {
                return new Expression.BinaryIntExpression(new Expression.IntConst(sum), freeVar, Expression.IntOperation.SUB);
            } else {
                return buildSumOfExpressionAndConst(freeVar, sum);
            }
        }

        //TODO This is bad, improve
        if (expression.expression1 == tmp1 && expression.expression2 == tmp2) {
            return expression;
        } else {
            return new Expression.BinaryIntExpression(tmp1, tmp2, expression.operation);
        }
    }

    //TODO rename
    private Expression buildSumOfExpressionAndConst(Expression nonConstExpression, BigInteger value) {
        if (value.compareTo(BigInteger.ZERO) < 0) {
            return new Expression.BinaryIntExpression(nonConstExpression, new Expression.IntConst(value.negate()), Expression.IntOperation.SUB);
        } else if (value.compareTo(BigInteger.ZERO) > 0) {
            return new Expression.BinaryIntExpression(nonConstExpression, new Expression.IntConst(value), Expression.IntOperation.ADD);
        }
        return nonConstExpression;
    }

    @Override
    public Expression visit(Expression.BinaryBoolExpression expression) {
        Expression tmp1 = expression.expression1.accept(this);
        Expression tmp2 = expression.expression2.accept(this);

        if (tmp1 instanceof Expression.BoolConst && tmp2 instanceof Expression.BoolConst) {
            return evaluateBoolExpression(((Expression.BoolConst) tmp1).value, ((Expression.BoolConst) tmp2).value, expression.operation);
        }

        if (tmp1 instanceof Expression.BoolConst ^ tmp2 instanceof Expression.BoolConst) {
            Expression.BoolConst constExp = (Expression.BoolConst) (tmp1 instanceof Expression.BoolConst ? tmp1 : tmp2);
            Expression nonConstExp = tmp1 instanceof Expression.BoolConst ? tmp2 : tmp1;
            Expression.BoolOperation operation = expression.operation;

            switch (operation) {
                case AND:
                    return constExp.value ? nonConstExp : Expression.BoolConst.FALSE;
                case OR:
                    return constExp.value ? Expression.BoolConst.TRUE : nonConstExp;
            }
        }

        if (tmp1.equals(tmp2)) {
            return tmp1;
        }

        if (tmp1 == expression.expression1 && tmp2 == expression.expression2) {
            return expression;
        }

        return new Expression.BinaryBoolExpression(tmp1, tmp2, expression.operation);
    }

    private Expression evaluateBoolExpression(boolean v1, boolean v2, Expression.BoolOperation operation) {
        switch (operation) {
            case AND:
                return (v1 && v2) ? Expression.BoolConst.TRUE : Expression.BoolConst.FALSE;
            case OR:
                return (v1 || v2) ? Expression.BoolConst.TRUE : Expression.BoolConst.FALSE;
        }
        throw new RuntimeException("Unreachable code!");
    }

    @Override
    public Expression visit(Expression.SelectExpression expression) {
        Expression tmp1 = expression.expression1.accept(this);
        Expression tmp2 = expression.expression2.accept(this);

        Optional<ExpressionView.SimpleArray> optArrayView = ExpressionView.viewAsSimpleArray(tmp1);

        if (optArrayView.isPresent()) {
            Optional<ExpressionView.SimpleAdditiveTerm> optIndexView = ExpressionView.viewAsSimpleAdditiveTerm(tmp2);
            if (optIndexView.isPresent()) {
                ExpressionView.SimpleArray arrayView = optArrayView.get();
                ExpressionView.SimpleAdditiveTerm indexView = optIndexView.get();

                if (arrayView.isIndexCompatible(indexView)) {
                    return arrayView.select(indexView);
                }
            }
        }

        if (tmp1 == expression.expression1 && tmp2 == expression.expression2) {
            return expression;
        }

        return new Expression.SelectExpression(tmp1, tmp2);
    }

    @Override
    public Expression visit(Expression.StoreExpression expression) {
        Expression tmp1 = expression.expression1.accept(this);
        Expression tmp2 = expression.expression2.accept(this);
        Expression tmp3 = expression.expression3.accept(this);

        Optional<ExpressionView.SimpleArray> optArrayView = ExpressionView.viewAsSimpleArray(tmp1);

        if (optArrayView.isPresent()) {
            Optional<ExpressionView.SimpleAdditiveTerm> optIndexView = ExpressionView.viewAsSimpleAdditiveTerm(tmp2);
            if (optIndexView.isPresent()) {
                ExpressionView.SimpleArray arrayView = optArrayView.get();
                ExpressionView.SimpleAdditiveTerm indexView = optIndexView.get();

                Optional<ExpressionView.SimpleArray> optNewArray = arrayView.write(expression, indexView, tmp3);
                if (optNewArray.isPresent()) {
                    return optNewArray.get().optimize();
                }
            }
        }
        if (tmp1 == expression.expression1 && tmp2 == expression.expression2 && tmp3 == expression.expression3) {
            return expression;
        }

        return new Expression.StoreExpression(tmp1, tmp2, tmp3);
    }

    @Override
    public Expression visit(Expression.AppExpression expression) {
        throw new UnsupportedOperationException("AppExpression should be eliminated at this point!");
    }

    @Override
    public Expression visit(Expression.ConstructorAppExpression expression) {
        throw new UnsupportedOperationException("ConstructorAppExpression should be eliminated at this point!");
    }

    @Override
    public Expression visit(Expression.MatchExpression expression) {
        throw new UnsupportedOperationException("MatchExpression should be eliminated at this point!");
    }

    @Override
    public Expression visit(Expression.NegationExpression expression) {
        Expression tmp = expression.expression.accept(this);

        if (tmp instanceof Expression.NegationExpression) {
            return ((Expression.NegationExpression) tmp).expression;
        }

        if (tmp == Expression.BoolConst.TRUE) {
            return Expression.BoolConst.FALSE;
        } else if (tmp == Expression.BoolConst.FALSE) {
            return Expression.BoolConst.TRUE;
        }

        if (tmp == expression.expression) {
            return expression;
        }

        return new Expression.NegationExpression(tmp);
    }

    @Override
    public Expression visit(Expression.ConditionalExpression expression) {
        Expression tmp1 = expression.expression1.accept(this);

        if (tmp1 == Expression.BoolConst.TRUE) {
            return expression.expression2.accept(this);
        }
        if (tmp1 == Expression.BoolConst.FALSE) {
            return expression.expression3.accept(this);
        }

        ConservativelyAllocatingConstantFoldingExpressionVisitor child1Visitor;
        ConservativelyAllocatingConstantFoldingExpressionVisitor child2Visitor;

        Optional<ExpressionView.SimpleEquality> optEquality = ExpressionView.viewAsSimpleEquality(tmp1);

        if (optEquality.isPresent()) {
            ExpressionView.SimpleEquality equality = optEquality.get();

            {
                Map<Expression.FreeVarExpression, Expression> freeVarMapping = new HashMap<>(this.freeVarMapping);
                freeVarMapping.put(equality.getFreeVar(), equality.getValue());
                child1Visitor = new ConservativelyAllocatingConstantFoldingExpressionVisitor(freeVarMapping);
            }

            if (equality.getFreeVar().getType().equals(Type.Boolean)) {
                    Map<Expression.FreeVarExpression, Expression> freeVarMapping = new HashMap<>(this.freeVarMapping);
                    freeVarMapping.put(equality.getFreeVar(), negate(equality.getValue()));
                    child2Visitor = new ConservativelyAllocatingConstantFoldingExpressionVisitor(freeVarMapping);
            } else {
                child2Visitor = this;
            }
        } else {
            child1Visitor = this;
            child2Visitor = this;
        }

        Expression tmp2 = expression.expression2.accept(child1Visitor);

        if (tmp2 == Expression.BoolConst.TRUE) {
            Expression tmp3 = expression.expression3.accept(child2Visitor);
            if (tmp3 == Expression.BoolConst.TRUE) {
                return Expression.BoolConst.TRUE;
            }
            if (tmp3 == Expression.BoolConst.FALSE) {
                return tmp1;
            }
            return new Expression.BinaryBoolExpression(tmp1, tmp3, Expression.BoolOperation.OR);
        }
        if (tmp2 == Expression.BoolConst.FALSE) {
            Expression tmp3 = expression.expression3.accept(child2Visitor);
            if (tmp3 == Expression.BoolConst.TRUE) {
                return negate(tmp1);
            }
            if (tmp3 == Expression.BoolConst.FALSE) {
                return Expression.BoolConst.FALSE;
            }
            return new Expression.BinaryBoolExpression(negate(tmp1), tmp3, Expression.BoolOperation.AND);
        }

        Expression tmp3 = expression.expression3.accept(child2Visitor);

        if (tmp3 == Expression.BoolConst.TRUE) {
            return new Expression.BinaryBoolExpression(negate(tmp1), tmp2, Expression.BoolOperation.OR);
        }

        if (tmp3 == Expression.BoolConst.FALSE) {
            return new Expression.BinaryBoolExpression(tmp1, tmp2, Expression.BoolOperation.AND);
        }

        if (tmp2 instanceof Expression.IntConst && tmp3 instanceof Expression.IntConst) {
            if (((Expression.IntConst) tmp2).value.equals(((Expression.IntConst) tmp3).value)) {
                return tmp2;
            }
        }

        if (tmp1 == expression.expression1 && tmp2 == expression.expression2 && tmp3 == expression.expression3) {
            return expression;
        }

        return new Expression.ConditionalExpression(tmp1, tmp2, tmp3);
    }

    private Expression negate(Expression expression) {
        if(expression == Expression.BoolConst.FALSE) {
            return Expression.BoolConst.TRUE;
        }
        if(expression == Expression.BoolConst.TRUE) {
            return Expression.BoolConst.FALSE;
        }

        if (expression instanceof Expression.NegationExpression) {
            return ((Expression.NegationExpression) expression).expression;
        }

        return new Expression.NegationExpression(expression);
    }

    @Override
    public Expression visit(Expression.ComparisonExpression expression) {
        Expression tmp1 = expression.expression1.accept(this);
        Expression tmp2 = expression.expression2.accept(this);

        if (tmp1 instanceof Expression.IntConst && tmp2 instanceof Expression.IntConst) {
            return evaluateCompExpression(((Expression.IntConst) tmp1).value, ((Expression.IntConst) tmp2).value, expression.operation) ? Expression.BoolConst.TRUE : Expression.BoolConst.FALSE;
        }
        if (tmp1 instanceof Expression.BoolConst && tmp2 instanceof Expression.BoolConst) {
            if (expression.operation == Expression.CompOperation.EQ) {
                return ((Expression.BoolConst) tmp1).value == ((Expression.BoolConst) tmp2).value ? Expression.BoolConst.TRUE : Expression.BoolConst.FALSE;
            }
            if (expression.operation == Expression.CompOperation.NEQ) {
                return ((Expression.BoolConst) tmp1).value != ((Expression.BoolConst) tmp2).value ? Expression.BoolConst.TRUE : Expression.BoolConst.FALSE;
            }
            throw new RuntimeException("Unsupported comparison between booleans " + expression.operation + "!");
        }

        if (tmp1 instanceof Expression.BoolConst ^ tmp2 instanceof Expression.BoolConst) {
            if (expression.operation == Expression.CompOperation.EQ) {
                Expression.BoolConst boolConst = (Expression.BoolConst) (tmp1 instanceof Expression.BoolConst ? tmp1 : tmp2);
                Expression nonConst = tmp1 instanceof Expression.BoolConst ? tmp2 : tmp1;

                if (boolConst == Expression.BoolConst.FALSE) {
                    return negate(nonConst);
                } else {
                    return nonConst;
                }
            }
        }

        if (tmp1 instanceof Expression.IntConst ^ tmp2 instanceof Expression.IntConst) {
            Expression.IntConst constExp = (Expression.IntConst) (tmp1 instanceof Expression.IntConst ? tmp1 : tmp2);
            Expression nonConstExp = tmp1 instanceof Expression.IntConst ? tmp2 : tmp1;

            boolean constFirst = (tmp1 instanceof Expression.IntConst);

            Optional<ExpressionView.SimpleAdditiveTerm> optAdditiveTerm = ExpressionView.viewAsSimpleAdditiveTerm(nonConstExp);
            // TODO extend!!
            if (optAdditiveTerm.isPresent()) {
                ExpressionView.SimpleAdditiveTerm additiveTerm = optAdditiveTerm.get();

                BigInteger oldConstValue = constExp.value;
                BigInteger grandChildConst = additiveTerm.getNormalizedSummand().negate();
                Expression.CompOperation operation = expression.operation;

                if(additiveTerm.isFreeVarNegated()) {
                    oldConstValue = oldConstValue.negate();
                    grandChildConst = grandChildConst.negate();
                    operation = operationTimesMinusOne(operation);
                }

                Expression.IntConst newConst;

                newConst = new Expression.IntConst(grandChildConst.add(oldConstValue));

                if (constFirst) {
                    return new Expression.ComparisonExpression(newConst, additiveTerm.getFreeVar(), operation);
                } else {
                    return new Expression.ComparisonExpression(additiveTerm.getFreeVar(), newConst, operation);
                }
            } else if (nonConstExp instanceof Expression.ConditionalExpression) {
                if (expression.operation == Expression.CompOperation.EQ) {
                    Expression.ConditionalExpression condExpression = (Expression.ConditionalExpression) nonConstExp;

                    return new Expression.ConditionalExpression(condExpression.expression1, new Expression.ComparisonExpression(condExpression.expression2, constExp, Expression.CompOperation.EQ), new Expression.ComparisonExpression(condExpression.expression3, constExp, Expression.CompOperation.EQ)).accept(this);
                }
            }
        }

        if (tmp1 == expression.expression1 && tmp2 == expression.expression2) {
            return expression;
        }
        return new Expression.ComparisonExpression(tmp1, tmp2, expression.operation);
    }

    private static Expression.CompOperation operationTimesMinusOne(Expression.CompOperation operation) {
        switch (operation) {
            case EQ:
                return Expression.CompOperation.EQ;
            case NEQ:
                return Expression.CompOperation.NEQ;
            case GT:
                return Expression.CompOperation.LT;
            case LT:
                return Expression.CompOperation.GT;
            case GE:
                return Expression.CompOperation.LE;
            case LE:
                return Expression.CompOperation.GE;
        }

        throw new UnsupportedOperationException();
    }

    private Expression.IntOperation operationTimesMinusOne(Expression.IntOperation operation) {
        switch (operation) {
            case ADD:
                return Expression.IntOperation.SUB;
            case SUB:
                return Expression.IntOperation.ADD;
        }

        throw new UnsupportedOperationException();
    }

    private boolean evaluateCompExpression(BigInteger v1, BigInteger v2, Expression.CompOperation operation) {
        int i = v1.compareTo(v2);

        if (i == 0) {
            return operation == Expression.CompOperation.GE || operation == Expression.CompOperation.LE || operation == Expression.CompOperation.EQ;
        } else if (i < 0) {
            return operation == Expression.CompOperation.LE || operation == Expression.CompOperation.LT || operation == Expression.CompOperation.NEQ;
        } else {
            return operation == Expression.CompOperation.GE || operation == Expression.CompOperation.GT || operation == Expression.CompOperation.NEQ;
        }
    }

    @Override
    public Expression visit(Expression.ConstExpression expression) {
        return expression.value.accept(this);
    }

    @Override
    public Expression visit(Expression.SumExpression expression) {
        throw new UnsupportedOperationException("SumExpression should be eliminated at this point!");
    }

    @Override
    public Expression visit(Expression.BitvectorNegationExpression expression) {
        throw new IllegalArgumentException();
    }
}
