package secpriv.horst.translation.visitors;

import secpriv.horst.data.Clause;
import secpriv.horst.data.Proposition;

import java.util.ArrayList;
import java.util.List;

public class TransformToConjunctiveNormalFormClauseVisitor implements Clause.Visitor<Clause> {

    private final CnfTransformationClauseVisitor cnfTransformationClauseVisitor = new CnfTransformationClauseVisitor();


    @Override
    public Clause visit(Clause clause) {
        // go through all the propositions and call cnfTransformationClauseVisitor for the propositions
        List<Proposition> premises = new ArrayList<>();
        for (Proposition proposition : clause.premises){
            premises.add(proposition.accept(cnfTransformationClauseVisitor));
        }
        return new Clause(premises, clause.conclusion, clause.freeVars);
    }
}
