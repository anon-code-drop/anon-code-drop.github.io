package secpriv.horst.translation.visitors;

import secpriv.horst.data.Predicate;
import secpriv.horst.data.Proposition;

import java.util.Optional;

public class RetrievePredicatesPropositionVisitor implements Proposition.Visitor<Optional<Predicate>> {
    @Override
    public Optional<Predicate> visit(Proposition.PredicateProposition proposition) {
        return Optional.of(proposition.predicate);
    }

    @Override
    public Optional<Predicate> visit(Proposition.ExpressionProposition proposition) {
        return Optional.empty();
    }
}
