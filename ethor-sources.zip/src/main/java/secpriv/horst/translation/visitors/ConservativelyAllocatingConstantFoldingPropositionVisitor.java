package secpriv.horst.translation.visitors;

public class ConservativelyAllocatingConstantFoldingPropositionVisitor extends ExpressionMappingPropositionVisitor {
    public ConservativelyAllocatingConstantFoldingPropositionVisitor() {
        super(new ConservativelyAllocatingConstantFoldingExpressionVisitor());
    }
}
