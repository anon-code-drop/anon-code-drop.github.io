package secpriv.horst.translation.visitors;

import secpriv.horst.data.Proposition;

public class CnfTransformationClauseVisitor implements Proposition.Visitor<Proposition> {

    private final QuineMcCluskeyTransformationVisitor quineMcCluskeyTransformationVisitor = new QuineMcCluskeyTransformationVisitor();

    @Override
    public Proposition visit(Proposition.PredicateProposition proposition) {
        return proposition;
    }

    @Override
    public Proposition visit(Proposition.ExpressionProposition proposition) {
        // receiving BinaryBoolExpression -> maybe split them in a list of premises
        return new Proposition.ExpressionProposition(proposition.expression.accept(quineMcCluskeyTransformationVisitor));
    }
}
