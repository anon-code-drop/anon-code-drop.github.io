package secpriv.horst.translation.visitors;

import secpriv.horst.data.Expression;

import java.util.Map;

public class ContextSensitiveInlineEqualitiesPropositionVisitor extends ExpressionMappingPropositionVisitor {
    public ContextSensitiveInlineEqualitiesPropositionVisitor(Map<Expression.FreeVarExpression, Expression> inlines) {
        super(new ContextSensitiveInlineEqualitiesExpressionVisitor(inlines));
    }

    public boolean hasSkippedInlines() {
        return ((ContextSensitiveInlineEqualitiesExpressionVisitor) this.expressionVisitor).hasSkippedInlines();
    }
}
