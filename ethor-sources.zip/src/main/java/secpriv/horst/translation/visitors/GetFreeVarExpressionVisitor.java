package secpriv.horst.translation.visitors;

import secpriv.horst.data.Expression;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class GetFreeVarExpressionVisitor extends DefaultValueExpressionVisitor<Void> {
    private final Set<Expression.FreeVarExpression> freeVars = new HashSet<>();

    public GetFreeVarExpressionVisitor() {
        super(null);
    }

    public Set<Expression.FreeVarExpression> getFreeVars() {
        return Collections.unmodifiableSet(freeVars);
    }

    @Override
    public Void visit(Expression.FreeVarExpression expression) {
        freeVars.add(expression);
        return null;
    }

    @Override
    public Void visit(Expression.BinaryIntExpression expression) {
        return visitBinaryExpression(expression);
    }

    private Void visitBinaryExpression(Expression.BinaryExpression expression) {
        expression.expression1.accept(this);
        expression.expression2.accept(this);
        return null;
    }

    @Override
    public Void visit(Expression.BinaryBoolExpression expression) {
        return visitBinaryExpression(expression);
    }

    @Override
    public Void visit(Expression.SelectExpression expression) {
        return visitBinaryExpression(expression);
    }

    @Override
    public Void visit(Expression.StoreExpression expression) {
        return visitTernaryExpression(expression);
    }

    private Void visitTernaryExpression(Expression.TernaryExpression expression) {
        expression.expression1.accept(this);
        expression.expression2.accept(this);
        expression.expression3.accept(this);
        return null;
    }

    @Override
    public Void visit(Expression.AppExpression expression) {
        throw new RuntimeException();
    }

    @Override
    public Void visit(Expression.ConstructorAppExpression expression) {
        throw new RuntimeException();
    }

    @Override
    public Void visit(Expression.MatchExpression expression) {
        throw new RuntimeException();
    }

    @Override
    public Void visit(Expression.NegationExpression expression) {
        return visitUnaryExpression(expression);
    }

    private Void visitUnaryExpression(Expression.NegationExpression expression) {
        expression.expression.accept(this);
        return null;
    }

    @Override
    public Void visit(Expression.ConditionalExpression expression) {
        return visitTernaryExpression(expression);
    }

    @Override
    public Void visit(Expression.ComparisonExpression expression) {
        return visitBinaryExpression(expression);
    }

    @Override
    public Void visit(Expression.ConstExpression expression) {
        throw new RuntimeException();
    }

    @Override
    public Void visit(Expression.SumExpression expression) {
        throw new RuntimeException();
    }

    @Override
    public Void visit(Expression.BitvectorNegationExpression expression) {
        throw new RuntimeException();
    }
}
