package secpriv.horst.translation.visitors;

import secpriv.horst.data.Expression;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


public class QuineMcCluskeyTransformationVisitor implements Expression.Visitor<Expression> {

    @Override
    public Expression visit(Expression.IntConst expression) {
        return expression;
    }

    @Override
    public Expression visit(Expression.BoolConst expression) {
        return expression;
    }

    @Override
    public Expression visit(Expression.ArrayInitExpression expression) {
        throw new UnsupportedOperationException("ArrayIntExpressions should not be allowed here!");
    }

    @Override
    public Expression visit(Expression.VarExpression expression) {
        throw new UnsupportedOperationException("VarExpressions should not be allowed here!");
    }

    @Override
    public Expression visit(Expression.FreeVarExpression expression) {
        return expression;
    }

    @Override
    public Expression visit(Expression.ParVarExpression expression) {
        throw new UnsupportedOperationException("ParVarExpressions should not be allowed here!");
    }

    @Override
    public Expression visit(Expression.BinaryIntExpression expression) {
        throw new UnsupportedOperationException("BinaryIntExpressions should not be allowed here!");
    }

    @Override
    public Expression visit(Expression.BinaryBoolExpression expression) {
        return optimize(expression);
    }

    @Override
    public Expression visit(Expression.SelectExpression expression) {
        throw new UnsupportedOperationException("SelectExpressions should not be allowed here!");
    }

    @Override
    public Expression visit(Expression.StoreExpression expression) {
        throw new UnsupportedOperationException("StoreExpressions should not be allowed here!");
    }

    @Override
    public Expression visit(Expression.AppExpression expression) {
        throw new UnsupportedOperationException("AppExpressions should not be allowed here!");
    }

    @Override
    public Expression visit(Expression.ConstructorAppExpression expression) {
        throw new UnsupportedOperationException("ConstructorAppExpressions should not be allowed here!");
    }

    @Override
    public Expression visit(Expression.MatchExpression expression) {
        throw new UnsupportedOperationException("MatchExpressions should not be allowed here!");
    }

    @Override
    public Expression visit(Expression.NegationExpression expression) {
        return optimize(expression);
    }

    @Override
    public Expression visit(Expression.ConditionalExpression expression) {
        throw new UnsupportedOperationException("ConditionalExpression should not be allowed here!");
    }

    @Override
    public Expression visit(Expression.ComparisonExpression expression) {
        return optimize(expression);
    }

    @Override
    public Expression visit(Expression.ConstExpression expression) {
        throw new UnsupportedOperationException("ConstIntExpressions should not be allowed here!");
    }

    @Override
    public Expression visit(Expression.SumExpression expression) {
        throw new UnsupportedOperationException("SumExpressions should not be allowed here!");
    }

    @Override
    public Expression visit(Expression.BitvectorNegationExpression expression) {
        throw new UnsupportedOperationException("BitvectorNegationExpression should not be allowed here!");
    }


    private Expression optimize(Expression expression) {
        Map<String, Expression> mapping = expression.accept(new GetAllFreeVarsExpressionVisitor());

        char[][] truthTable = generateTruthTable(mapping, expression);

        ArrayList<Integer> minterms = new ArrayList<>();
        for (int i = 0; i < truthTable.length ; i++) {
            if (truthTable[i][truthTable[0].length - 1] == '1'){
                minterms.add(i);
            }
        }
        System.out.println("Minterms: " + minterms);
        // if F' is a contradiction, it means that F is tautology, hence return TRUE. If F' is tautology, that means that F is contradiction so return FALSE
        if (minterms.size() == 0) {
            return Expression.BoolConst.TRUE;
        } else if (minterms.size() == truthTable.length) {
            return Expression.BoolConst.FALSE;
        }

        ArrayList<String> essentialPrimeImplicants = findingPrimeImplicants(mapping.size(), minterms);

        // converting prime implications back to free vars
        ArrayList<Expression> expressions = new ArrayList<>();
        System.out.println("\nThe simplified expression\n");
        for (String primeImpl : essentialPrimeImplicants) {
            expressions.add(convertPrimeImplicantsToExpressions(primeImpl, mapping));
            System.out.print(essentialPrimeImplicants.indexOf(primeImpl) < essentialPrimeImplicants.size() -1 ? " && " : "");
        }

        return getFinalExpression(expressions, Expression.BoolOperation.AND, false);
    }

    private char[][] generateTruthTable(Map<String, Expression> mapping, Expression expression) {
        int numOfVariables = mapping.size();
        int numOrRows = (int) Math.pow(2, numOfVariables);

        char[][] truthTable = new char[numOrRows][numOfVariables + 2];

        // fill the truth table with zeros and ones
        for (int i = 0; i < numOrRows; i++) {
            String binaryRep = String.format("%" + numOfVariables + "s", Integer.toBinaryString(i)).replace(" ", "0");
            for (int j = 0; j < truthTable[0].length; j++) {
                if (j == numOfVariables) {

                    // evaluate the formula with the values from the current row in the truth table
                    Expression.BoolConst evaluatedExpression = expression.accept(new EvaluateTruthTableExpressionVisitor(truthTable[i], mapping));
                    truthTable[i][j] = evaluatedExpression.value == Expression.BoolConst.TRUE.value ? '1': '0';
                    truthTable[i][++j] = evaluatedExpression.value == Expression.BoolConst.TRUE.value ? '0': '1'; // negating F to obtain F' in order to later get CNF
                } else {
                    truthTable[i][j] = binaryRep.charAt(j);
                }
            }
        }

        ArrayList<String> variables = new ArrayList<>(mapping.keySet());
        variables.add("F");
        variables.add("N");
        printTable(truthTable, variables);
        return truthTable;
    }


    private void printTable(char[][] table, ArrayList<String> list) {
        if (!list.isEmpty()) {
            for (int i = 0; i < table[0].length; i++) {
                System.out.print((list.get(i).length() == 1 ? " " + list.get(i): list.get(i)) + "|");
            }
            System.out.println();
        }
        for (char[] row : table) {
            if (new String(row).trim().isEmpty()) {
                continue;
            }
            for (int j = 0; j < table[0].length; j++) {
                System.out.print(" " + row[j] + "|");
            }
            System.out.println();
        }
        System.out.println();
    }


    private ArrayList<String> findingPrimeImplicants(int numOfVariables, ArrayList<Integer> minterms) {
        System.out.println();
        char[][] mintermsBitRepMatrix = new char[minterms.size()][numOfVariables];
        char[][] primeImplicantsMatrix = new char[minterms.size()*(minterms.size() + 1)/2][numOfVariables];
        int numberOfPrimeImplicants = 0;

        binaryRepresentationOfMinterms(mintermsBitRepMatrix, minterms);

        numberOfPrimeImplicants = combiningTerms(mintermsBitRepMatrix, minterms, primeImplicantsMatrix, numberOfPrimeImplicants, numOfVariables);
        System.out.println("\nFinal prime implications table");
        printTable(primeImplicantsMatrix, new ArrayList<>());
        System.out.println("Number of prime implicants: " + numberOfPrimeImplicants);

        char[][] piCoverageChartMatrix = new char[minterms.size()*(minterms.size() + 1)/2][minterms.size()];
        generatePiCoverageChart(piCoverageChartMatrix, primeImplicantsMatrix, minterms);
        System.out.println("\nPi coverage chart");
        printTable(piCoverageChartMatrix, minterms.stream().map(Object::toString).collect(Collectors.toCollection(ArrayList::new)));

        ArrayList<Integer> essentialPrimeImplicantsIndices = findEssentialPrimeImplicants(piCoverageChartMatrix, minterms);

        ArrayList<String> essentialPrimeImplicants = new ArrayList<>();
        System.out.println("\nEssential prime implicants");
        for (Integer rowNum : essentialPrimeImplicantsIndices) {
            System.out.println(primeImplicantsMatrix[rowNum]);
            essentialPrimeImplicants.add(new String(primeImplicantsMatrix[rowNum]));
        }

        return essentialPrimeImplicants;
    }


    private void binaryRepresentationOfMinterms(char[][] mintermsBitRepMatrix, ArrayList<Integer> minterms) {
        for (int i = 0; i < mintermsBitRepMatrix.length; i++) {
            String binaryRepOfMinterm = String.format("%" + mintermsBitRepMatrix[0].length + "s", Integer.toBinaryString(minterms.get(i))).replace(" ", "0");
            for (int j = 0; j < mintermsBitRepMatrix[0].length; j++) {
                mintermsBitRepMatrix[i][j] = binaryRepOfMinterm.charAt(j);
            }
        }
        System.out.println("\nMinterms bit representation table");
        printTable(mintermsBitRepMatrix, new ArrayList<>());
    }


    private int combiningTerms(char[][] mintermsBitRepMatrix, ArrayList<Integer> minterms, char[][] primImplicantsMatrix, int numberOfPrimeImplicants, int numOfVariables) {
        char[][] tempMintermsMatrix = new char[minterms.size()*(minterms.size() + 1)/2][numOfVariables];
        int rowOfPrimeImcplicantsMatrix = 0;
        for(int i = 0; i < mintermsBitRepMatrix.length; i++) {
            System.arraycopy(mintermsBitRepMatrix[i], 0, tempMintermsMatrix[i], 0, mintermsBitRepMatrix[i].length);
        }

        while (true) {
            char[][] mintermsWithOneBitDifferenceMatrix = new char[minterms.size()*(minterms.size() + 1)/2][numOfVariables]; // temporary matrix to hold comparision for current round
            int rowOfMintermsWithDifferentBitMatrix = 0;
            int numOfCombinedTerms = 0;
            int[] areMintermsCombined = new int[minterms.size()*(minterms.size() + 1)/2];

            // compare minterms with one another, take the one that differ in one bit
            for (int outerRow = 0; outerRow < tempMintermsMatrix.length; outerRow++) {
                if (new String(tempMintermsMatrix[outerRow]).trim().isEmpty()) {
                    continue;
                }

                inner: for (int innerRow = outerRow + 1; innerRow < tempMintermsMatrix.length; innerRow++) {
                    if (new String(tempMintermsMatrix[innerRow]).trim().isEmpty()) {
                        continue;
                    }

                    if (Arrays.equals(tempMintermsMatrix[outerRow], tempMintermsMatrix[innerRow])) {
                        continue;
                    }

                    // compare the bits one by one
                    int diff = 0;
                    int diffBitPosition = 0;
                    for (int bitPosition = 0; bitPosition < tempMintermsMatrix[outerRow].length; bitPosition++) {
                        if (tempMintermsMatrix[outerRow][bitPosition] != tempMintermsMatrix[innerRow][bitPosition]) {
                            diff++;
                            diffBitPosition = bitPosition;
                        }
                    }

                    if (diff == 1) {
                        // if the minterms are different in only one bit, save the pair
                        numOfCombinedTerms++;
                        areMintermsCombined[outerRow]++;
                        areMintermsCombined[innerRow]++;
                        String outerRowString = new String(tempMintermsMatrix[outerRow]);

                        // if this combination is already saved, just ignore it
                        for (char[] rowOfMinterWithOneBitDiff : mintermsWithOneBitDifferenceMatrix) {
                            if (new String(rowOfMinterWithOneBitDiff).trim().isEmpty()) {
                                continue;
                            }
                            StringBuilder row = new StringBuilder(outerRowString);
                            row.setCharAt(diffBitPosition, '-');
                            if (new String(rowOfMinterWithOneBitDiff).contentEquals(row)) {
                                continue inner;
                            }
                        }

                        System.arraycopy(tempMintermsMatrix[outerRow], 0, mintermsWithOneBitDifferenceMatrix[rowOfMintermsWithDifferentBitMatrix], 0, tempMintermsMatrix[outerRow].length);
                        mintermsWithOneBitDifferenceMatrix[rowOfMintermsWithDifferentBitMatrix++][diffBitPosition] = '-';
                    }
                }
            }

            // save the minterms that haven't been combined as prime implications
            for (int row = 0; row < tempMintermsMatrix.length; row++) {
                if (areMintermsCombined[row] == 0) {
                    if (new String(tempMintermsMatrix[row]).trim().isEmpty()) {
                        continue;
                    }

                    System.arraycopy(tempMintermsMatrix[row], 0, primImplicantsMatrix[rowOfPrimeImcplicantsMatrix++], 0, tempMintermsMatrix[row].length);
                    numberOfPrimeImplicants++;
                }
            }

            // no more combinations possible
            if (numOfCombinedTerms == 0) {
                break;
            }
            System.out.println("\nMinterms with one different bit table");
            printTable(mintermsWithOneBitDifferenceMatrix, new ArrayList<>());


            // copy found pairs to minitermsBitRepMatrix to check for further pairings
            for(int i = 0; i < tempMintermsMatrix.length; i++) {
                System.arraycopy(mintermsWithOneBitDifferenceMatrix[i], 0, tempMintermsMatrix[i], 0, tempMintermsMatrix[i].length);
            }
        }
        return numberOfPrimeImplicants;
    }


    private void generatePiCoverageChart(char[][] piCoverageChartMatrix, char[][] primeImplicantsMatrix, ArrayList<Integer> minterms) {

        for (int row = 0; row < primeImplicantsMatrix.length; row++) {
            ArrayList<Integer> mintermsCombined = new ArrayList<>();
            if (new String(primeImplicantsMatrix[row]).trim().isEmpty()) {
                continue;
            }
            System.out.println("Row " + Arrays.toString(primeImplicantsMatrix[row]));

            Arrays.fill(piCoverageChartMatrix[row], ' ');

            // finding out which minterms are combined for this prime implicant
            String stringRepOfRow = new String(primeImplicantsMatrix[row]);
            if (stringRepOfRow.contains("-")) {
                mintermsCombined.addAll(decodeDashes(new ArrayList<>(), stringRepOfRow));
            } else {
                mintermsCombined.add(Integer.parseInt(stringRepOfRow, 2));
            }

            // mark which minterms are combined for which prime implicant
            for (Integer minterm : mintermsCombined) {
                piCoverageChartMatrix[row][minterms.indexOf(minterm)] = 'x';
            }
        }
    }

    private List<Integer> decodeDashes(ArrayList<Integer> list, String stringRepOfRow) {
        if (!stringRepOfRow.contains("-")) {
            list.add(Integer.parseInt(stringRepOfRow, 2));
            return list;
        } else  {
            decodeDashes(list, stringRepOfRow.replaceFirst("-", "1"));
            decodeDashes(list, stringRepOfRow.replaceFirst("-", "0"));
            return list;
        }
    }


    private ArrayList<Integer> findEssentialPrimeImplicants(char[][] piCoverageChartMatrix, ArrayList<Integer> minterms) {
        ArrayList<Integer> essentialsPrimeImplicatns =  new ArrayList<>();
        int[] mintermContained = new int[piCoverageChartMatrix[0].length];


        // count by how many prime implicats can the minterm be covered
        for (char[] row : piCoverageChartMatrix) {
            for (int col = 0; col <row.length; col++)
                if (row[col] == 'x') {
                    mintermContained[col]++;
                }
        }

        // if there are no more essential prime implicants return
        if (Arrays.stream(mintermContained).filter(mintermsCount -> mintermsCount == 1).findAny().orElse(0) == 0) {
            return essentialsPrimeImplicatns;
        }

        // mark which rows in primeImplicantsMatrix are essential
        for (int count = 0; count < mintermContained.length; count++) {
            if (mintermContained[count] == 1) {
                for (int row = 0; row < piCoverageChartMatrix.length; row++) {
                    if (piCoverageChartMatrix[row][count] == 'x') {
                        essentialsPrimeImplicatns.add(row);
                        Arrays.fill(piCoverageChartMatrix[row], ' ');
                    }
                }
            }
        }

        System.out.println("\nPi coverage chart after extracting essentials");
        printTable(piCoverageChartMatrix, minterms.stream().map(Object::toString).collect(Collectors.toCollection(ArrayList::new)));

        return essentialsPrimeImplicatns;
    }


    private Expression convertPrimeImplicantsToExpressions(String primeImpl, Map<String, Expression> freeVars) {
        // 1s and 0s are reversed, because we are dealing with F' and want CNF, not DNF
        ArrayList<Expression> expressions = new ArrayList<>();
        boolean isFirst = true;
        System.out.print("(");
        for(int index = 0; index < primeImpl.length(); index++) {
            if (primeImpl.charAt(index) == '1') {
                if (!isFirst) {
                    System.out.print(" || ");
                }
                System.out.print("~" + new ArrayList<>(freeVars.keySet()).get(index));
                expressions.add(new Expression.NegationExpression(new ArrayList<>(freeVars.values()).get(index)));
                isFirst = false;
            } else if (primeImpl.charAt(index) == '0') {
                if (!isFirst) {
                    System.out.print(" || ");
                }
                System.out.print(new ArrayList<>(freeVars.keySet()).get(index));
                expressions.add(new ArrayList<>(freeVars.values()).get(index));
                isFirst = false;
            }
        }
        System.out.print(")");

        return getFinalExpression(expressions, Expression.BoolOperation.OR, true);
    }


    private Expression getFinalExpression(List<Expression> expressions, Expression.BoolOperation boolOperation, boolean negate) {
        if (expressions.size() == 1) {
            return expressions.get(0);
        } else {
            return new Expression.BinaryBoolExpression(getFinalExpression(expressions.subList(0, expressions.size()/2), boolOperation, negate),
                    getFinalExpression(expressions.subList(expressions.size()/2 , expressions.size()), boolOperation, negate),
                    boolOperation);
        }
    }

}

