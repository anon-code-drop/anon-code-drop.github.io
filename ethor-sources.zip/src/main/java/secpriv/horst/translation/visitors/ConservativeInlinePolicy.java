package secpriv.horst.translation.visitors;

import secpriv.horst.data.Expression;
import secpriv.horst.data.ExpressionView;

import java.util.Optional;

public class ConservativeInlinePolicy implements InlinePolicy {
    public static final ConservativeInlinePolicy instance = new ConservativeInlinePolicy();

    @Override
    public boolean isInlineOkay(Expression parent, Expression.FreeVarExpression freeVar, Expression inlinedValue) {
        class IsInlineOkayValueVisitor extends DefaultValueExpressionVisitor<Boolean> {
            private IsInlineOkayValueVisitor() {
                super(false);
            }

            @Override
            public Boolean visit(Expression.FreeVarExpression expression) {
                return true;
            }

            @Override
            public Boolean visit(Expression.IntConst expression) {
                return true;
            }

            @Override
            public Boolean visit(Expression.ArrayInitExpression expression) {
                return expression.initializer.accept(this);
            }

            @Override
            public Boolean visit(Expression.BoolConst expression) {
                return true;
            }

            @Override
            public Boolean visit(Expression.BinaryIntExpression expression) {
                return ExpressionView.viewAsSimpleAdditiveTerm(expression).isPresent();
            }

            @Override
            public Boolean visit(Expression.BinaryBoolExpression expression) {
                return false;
            }

            @Override
            public Boolean visit(Expression.StoreExpression valueStoreExpression) {
                class IsInlineStoreOkayContextVisitor extends DefaultValueExpressionVisitor<Boolean> {
                    private IsInlineStoreOkayContextVisitor() {
                        super(false);
                    }

                    @Override
                    public Boolean visit(Expression.StoreExpression parentStoreExpression) {
                        Optional<ExpressionView.SimpleArray> optParentArray = ExpressionView.viewAsSimpleArray(parentStoreExpression);
                        Optional<ExpressionView.SimpleArray> optValueArray = ExpressionView.viewAsSimpleArray(valueStoreExpression);

                        return optParentArray.flatMap(p -> optValueArray.map(v -> v.isIndexCompatible(p))).orElse(false);
                    }

                    @Override
                    public Boolean visit(Expression.SelectExpression parentSelectExpression) {
                        if (!parentSelectExpression.expression1.equals(freeVar)) {
                            return false;
                        }

                        Optional<ExpressionView.SimpleAdditiveTerm> optIndex = ExpressionView.viewAsSimpleAdditiveTerm(parentSelectExpression.expression2);
                        Optional<ExpressionView.SimpleArray> optValueArray = ExpressionView.viewAsSimpleArray(valueStoreExpression);

                        return optIndex.flatMap(i -> optValueArray.map(v -> v.isIndexCompatible(i))).orElse(false);
                    }
                }
                if (parent == null) {
                    return true;
                }

                return parent.accept(new IsInlineStoreOkayContextVisitor());
            }
        }

        return inlinedValue.accept(new IsInlineOkayValueVisitor());
    }
}
