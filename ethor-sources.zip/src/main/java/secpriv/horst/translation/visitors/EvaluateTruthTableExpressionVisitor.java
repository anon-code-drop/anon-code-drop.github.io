package secpriv.horst.translation.visitors;

import secpriv.horst.data.Expression;

import java.util.ArrayList;
import java.util.Map;

public class EvaluateTruthTableExpressionVisitor implements Expression.Visitor<Expression.BoolConst> {

    private final ConstantFoldingExpressionVisitor constantFoldingExpressionVisitor = new ConstantFoldingExpressionVisitor();
    private final ArrayList<String> freeVars;
    private final char[] row;
    private final Map<String, Expression> mapping;

    EvaluateTruthTableExpressionVisitor(char[] row, Map<String, Expression> mapping) {
        this.freeVars = new ArrayList<>(mapping.keySet());
        this.row = row;
        this.mapping = mapping;
    }

    @Override
    public Expression.BoolConst visit(Expression.IntConst expression) {
        throw new UnsupportedOperationException("IntConst should not be allowed here!");
    }

    @Override
    public Expression.BoolConst visit(Expression.BoolConst expression) {
        return expression;
    }

    @Override
    public Expression.BoolConst visit(Expression.ArrayInitExpression expression) {
        throw new UnsupportedOperationException("ArrayInitExpression should not be allowed here!");
    }

    @Override
    public Expression.BoolConst visit(Expression.VarExpression expression) {
        throw new UnsupportedOperationException("VarExpression should not be allowed here!");
    }

    @Override
    public Expression.BoolConst visit(Expression.FreeVarExpression expression) {
        int index = freeVars.indexOf(expression.name);
        return row[index] == '1' ? Expression.BoolConst.TRUE : Expression.BoolConst.FALSE;
    }

    @Override
    public Expression.BoolConst visit(Expression.ParVarExpression expression) {
        throw new UnsupportedOperationException("ParVarExpression should not be allowed here!");
    }

    @Override
    public Expression.BoolConst visit(Expression.BinaryIntExpression expression) {
        throw new UnsupportedOperationException("BinaryIntExpression should not be allowed here!");
    }

    @Override
    public Expression.BoolConst visit(Expression.BinaryBoolExpression expression) {
        Expression child1 = expression.expression1.accept(this);
        Expression child2 = expression.expression2.accept(this);

        return (Expression.BoolConst) new Expression.BinaryBoolExpression(child1, child2, expression.operation).accept(constantFoldingExpressionVisitor);
    }

    @Override
    public Expression.BoolConst visit(Expression.SelectExpression expression) {
        String key = mapping.entrySet().stream().filter(entry -> expression.equals(entry.getValue())).map(Map.Entry::getKey).findFirst().get();
        int index = freeVars.indexOf(key);
        return row[index] == '1' ? Expression.BoolConst.TRUE : Expression.BoolConst.FALSE;
    }

    @Override
    public Expression.BoolConst visit(Expression.StoreExpression expression) {
        throw new UnsupportedOperationException("StoreExpression should not be allowed here!");
    }

    @Override
    public Expression.BoolConst visit(Expression.AppExpression expression) {
        throw new UnsupportedOperationException("AppExpression should not be allowed here!");
    }

    @Override
    public Expression.BoolConst visit(Expression.ConstructorAppExpression expression) {
        throw new UnsupportedOperationException("ConstructorAppExpression should not be allowed here!");
    }

    @Override
    public Expression.BoolConst visit(Expression.MatchExpression expression) {
        throw new UnsupportedOperationException("MatchExpression should not be allowed here!");
    }

    @Override
    public Expression.BoolConst visit(Expression.NegationExpression expression) {
        return (Expression.BoolConst) new Expression.NegationExpression(expression.expression.accept(this)).accept(constantFoldingExpressionVisitor);
    }

    @Override
    public Expression.BoolConst visit(Expression.ConditionalExpression expression) {
        throw new UnsupportedOperationException("ConditionalExpression should not be allowed here!");
    }

    @Override
    public Expression.BoolConst visit(Expression.ComparisonExpression expression) {
        String key = mapping.entrySet().stream().filter(entry -> expression.equals(entry.getValue())).map(Map.Entry::getKey).findFirst().get();
        int index = freeVars.indexOf(key);
        return row[index] == '1' ? Expression.BoolConst.TRUE : Expression.BoolConst.FALSE;
    }

    @Override
    public Expression.BoolConst visit(Expression.ConstExpression expression) {
        throw new UnsupportedOperationException("ConstExpression should not be allowed here!");
    }

    @Override
    public Expression.BoolConst visit(Expression.SumExpression expression) {
        throw new UnsupportedOperationException("SumExpression should not be allowed here!");
    }

    @Override
    public Expression.BoolConst visit(Expression.BitvectorNegationExpression expression) {
        throw new UnsupportedOperationException("BitvectorNegationExpression should not be allowed here!");
    }
}
