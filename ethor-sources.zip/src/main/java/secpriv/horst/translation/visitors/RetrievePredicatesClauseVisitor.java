package secpriv.horst.translation.visitors;

import secpriv.horst.data.Clause;
import secpriv.horst.data.Predicate;
import secpriv.horst.translation.MediumStepTransformer;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class RetrievePredicatesClauseVisitor implements Clause.Visitor<List<Predicate>> {
    @Override
    public List<Predicate> visit(Clause clause) {
        RetrievePredicatesPropositionVisitor propositionVisitor = new RetrievePredicatesPropositionVisitor();
        return Stream.concat(clause.premises.stream().map(p -> p.accept(propositionVisitor)).filter(Optional::isPresent).map(Optional::get), Stream.of(clause.conclusion.predicate)).collect(Collectors.toList());
    }
}
