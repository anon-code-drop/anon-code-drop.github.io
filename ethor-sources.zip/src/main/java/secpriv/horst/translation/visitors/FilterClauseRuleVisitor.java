package secpriv.horst.translation.visitors;

import secpriv.horst.data.Clause;
import secpriv.horst.translation.ClauseFilteringRuleVisitor;

import java.util.Optional;
import java.util.Set;
import java.util.function.Function;

public class FilterClauseRuleVisitor extends ClauseFilteringRuleVisitor {
    public FilterClauseRuleVisitor(Set<Clause> filteredClauses) {
        super((Function<Clause, Optional<Clause>>) (c -> filteredClauses.contains(c) ? Optional.empty() : Optional.of(c)));
    }
}
