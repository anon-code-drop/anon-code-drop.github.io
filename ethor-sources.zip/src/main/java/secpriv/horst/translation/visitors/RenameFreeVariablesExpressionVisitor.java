package secpriv.horst.translation.visitors;

import secpriv.horst.data.Expression;

import java.util.Collections;
import java.util.Map;

public class RenameFreeVariablesExpressionVisitor extends AbstractExpressionVisitor {
    final private Map<String, String> renamingMap;

    public RenameFreeVariablesExpressionVisitor(Map<String, String> renamingMap) {
        this.renamingMap = Collections.unmodifiableMap(renamingMap);
    }

    @Override
    public Expression visit(Expression.FreeVarExpression expression) {
        if(renamingMap.containsKey(expression.name)) {
            String newName = renamingMap.get(expression.name);
            return new Expression.FreeVarExpression(expression.type, newName);
        }
        return expression;
    }
}
