package secpriv.horst.translation.visitors;

import secpriv.horst.data.Expression;

import java.util.Map;
import java.util.TreeMap;

public class GetAllFreeVarsExpressionVisitor implements Expression.Visitor<Map<String,Expression>> {

    private Map<String, Expression> mapping = new TreeMap<>();
    private char expressionCounter = 'A';

    @Override
    public Map<String, Expression> visit(Expression.IntConst expression) {
        throw new UnsupportedOperationException("IntConst should not be allowed here!");
    }

    @Override
    public Map<String, Expression> visit(Expression.BoolConst expression) {
        throw new UnsupportedOperationException("BoolConst should not be allowed here!");
    }

    @Override
    public Map<String, Expression> visit(Expression.ArrayInitExpression expression) {
        throw new UnsupportedOperationException("ArrayInitExpression should not be allowed here!");
    }

    @Override
    public Map<String, Expression> visit(Expression.VarExpression expression) {
        throw new UnsupportedOperationException("VarExpression should not be allowed here!");
    }

    @Override
    public Map<String, Expression> visit(Expression.FreeVarExpression expression) {
        if (!mapping.containsKey(expression.name)) {
            mapping.put(expression.name, expression);
        }
        return mapping;
    }

    @Override
    public Map<String, Expression> visit(Expression.ParVarExpression expression) {
        throw new UnsupportedOperationException("ParVarExpression should not be allowed here!");
    }

    @Override
    public Map<String, Expression> visit(Expression.BinaryIntExpression expression) {
        throw new UnsupportedOperationException("BinaryIntExpression should not be allowed here!");
    }

    @Override
    public Map<String, Expression> visit(Expression.BinaryBoolExpression expression) {
        expression.expression1.accept(this);
        expression.expression2.accept(this);
        return mapping;
    }

    @Override
    public Map<String, Expression> visit(Expression.SelectExpression expression) {
        if (!mapping.containsValue(expression)) {
            mapping.put("+" + expressionCounter++, expression);  // save select expression as +x variables to be able to distinguish them from free vars and comparison expressions
        }
        return mapping;
    }

    @Override
    public Map<String, Expression> visit(Expression.StoreExpression expression) {
        throw new UnsupportedOperationException("StoreExpression should not be allowed here!");
    }

    @Override
    public Map<String, Expression> visit(Expression.AppExpression expression) {
        throw new UnsupportedOperationException("AppExpression should not be allowed here!");
    }

    @Override
    public Map<String, Expression> visit(Expression.ConstructorAppExpression expression) {
        throw new UnsupportedOperationException("ConstructorAppExpression should not be allowed here!");
    }

    @Override
    public Map<String, Expression> visit(Expression.MatchExpression expression) {
        throw new UnsupportedOperationException("MatchExpression should not be allowed here!");
    }

    @Override
    public Map<String, Expression> visit(Expression.NegationExpression expression) {
        expression.expression.accept(this);
        return mapping;
    }

    @Override
    public Map<String, Expression> visit(Expression.ConditionalExpression expression) {
        throw new UnsupportedOperationException("ConditionalExpression should not be allowed here!");
    }

    @Override
    public Map<String, Expression> visit(Expression.ComparisonExpression expression) {
        if (!mapping.containsValue(expression)) {
            mapping.put("." + expressionCounter++, expression);  // save comparision expressions as .x variables to be able to distinguish them from free vars and select expression
        }
        return mapping;
    }

    @Override
    public Map<String, Expression> visit(Expression.ConstExpression expression) {
        throw new UnsupportedOperationException("ConstExpression should not be allowed here!");
    }

    @Override
    public Map<String, Expression> visit(Expression.SumExpression expression) {
        throw new UnsupportedOperationException("SumExpression should not be allowed here!");
    }

    @Override
    public Map<String, Expression> visit(Expression.BitvectorNegationExpression expression) {
        throw new UnsupportedOperationException("BitvectorNegationExpression should not be allowed here!");
    }
}
