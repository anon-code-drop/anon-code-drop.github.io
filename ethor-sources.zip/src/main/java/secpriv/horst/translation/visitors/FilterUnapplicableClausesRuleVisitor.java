package secpriv.horst.translation.visitors;

import secpriv.horst.data.Clause;
import secpriv.horst.data.Rule;
import secpriv.horst.tools.PredicateHelper;

import java.util.List;
import java.util.stream.Collectors;

public class FilterUnapplicableClausesRuleVisitor implements Rule.Visitor<Rule> {
    @Override
    public Rule visit(Rule rule) {
        //TODO make return Optional and filter
        List<Clause> filteredClauses = rule.clauses.stream().filter(this::impliesNoQueryAndDoesNotContainFalsePremise).collect(Collectors.toList());

        return new Rule(rule.name, rule.selectorFunctionInvocation, filteredClauses);
    }

    private boolean impliesNoQueryAndDoesNotContainFalsePremise(Clause clause) {
        if (PredicateHelper.isQueryOrTest(clause.conclusion.predicate)) {
            return true;
        }

        FilterFalsePropositionVisitor filterFalsePropositionVisitor = new FilterFalsePropositionVisitor();
        return clause.premises.stream().allMatch(p -> p.accept(filterFalsePropositionVisitor));
    }
}
