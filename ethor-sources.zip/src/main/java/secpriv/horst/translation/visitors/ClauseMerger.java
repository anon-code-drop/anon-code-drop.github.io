package secpriv.horst.translation.visitors;

import secpriv.horst.data.Clause;
import secpriv.horst.data.Expression;
import secpriv.horst.data.Proposition;
import secpriv.horst.tools.Zipper;
import secpriv.horst.translation.FreeVariableScope;
import secpriv.horst.types.Type;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ClauseMerger {
    private class FilterConclusionVisitor implements Proposition.Visitor<Boolean> {
        final String filteredName;

        private FilterConclusionVisitor(String filteredName) {
            this.filteredName = filteredName;
        }

        @Override
        public Boolean visit(Proposition.PredicateProposition proposition) {
            return !proposition.predicate.name.equals(filteredName);
        }

        @Override
        public Boolean visit(Proposition.ExpressionProposition proposition) {
            return true;
        }
    }

    public Clause merge(List<Clause> clauses) {
        Clause currentClause = clauses.get(0);
        List<Proposition> currentPremises = new ArrayList<>(currentClause.premises);
        Map<String, Type> currentFreeVars = new HashMap<>(currentClause.freeVars);
        Map<String, String> renames = new HashMap<>();

        for (int i = 1; i < clauses.size(); ++i) {
            Clause clauseToMerge = clauses.get(i);

            final Clause currentClauseForLambda = currentClause;

            Proposition.PredicateProposition filteredPredicate =
                    (Proposition.PredicateProposition) clauseToMerge.premises.stream().filter(p ->
                            !p.accept(new FilterConclusionVisitor(currentClauseForLambda.conclusion.predicate.name))).findFirst().get();
            // creating rename map
            for (int j = 0; j < currentClause.conclusion.arguments.size(); ++j) {
                String name1 = ((Expression.FreeVarExpression) filteredPredicate.arguments.get(j)).name;
                String name2 = ((Expression.FreeVarExpression) currentClause.conclusion.arguments.get(j)).name;
                renames.put(name1, name2);
            }
            // renaming variables in the premise expressions
            clauseToMerge.premises.stream().filter(p ->
                    p.accept(new FilterConclusionVisitor(currentClauseForLambda.conclusion.predicate.name))).forEach(currentPremises::add);

            currentPremises =
                    currentPremises.stream().map(p ->
                            p.accept(new RenameFreeVariablesPropositionVisitor(renames))).collect(Collectors.toList());
            //renaming variables in conclusion
            Proposition.PredicateProposition currentConclusion =
                    (Proposition.PredicateProposition) clauseToMerge.conclusion.accept(new RenameFreeVariablesPropositionVisitor(renames));
            // renaming free variables
            Map<String, Type> clauseToMergeFreeVars = new HashMap<>(clauseToMerge.freeVars);
            Map<String, Type> filteredToMergeFreeVars = new HashMap<>();
            for (Map.Entry<String, Type> freeVar : clauseToMergeFreeVars.entrySet()) {
                if (!renames.containsKey(freeVar.getKey())) {
                    filteredToMergeFreeVars.put(freeVar.getKey(), freeVar.getValue());
                }
            }
            currentFreeVars.putAll(filteredToMergeFreeVars);

            currentClause = new Clause(currentPremises, currentConclusion, currentFreeVars);
        }
        return currentClause;
    }

    public Clause resolve(Clause clause1, Clause clause2) {
        //TODO check for predicate equality instead of strings
        FilterConclusionVisitor filterConclusionVisitor = new FilterConclusionVisitor(clause1.conclusion.predicate.name);

        //TODO make more efficient by applying scoping only when there are conflicting freevar names
        clause1 = scopeFreeVariables(clause1);
        clause2 = scopeFreeVariables(clause2);

        Map<Boolean, List<Proposition>> partitionedPremises = clause2.premises.stream().collect(Collectors.groupingBy(p -> p.accept(filterConclusionVisitor)));
        List<Proposition> resolutionCandidates = partitionedPremises.getOrDefault(false, Collections.emptyList());
        if (resolutionCandidates.size() != 1) {
            throw new IllegalArgumentException("The predicate implied by clause1 has to appear exactly once in the premises of clause2 but occurred " + resolutionCandidates.size() + " times!");
        }

        Proposition.PredicateProposition resolvedPremise = (Proposition.PredicateProposition) resolutionCandidates.get(0);
        Proposition.PredicateProposition removedConclusion = clause1.conclusion;

        Map<String, String> unifier = new HashMap<>();
        Zipper.zipList(removedConclusion.arguments, resolvedPremise.arguments, (e1, e2) -> unifier.put(((Expression.FreeVarExpression) e1).name, ((Expression.FreeVarExpression) e2).name));

        RenameFreeVariablesPropositionVisitor unifyingVisitor = new RenameFreeVariablesPropositionVisitor(unifier);

        //TODO make more efficient by applying renaming only one set of premises
        List<Proposition> resolvedPremises = Stream.concat(clause1.premises.stream(), partitionedPremises.getOrDefault(true, Collections.emptyList()).stream()).map(p -> p.accept(unifyingVisitor)).collect(Collectors.toList());
        Proposition.PredicateProposition resolvedConclusion = (Proposition.PredicateProposition) clause2.conclusion.accept(unifyingVisitor);
        Map<String, Type> resolvedFreeVars = Stream.concat(clause1.freeVars.entrySet().stream(), clause2.freeVars.entrySet().stream()).filter(e -> !unifier.containsKey(e.getKey())).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

        return new Clause(resolvedPremises, resolvedConclusion, resolvedFreeVars);
    }

    private Clause scopeFreeVariables(Clause clause) {
        FreeVariableScope scope = new FreeVariableScope();
        Map<String, String> renames = new HashMap<>();
        for (String name : clause.freeVars.keySet()) {
            renames.put(name, scope.addOrReplaceScope(name));
        }

        RenameFreeVariablesClauseVisitor renameFreeVariablesClauseVisitor = new RenameFreeVariablesClauseVisitor(renames);

        return clause.accept(renameFreeVariablesClauseVisitor);
    }
}
