package secpriv.horst.translation.visitors;

public class ConservativelyAllocatingConstantFoldingRuleVisitor extends ClauseMappingRuleVisitor {
    public ConservativelyAllocatingConstantFoldingRuleVisitor() {
        super(new PropositionMappingClauseVisitor(new ExpressionMappingPropositionVisitor(new ConservativelyAllocatingConstantFoldingExpressionVisitor())));
    }
}
