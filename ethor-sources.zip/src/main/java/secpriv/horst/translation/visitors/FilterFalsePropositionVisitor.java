package secpriv.horst.translation.visitors;

import secpriv.horst.data.Expression;
import secpriv.horst.data.Proposition;

class FilterFalsePropositionVisitor implements Proposition.Visitor<Boolean> {
    @Override
    public Boolean visit(Proposition.PredicateProposition proposition) {
        return true;
    }

    @Override
    public Boolean visit(Proposition.ExpressionProposition proposition) {
        return proposition.expression != Expression.BoolConst.FALSE;
    }
}
