package secpriv.horst.translation.visitors;

import secpriv.horst.data.Clause;
import secpriv.horst.data.Expression;

import java.util.Map;

public class HasPotentialInlinesClauseVisitor implements Clause.Visitor<Boolean> {
    private final HasPotentialInlinesPropositionVisitor propositionVisitor;

    public HasPotentialInlinesClauseVisitor(Map<Expression.FreeVarExpression, Expression> inlines) {
        propositionVisitor = new HasPotentialInlinesPropositionVisitor(inlines);
    }

    @Override
    public Boolean visit(Clause clause) {
        boolean ret =  clause.premises.stream().anyMatch(p -> p.accept(propositionVisitor));
        ret |= clause.conclusion.accept(propositionVisitor);
        return ret;
    }

    public boolean haveInlinesBeenEncountered() {
        return propositionVisitor.haveInlinesBeenEncountered();
    }
}
