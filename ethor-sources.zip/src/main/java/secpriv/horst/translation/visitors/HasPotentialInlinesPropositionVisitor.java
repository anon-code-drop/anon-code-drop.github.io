package secpriv.horst.translation.visitors;

import secpriv.horst.data.Expression;
import secpriv.horst.data.Proposition;

import java.util.Map;

public class HasPotentialInlinesPropositionVisitor implements Proposition.Visitor<Boolean> {
    private final HasPotentialInlinesExpressionVisitor expressionVisitor;

    public HasPotentialInlinesPropositionVisitor(Map<Expression.FreeVarExpression, Expression> inlines) {
        expressionVisitor = new HasPotentialInlinesExpressionVisitor(inlines);
    }

    @Override
    public Boolean visit(Proposition.PredicateProposition proposition) {
        // These do are not taken into consideration because predicate proposition are never the target of value inlines
        // however, for the purpose of "encountering" freevars (so that constraints do no get deleted) we visit the arguments
        proposition.arguments.forEach(a -> a.accept(expressionVisitor));
        return false;
    }

    @Override
    public Boolean visit(Proposition.ExpressionProposition proposition) {
        return proposition.expression.accept(expressionVisitor);
    }

    public boolean haveInlinesBeenEncountered() {
        return expressionVisitor.haveInlinesBeenEncountered();
    }
}
