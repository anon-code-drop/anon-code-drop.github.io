package secpriv.horst.translation.visitors;

import secpriv.horst.data.Expression;

import java.util.Map;

public class HasPotentialInlinesExpressionVisitor implements Expression.Visitor<Boolean> {
    private final InlinePolicy inlinePolicy = ConservativeInlinePolicy.instance;

    private Expression parent;
    private boolean isEncountered = false;
    private final Map<Expression.FreeVarExpression, Expression> inlines;

    public HasPotentialInlinesExpressionVisitor(Map<Expression.FreeVarExpression, Expression> inlines) {
        this.inlines = inlines;
    }


    @Override
    public Boolean visit(Expression.IntConst expression) {
        return false;
    }

    @Override
    public Boolean visit(Expression.BoolConst expression) {
        return false;
    }

    @Override
    public Boolean visit(Expression.ArrayInitExpression expression) {
        parent = expression;
        return expression.initializer.accept(this);
    }

    @Override
    public Boolean visit(Expression.VarExpression expression) {
        return false;
    }


    @Override
    public Boolean visit(Expression.FreeVarExpression expression) {
        if (inlines.containsKey(expression)) {
            isEncountered = true;
            return inlinePolicy.isInlineOkay(parent, expression, inlines.get(expression));
        }

        return false;
    }

    @Override
    public Boolean visit(Expression.ParVarExpression expression) {
        return false;
    }

    private Boolean visitBinaryExpression(Expression.BinaryExpression expression) {
        parent = expression;
        boolean child1 = expression.expression1.accept(this);

        if (isEncountered && child1) {
            return true;
        }

        parent = expression;
        boolean child2 = expression.expression2.accept(this);

        return child1 || child2;
    }

    @Override
    public Boolean visit(Expression.BinaryIntExpression expression) {
        return visitBinaryExpression(expression);
    }

    @Override
    public Boolean visit(Expression.BinaryBoolExpression expression) {
        return visitBinaryExpression(expression);
    }

    @Override
    public Boolean visit(Expression.SelectExpression expression) {
        return visitBinaryExpression(expression);
    }


    private Boolean visitTernary(Expression.TernaryExpression expression) {
        parent = expression;
        boolean child1 = expression.expression1.accept(this);

        if (isEncountered && child1) {
            return true;
        }
        parent = expression;
        boolean child2 = expression.expression2.accept(this);

        if (isEncountered && (child1 || child2)) {
            return true;
        }

        parent = expression;
        boolean child3 = expression.expression3.accept(this);

        return child1 || child2 || child3;
    }

    @Override
    public Boolean visit(Expression.StoreExpression expression) {
        return visitTernary(expression);
    }

    @Override
    public Boolean visit(Expression.AppExpression expression) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Boolean visit(Expression.ConstructorAppExpression expression) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Boolean visit(Expression.MatchExpression expression) {
        throw new UnsupportedOperationException();
    }

    private Boolean visitUnaryExpression(Expression.UnaryExpression expression) {
        parent = expression;
        return expression.expression.accept(this);
    }

    @Override
    public Boolean visit(Expression.NegationExpression expression) {
        return visitUnaryExpression(expression);
    }

    @Override
    public Boolean visit(Expression.ConditionalExpression expression) {
        return visitTernary(expression);
    }

    @Override
    public Boolean visit(Expression.ComparisonExpression expression) {
        return visitBinaryExpression(expression);
    }

    @Override
    public Boolean visit(Expression.ConstExpression expression) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Boolean visit(Expression.SumExpression expression) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Boolean visit(Expression.BitvectorNegationExpression expression) {
        throw new UnsupportedOperationException();
    }

    public boolean haveInlinesBeenEncountered() {
        return isEncountered;
    }
}
