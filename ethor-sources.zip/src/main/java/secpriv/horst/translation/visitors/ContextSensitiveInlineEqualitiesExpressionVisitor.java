package secpriv.horst.translation.visitors;

import secpriv.horst.data.Expression;
import secpriv.horst.data.ExpressionView;
import secpriv.horst.tools.TriFunction;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Function;

public class ContextSensitiveInlineEqualitiesExpressionVisitor implements Expression.Visitor<Expression> {
    private Expression parent;
    private boolean hasSkippedInlines = false;
    private final Map<Expression.FreeVarExpression, Expression> inlines;
    private final InlinePolicy inlinePolicy = ConservativeInlinePolicy.instance;

    public ContextSensitiveInlineEqualitiesExpressionVisitor(Map<Expression.FreeVarExpression, Expression> inlines) {
        this.inlines = Collections.unmodifiableMap(inlines);
    }

    @Override
    public Expression visit(Expression.IntConst expression) {
        return expression;
    }

    @Override
    public Expression visit(Expression.BoolConst expression) {
        return expression;
    }

    @Override
    public Expression visit(Expression.ArrayInitExpression expression) {
        parent = expression;
        Expression tmp = expression.initializer.accept(this);

        if (tmp == expression.initializer) {
            return expression;
        }

        return new Expression.ArrayInitExpression(tmp);
    }

    @Override
    public Expression visit(Expression.VarExpression expression) {
        return expression;
    }

    @Override
    public Expression visit(Expression.FreeVarExpression expression) {

        if (inlines.containsKey(expression)) {
            if (inlinePolicy.isInlineOkay(parent, expression, inlines.get(expression))) {
                return inlines.get(expression);
            } else {
                hasSkippedInlines = true;
            }
        }

        return expression;
    }

    @Override
    public Expression visit(Expression.ParVarExpression expression) {
        return expression;
    }

    private Expression visitBinaryExpression(Expression.BinaryExpression expression, BiFunction<Expression, Expression, Expression> constructor) {
        parent = expression;
        Expression child1 = expression.expression1.accept(this);
        parent = expression;
        Expression child2 = expression.expression2.accept(this);

        if (child1 == expression.expression1 && child2 == expression.expression2) {
            return expression;
        }

        return constructor.apply(child1, child2);
    }

    @Override
    public Expression visit(Expression.BinaryIntExpression expression) {
        return visitBinaryExpression(expression, (x, y) -> new Expression.BinaryIntExpression(x, y, expression.operation));
    }

    @Override
    public Expression visit(Expression.BinaryBoolExpression expression) {
        return visitBinaryExpression(expression, (x, y) -> new Expression.BinaryBoolExpression(x, y, expression.operation));
    }

    @Override
    public Expression visit(Expression.SelectExpression expression) {
        return visitBinaryExpression(expression, Expression.SelectExpression::new);
    }


    private Expression visitTernary(Expression.TernaryExpression expression, TriFunction<Expression, Expression, Expression, Expression> constructor) {
        parent = expression;
        Expression child1 = expression.expression1.accept(this);
        parent = expression;
        Expression child2 = expression.expression2.accept(this);
        parent = expression;
        Expression child3 = expression.expression3.accept(this);

        if (child1 == expression.expression1 && child2 == expression.expression2 && child3 == expression.expression3) {
            return expression;
        }

        return constructor.apply(child1, child2, child3);
    }

    @Override
    public Expression visit(Expression.StoreExpression expression) {
        return visitTernary(expression, Expression.StoreExpression::new);
    }

    @Override
    public Expression visit(Expression.AppExpression expression) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Expression visit(Expression.ConstructorAppExpression expression) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Expression visit(Expression.MatchExpression expression) {
        throw new UnsupportedOperationException();
    }

    private Expression visitUnaryExpression(Expression.UnaryExpression expression, Function<Expression, Expression> constructor) {
        parent = expression;
        Expression child = expression.expression.accept(this);

        if (child == expression.expression) {
            return expression;
        }

        return constructor.apply(child);
    }

    @Override
    public Expression visit(Expression.NegationExpression expression) {
        return visitUnaryExpression(expression, Expression.NegationExpression::new);
    }

    @Override
    public Expression visit(Expression.ConditionalExpression expression) {
        return visitTernary(expression, Expression.ConditionalExpression::new);
    }

    @Override
    public Expression visit(Expression.ComparisonExpression expression) {
        return visitBinaryExpression(expression, (x, y) -> new Expression.ComparisonExpression(x, y, expression.operation));
    }

    @Override
    public Expression visit(Expression.ConstExpression expression) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Expression visit(Expression.SumExpression expression) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Expression visit(Expression.BitvectorNegationExpression expression) {
        throw new UnsupportedOperationException();
    }

    public boolean hasSkippedInlines() {
        return hasSkippedInlines;
    }
}
