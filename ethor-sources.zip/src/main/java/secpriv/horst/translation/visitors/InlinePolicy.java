package secpriv.horst.translation.visitors;

import secpriv.horst.data.Expression;

public interface InlinePolicy {
    boolean isInlineOkay(Expression parent, Expression.FreeVarExpression freeVar, Expression inlinedValue);
}
