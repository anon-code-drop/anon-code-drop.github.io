package secpriv.horst.translation.visitors;

import secpriv.horst.data.*;
import secpriv.horst.tools.PropositionHelper;
import secpriv.horst.types.Type;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EqualityInliningClauseVisitor implements Clause.Visitor<Clause> {
    public static final Clause UNREACHABLE = new Clause(Collections.singletonList(new Proposition.ExpressionProposition(Expression.BoolConst.FALSE)), new Proposition.PredicateProposition(Predicate.newPredicate("unreachable___", Collections.emptyList(), Collections.emptyList()), Collections.emptyList(), Collections.emptyList()), Collections.emptyMap());

    private static Set<Expression.FreeVarExpression> getFreeVars(Expression expression) {
        GetFreeVarExpressionVisitor expressionVisitor = new GetFreeVarExpressionVisitor();
        expression.accept(expressionVisitor);
        return expressionVisitor.getFreeVars();
    }

    private Set<Expression.FreeVarExpression> getFreeVars(Proposition proposition) {
        class GetFreeVarPropositionVisitor implements Proposition.Visitor<Set<Expression.FreeVarExpression>> {
            @Override
            public Set<Expression.FreeVarExpression> visit(Proposition.PredicateProposition proposition) {
                return proposition.arguments.stream().flatMap(a -> getFreeVars(a).stream()).collect(Collectors.toSet());
            }

            @Override
            public Set<Expression.FreeVarExpression> visit(Proposition.ExpressionProposition proposition) {
                return getFreeVars(proposition.expression);
            }
        }

        return proposition.accept(new GetFreeVarPropositionVisitor());
    }

    private Set<Expression.FreeVarExpression> getFreeVars(Clause clause) {
        return Stream.concat(clause.premises.stream(), Stream.of(clause.conclusion)).flatMap(p -> this.getFreeVars(p).stream()).collect(Collectors.toSet());
    }

    @Override
    public Clause visit(Clause clause) {
        Clause mappedClause = clause.accept(new ConservativelyAllocatingConstantFoldingClauseVisitor());
        mappedClause = removeUnneededConstraints(mappedClause);

        int maxIterations = mappedClause.premises.size() * mappedClause.premises.size();

        while (true) {
            if (maxIterations-- < 0) {
                // TODO replace with something proper
                throw new RuntimeException("Maximum number of iterations exceeded, likely there are cyclic dependencies between free variables!");
            }
            mappedClause = mappedClause.accept(new UnfoldAndClauseVisitor());
            Clause finalMappedClause = mappedClause;

            List<Proposition.ExpressionProposition> potentialInlines = mappedClause.premises.stream().filter(p -> isPotentialInline(p, finalMappedClause.premises, finalMappedClause.conclusion)).map(e -> (Proposition.ExpressionProposition) e).collect(Collectors.toList());
            Optional<Proposition.ExpressionProposition> optInline = potentialInlines.stream().min(inlineComparator);

            if (optInline.isPresent()) {
                Proposition.ExpressionProposition inlinedProposition = optInline.get();

                List<Proposition> mappedPremises = mappedClause.premises;
                Proposition.PredicateProposition mappedConclusion = mappedClause.conclusion;
                Map<String, Type> mappedFreeVars = mappedClause.freeVars;

                Set<Expression.FreeVarExpression> argumentFreeVars = Stream.concat(getFreeVars(mappedClause.conclusion).stream(), mappedPremises.stream().filter(PropositionHelper::isPredicateProposition).flatMap(p -> getFreeVars(p).stream())).collect(Collectors.toSet());

                {
                    Optional<ExpressionView.FreeVarEquality> optionalFreeVarEquality = ExpressionView.viewAsFreeVarEquality(optInline.get().expression);

                    if (optionalFreeVarEquality.isPresent()) {
                        mappedPremises = mappedPremises.stream().filter(p -> p != inlinedProposition).collect(Collectors.toList());
                        Map<Expression.FreeVarExpression, Expression> inlines = Collections.singletonMap(optionalFreeVarEquality.get().getFirstFreeVar(), optionalFreeVarEquality.get().getSecondFreeVar());

                        InlineEqualitiesPropositionVisitor propositionVisitor = new InlineEqualitiesPropositionVisitor(inlines);
                        mappedPremises = mappedPremises.stream().map(e -> e.accept(propositionVisitor)).collect(Collectors.toList());
                        mappedConclusion = (Proposition.PredicateProposition) mappedConclusion.accept(propositionVisitor);
                        mappedFreeVars = mappedFreeVars.entrySet().stream().filter(e -> !e.getKey().equals(optionalFreeVarEquality.get().getFirstFreeVar().name)).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
                    } else {
                        ExpressionView.SimpleEquality simpleEquality = ExpressionView.viewAsSimpleEquality(inlinedProposition.expression).get();
                        Map<Expression.FreeVarExpression, Expression> inlines = Collections.singletonMap(simpleEquality.getFreeVar(), simpleEquality.getValue());

                        ContextSensitiveInlineEqualitiesPropositionVisitor propositionVisitor = new ContextSensitiveInlineEqualitiesPropositionVisitor(inlines);
                        mappedPremises = mappedPremises.stream().filter(p -> p != inlinedProposition).map(p -> PropositionHelper.isPredicateProposition(p) ? p : p.accept(propositionVisitor)).collect(Collectors.toList());

                        if (propositionVisitor.hasSkippedInlines() || argumentFreeVars.contains(simpleEquality.getFreeVar())) {
                            mappedPremises = Stream.concat(mappedPremises.stream(), Stream.of(inlinedProposition)).collect(Collectors.toList());
                        }
                    }

                    ConservativelyAllocatingConstantFoldingPropositionVisitor constantFoldingPropositionVisitor = new ConservativelyAllocatingConstantFoldingPropositionVisitor();
                    mappedPremises = mappedPremises.stream().map(p -> p.accept(constantFoldingPropositionVisitor)).collect(Collectors.toList());
                }

                mappedClause = new Clause(mappedPremises, mappedConclusion, mappedFreeVars);
            } else {
                break;
            }
        }

        mappedClause = new Clause(simplifyBounds(mappedClause.premises), mappedClause.conclusion, mappedClause.freeVars);
        mappedClause = new Clause(mappedClause.premises, mappedClause.conclusion, getFreeVars(mappedClause).stream().collect(Collectors.toMap(fv -> fv.name, fv -> fv.type)));

        FilterFalsePropositionVisitor filterFalsePropositionVisitor = new FilterFalsePropositionVisitor();
        if (mappedClause.premises.stream().allMatch(p -> p.accept(filterFalsePropositionVisitor))) {
            return mappedClause.accept(new RemoveTruePremiseClauseVisitor());
        }
        return UNREACHABLE;
    }

    private Clause removeUnneededConstraints(Clause clause) {
        List<Proposition> neededPremises = new ArrayList<>();
        HashMap<String, Type> neededFreeVars = new HashMap<>(clause.freeVars);

        for (Proposition premise : clause.premises) {
            Optional<ExpressionView.SimpleEquality> se = PropositionView.expressionFromProposition(premise).flatMap(ExpressionView::viewAsSimpleEquality);
            if (se.isPresent()) {
                if (clause.premises.stream().anyMatch(p -> p != premise && getFreeVars(p).contains(se.get().getFreeVar())) || getFreeVars(clause.conclusion).contains(se.get().getFreeVar())) {
                    neededPremises.add(premise);
                } else {
                    neededFreeVars.remove(se.get().getFreeVar().name);
                }
            } else {
                neededPremises.add(premise);
            }
        }

        return new Clause(neededPremises, clause.conclusion, neededFreeVars);
    }

    private static Comparator<Proposition.ExpressionProposition> inlineComparator = (o1, o2) -> {
        Optional<ExpressionView.FreeVarEquality> ofe1 = ExpressionView.viewAsFreeVarEquality(o1.expression);
        Optional<ExpressionView.FreeVarEquality> ofe2 = ExpressionView.viewAsFreeVarEquality(o2.expression);

        if (ofe1.isPresent() && ofe2.isPresent()) {
            return 0;
        }

        if (ofe1.isPresent()) {
            return -1;
        }
        if (ofe2.isPresent()) {
            return 1;
        }

        ExpressionView.SimpleEquality se1 = ExpressionView.viewAsSimpleEquality(o1.expression).get();
        ExpressionView.SimpleEquality se2 = ExpressionView.viewAsSimpleEquality(o2.expression).get();

        int i1 = getComplexity(se1.getValue());
        int i2 = getComplexity(se2.getValue());

        return i1 - i2;
    };

    private static int getComplexity(Expression value) {
        class ExpressionComplexityVisitor implements Expression.Visitor<Integer> {

            @Override
            public Integer visit(Expression.IntConst expression) {
                return 1;
            }

            @Override
            public Integer visit(Expression.BoolConst expression) {
                return 1;
            }

            @Override
            public Integer visit(Expression.ArrayInitExpression expression) {
                return 2;
            }

            @Override
            public Integer visit(Expression.VarExpression expression) {
                throw new UnsupportedOperationException();
            }

            @Override
            public Integer visit(Expression.FreeVarExpression expression) {
                return 0;
            }

            @Override
            public Integer visit(Expression.ParVarExpression expression) {
                throw new UnsupportedOperationException();
            }

            @Override
            public Integer visit(Expression.BinaryIntExpression expression) {
                return 10;
            }

            @Override
            public Integer visit(Expression.BinaryBoolExpression expression) {
                return 10;
            }

            @Override
            public Integer visit(Expression.SelectExpression expression) {
                return 15;
            }

            @Override
            public Integer visit(Expression.StoreExpression expression) {
                return 7;
            }

            @Override
            public Integer visit(Expression.AppExpression expression) {
                throw new UnsupportedOperationException();
            }

            @Override
            public Integer visit(Expression.ConstructorAppExpression expression) {
                throw new UnsupportedOperationException();
            }

            @Override
            public Integer visit(Expression.MatchExpression expression) {
                throw new UnsupportedOperationException();
            }

            @Override
            public Integer visit(Expression.NegationExpression expression) {
                return 10;
            }

            @Override
            public Integer visit(Expression.ConditionalExpression expression) {
                return 10;
            }

            @Override
            public Integer visit(Expression.ComparisonExpression expression) {
                return 10;
            }

            @Override
            public Integer visit(Expression.ConstExpression expression) {
                throw new UnsupportedOperationException();
            }

            @Override
            public Integer visit(Expression.SumExpression expression) {
                throw new UnsupportedOperationException();
            }

            @Override
            public Integer visit(Expression.BitvectorNegationExpression expression) {
                throw new UnsupportedOperationException();
            }
        }

        return value.accept(new ExpressionComplexityVisitor());
    }

    private boolean isPotentialInline(Proposition proposition, List<Proposition> premises, Proposition.PredicateProposition conclusion) {
        class IsPotentialInlinePropositionVisitor implements Proposition.Visitor<Boolean> {

            @Override
            public Boolean visit(Proposition.PredicateProposition proposition) {
                return false;
            }

            @Override
            public Boolean visit(Proposition.ExpressionProposition proposition) {
                if (ExpressionView.viewAsFreeVarEquality(proposition.expression).isPresent()) {
                    return true;
                }
                if (ExpressionView.viewAsSimpleEquality(proposition.expression).isPresent()) {
                    ExpressionView.SimpleEquality equality = ExpressionView.viewAsSimpleEquality(proposition.expression).get();
                    Map<Expression.FreeVarExpression, Expression> inlines = Collections.singletonMap(equality.getFreeVar(), equality.getValue());

                    HasPotentialInlinesPropositionVisitor propositionVisitor = new HasPotentialInlinesPropositionVisitor(inlines);
                    boolean hasPotentialInlines = premises.stream().filter(p -> p != proposition).anyMatch(p -> p.accept(propositionVisitor));
                    hasPotentialInlines |= conclusion.accept(propositionVisitor);

                    if (!propositionVisitor.haveInlinesBeenEncountered()) {
                        // nothing will be modified, because there is nothing to modify, but the constraint will be deleted
                        // TODO make more efficient
                        return true;
                    }

                    return hasPotentialInlines;
                }
                return false;
            }
        }
        return proposition.accept(new IsPotentialInlinePropositionVisitor());
    }

    private List<Proposition> simplifyBounds(List<Proposition> premises) {
        final Map<Boolean, List<Proposition>> premisesGroupedByBound = premises.stream().collect(Collectors.groupingBy(p -> PropositionView.expressionFromProposition(p).map(ExpressionView::isSimpleBound).orElse(false)));

        final List<Proposition> bounds = premisesGroupedByBound.getOrDefault(true, Collections.emptyList());
        final List<Proposition> nonBounds = premisesGroupedByBound.getOrDefault(false, Collections.emptyList());

        final List<Proposition> filteredBounds = new ArrayList<>();

        Collection<List<PropositionView<ExpressionView.SimpleLowerBound>>> lowerBoundsGroupedByFreeVar = bounds.stream()
                .map(p -> PropositionView.viewAs(p, ExpressionView::viewAsSimpleLowerBound))
                .filter(Optional::isPresent).map(Optional::get).collect(Collectors.groupingBy(p -> p.getExpressionView().getFreeVar())).values();

        for (List<PropositionView<ExpressionView.SimpleLowerBound>> list : lowerBoundsGroupedByFreeVar) {
            list.stream().max(Comparator.comparing(PropositionView::getExpressionView)).ifPresent(v -> filteredBounds.add(v.proposition));
        }

        Collection<List<PropositionView<ExpressionView.SimpleUpperBound>>> upperBoundsGroupedByFreeVar = bounds.stream()
                .map(p -> PropositionView.viewAs(p, ExpressionView::viewAsSimpleUpperBound))
                .filter(Optional::isPresent).map(Optional::get).collect(Collectors.groupingBy(p -> p.getExpressionView().getFreeVar())).values();

        for (List<PropositionView<ExpressionView.SimpleUpperBound>> list : upperBoundsGroupedByFreeVar) {
            list.stream().max(Comparator.comparing(PropositionView::getExpressionView)).ifPresent(v -> filteredBounds.add(v.proposition));
        }

        return Stream.of(nonBounds, filteredBounds).flatMap(Collection::stream).collect(Collectors.toList());
    }
}
