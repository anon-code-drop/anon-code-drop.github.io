package secpriv.horst.translation;

import java.util.HashMap;
import java.util.Map;

public class FreeVariableScope {
    private static long scopeCounter = 0;
    private final long scopeId = scopeCounter++;
    private Map<String, Map<String, Integer>> prefixToNewScopeMap = new HashMap<>();

    public String addOrReplaceScope(String name) {
        int leftBracketIndex = name.lastIndexOf('[');
        int rightBracketIndex = name.lastIndexOf(']');
        String prefix;
        String oldScope;

        if ((leftBracketIndex == rightBracketIndex && leftBracketIndex == -1) || rightBracketIndex != name.length() - 1) {
            prefix = name;
            oldScope = "";
        } else {
            prefix = name.substring(0, leftBracketIndex);
            oldScope = name.substring(leftBracketIndex+1, rightBracketIndex);
        }
        int prefixOccurrence = prefixAndScopeToInt(prefix, oldScope);
        return prefix + '[' + scopeId + ";" + prefixOccurrence + ']';
    }

    private int prefixAndScopeToInt(String prefix, String scope) {
        if (!prefixToNewScopeMap.containsKey(prefix)) {
            prefixToNewScopeMap.put(prefix, new HashMap<>());
        }

        if (prefixToNewScopeMap.get(prefix).containsKey(scope)) {
            return prefixToNewScopeMap.get(prefix).get(scope);
        }

        int newScopeIndex = prefixToNewScopeMap.get(prefix).size();
        prefixToNewScopeMap.get(prefix).put(scope, newScopeIndex);
        return newScopeIndex;
    }
}
