package secpriv.horst.translation;

import secpriv.horst.data.Rule;
import secpriv.horst.visitors.SExpressionRuleVisitor;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class InstrumentedTranslationPipeline implements Function<List<Rule>, List<Rule>> {
    private interface InstrumentedStep {
        List<Rule> apply(List<Rule> workingRules);
        long getAccumulatedSpentTimeMillis();
    }

    private static class MapInstrumentedStep implements InstrumentedStep {
        final Function<Rule, Rule> translation;
        private long accumulatedSpentTimeMillis = 0;

        private MapInstrumentedStep(Function<Rule, Rule> translation) {
            this.translation = translation;
        }

        @Override
        public List<Rule> apply(List<Rule> workingRules) {
            long start = System.currentTimeMillis();
            List<Rule> ret= workingRules.stream().map(translation).collect(Collectors.toList());
            accumulatedSpentTimeMillis += System.currentTimeMillis() - start;
            return ret;
        }

        @Override
        public long getAccumulatedSpentTimeMillis() {
            return accumulatedSpentTimeMillis;
        }
    }

    private static class FlatMapInstrumentedStep implements InstrumentedStep {
        final Function<Rule, List<Rule>> translation;
        private long accumulatedSpentTimeMillis = 0;

        private FlatMapInstrumentedStep(Function<Rule, List<Rule>> translation) {
            this.translation = translation;
        }


        @Override
        public List<Rule> apply(List<Rule> workingRules) {
            long start = System.currentTimeMillis();
            List<Rule> ret = workingRules.stream().flatMap(r -> translation.apply(r).stream()).collect(Collectors.toList());
            accumulatedSpentTimeMillis += System.currentTimeMillis() - start;
            return ret;
        }

        @Override
        public long getAccumulatedSpentTimeMillis() {
            return accumulatedSpentTimeMillis;
        }
    }

    public static class TranslationPipelineBuilder {
        private final List<InstrumentedStep> steps = new ArrayList<>();
        private final Map<InstrumentedStep, String> stepNames = new HashMap<>();

        private TranslationPipelineBuilder() {
        }

        public TranslationPipelineBuilder nameStep(String stepName) {
            InstrumentedStep lastStep = steps.get(steps.size() - 1);
            stepNames.put(lastStep, stepName);

            return this;
        }

        public TranslationPipelineBuilder addStep(Function<Rule, Rule> translation) {
            steps.add(new MapInstrumentedStep(translation));
            return this;
        }

        public TranslationPipelineBuilder addStep(Rule.Visitor<Rule> visitor) {
            return addStep((Function<Rule, Rule>) visitor::visit);
        }

        public TranslationPipelineBuilder addFlatMappingStep(Function<Rule, List<Rule>> translation) {
            steps.add(new FlatMapInstrumentedStep(translation));
            return this;
        }

        public TranslationPipelineBuilder addFlatMappingStep(Rule.Visitor<List<Rule>> visitor) {
            return addFlatMappingStep((Function<Rule, List<Rule>>) visitor::visit);
        }

        public InstrumentedTranslationPipeline build() {
            return new InstrumentedTranslationPipeline(steps, stepNames);
        }
    }

    private final List<InstrumentedStep> steps;
    private final Map<InstrumentedStep, String> stepNames;

    private InstrumentedTranslationPipeline(List<InstrumentedStep> steps, Map<InstrumentedStep, String> stepNames) {
        this.steps = Collections.unmodifiableList(steps);
        this.stepNames = stepNames;
    }

    public static TranslationPipelineBuilder builder() {
        return new TranslationPipelineBuilder();
    }

    public List<Rule> apply(List<Rule> initialRules) {
        ArrayList<Rule> ret = new ArrayList<>();

        for (Rule rule : initialRules) {
            List<Rule> workingRules = Collections.singletonList(rule);
            for (InstrumentedStep step : steps) {
                workingRules = step.apply(workingRules);
            }
            ret.addAll(workingRules);
        }

        return ret;
    }

    public String getInstrumentationOutput() {
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (InstrumentedStep step : steps) {
            sb.append(stepNames.getOrDefault(step, "Step " + i));
            sb.append(": ");
            sb.append(step.getAccumulatedSpentTimeMillis());
            sb.append(" ms");
            sb.append("\n");

            ++i;
        }

        return sb.toString();
    }
}

