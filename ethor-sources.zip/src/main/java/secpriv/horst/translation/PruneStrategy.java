package secpriv.horst.translation;

import org.jgrapht.Graph;
import org.jgrapht.GraphPath;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.graph.DefaultEdge;
import secpriv.horst.data.Clause;
import secpriv.horst.data.Predicate;
import secpriv.horst.data.Proposition;
import secpriv.horst.data.Rule;
import secpriv.horst.translation.visitors.FilterClauseRuleVisitor;
import secpriv.horst.visitors.RuleTypeOracle;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public abstract class PruneStrategy {
    public abstract List<Rule> pruneRules(List<Rule> rules, RuleTypeOracle oracle);

    private static Set<Predicate> getQueryPredicates(List<Rule> rules, RuleTypeOracle oracle) {
        return rules.stream().filter(oracle::isQueryOrTest).flatMap(r -> r.clauses.stream()).map(c -> c.conclusion.predicate).collect(Collectors.toSet());
    }

    public enum Enum {
        none(new NonePruneStrategy()),
        aggressive(new AggressivePruneStrategy()),
        deleteLeaves(new DeleteLeavesPruneStrategy());

        public final PruneStrategy strategy;

        Enum(PruneStrategy strategy) {
            this.strategy = strategy;
        }
    }

    public static class NonePruneStrategy extends PruneStrategy {
        @Override
        public List<Rule> pruneRules(List<Rule> rules, RuleTypeOracle oracle) {
            return rules;
        }
    }

    public static class AggressivePruneStrategy extends PruneStrategy {
        @Override
        public List<Rule> pruneRules(List<Rule> rules, RuleTypeOracle oracle) {
            Set<Predicate> queryPredicates = getQueryPredicates(rules, oracle);
            Predicate startPredicate = PredicateGraphHelper.getStartPredicate(rules);
            Graph<Predicate, DefaultEdge> graph = PredicateGraphHelper.calculatePredicateGraph(rules);
            DijkstraShortestPath<Predicate, DefaultEdge> dijkstraAlg = new DijkstraShortestPath<>(graph);

            class IstReachableFromStartPredicatePropositionVisitor implements Proposition.Visitor<Boolean> {
                private final Set<Predicate> reachableFromStart;

                IstReachableFromStartPredicatePropositionVisitor(Set<Predicate> reachableFromStart) {
                    this.reachableFromStart = reachableFromStart;
                }

                @Override
                public Boolean visit(Proposition.PredicateProposition proposition) {
                    if (reachableFromStart.contains(proposition.predicate)) {
                        return true;
                    }
                    Optional<GraphPath<Predicate, DefaultEdge>> optPath = Optional.ofNullable(dijkstraAlg.getPath(startPredicate, proposition.predicate));
                    optPath.ifPresent(p -> reachableFromStart.addAll(p.getVertexList()));
                    return optPath.isPresent();
                }

                @Override
                public Boolean visit(Proposition.ExpressionProposition proposition) {
                    return true;
                }
            }

            class PruneUnreachableOrUnqueriedPropositionsClauseVisitor implements Clause.Visitor<Optional<Clause>> {
                private final Set<Predicate> reachableFromStart = new HashSet<>();
                private final Set<Predicate> reachesAnyQuery = new HashSet<>();

                @Override
                public Optional<Clause> visit(Clause clause) {
                    IstReachableFromStartPredicatePropositionVisitor propositionVisitor = new IstReachableFromStartPredicatePropositionVisitor(reachableFromStart);

                    if (clause.premises.stream().allMatch(p -> p.accept(propositionVisitor))) {
                        if (queryPredicates.stream().anyMatch(q -> this.reachesThisOrAnyQuery(clause.conclusion.predicate, q))) {
                            return Optional.of(clause);
                        }
                    }

                    return Optional.empty();
                }

                private boolean reachesThisOrAnyQuery(Predicate predicate, Predicate query) {
                    if (reachesAnyQuery.contains(predicate)) {
                        return true;
                    }
                    Optional<GraphPath<Predicate, DefaultEdge>> optPath = Optional.ofNullable(dijkstraAlg.getPath(predicate, query));
                    optPath.ifPresent(p -> reachesAnyQuery.addAll(p.getVertexList()));
                    return optPath.isPresent();
                }
            }

            ClauseFilteringRuleVisitor ruleVisitor = new ClauseFilteringRuleVisitor(new PruneUnreachableOrUnqueriedPropositionsClauseVisitor());

            return rules.stream().map(r -> r.accept(ruleVisitor)).filter(Optional::isPresent).map(Optional::get).collect(Collectors.toList());
        }
    }

    public static class DeleteLeavesPruneStrategy extends PruneStrategy {
        @Override
        public List<Rule> pruneRules(List<Rule> rules, RuleTypeOracle oracle) {
            Set<Predicate> queryPredicates = getQueryPredicates(rules, oracle);

            while (true) {
                List<Rule> resultRules = deleteLeaveRules(rules, queryPredicates);
                if (rules == resultRules) {
                    break;
                }
                rules = resultRules;
            }
            return rules;
        }

        private static List<Rule> deleteLeaveRules(List<Rule> rules, Set<Predicate> queryPredicates) {
            PredicateOccurrenceMap predicateOccurrenceMap = new PredicateOccurrenceMap(rules);
            Set<Predicate> allPredicates = predicateOccurrenceMap.getAllPredicates();

            Set<Clause> deletionCandidates = new HashSet<>();

            for (Predicate p : allPredicates) {
                List<Clause> occurrenceInConclusion = predicateOccurrenceMap.getOccurrencesAsConclusion(p);
                List<Clause> occurrenceInPremise = predicateOccurrenceMap.getOccurrencesAsPremise(p);

                if (occurrenceInPremise.isEmpty() && !queryPredicates.contains(p)) {
                    deletionCandidates.addAll(occurrenceInConclusion);
                }
            }

            if (deletionCandidates.isEmpty()) {
                return rules;
            }

            FilterClauseRuleVisitor filterClauseRuleVisitor = new FilterClauseRuleVisitor(deletionCandidates);
            return rules.stream().map(r -> r.accept(filterClauseRuleVisitor)).filter(Optional::isPresent).map(Optional::get).collect(Collectors.toList());
        }
    }
}
