package secpriv.horst.translation;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jgrapht.Graph;
import org.jgrapht.GraphPath;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.graph.DefaultEdge;
import secpriv.horst.data.Clause;
import secpriv.horst.data.Predicate;
import secpriv.horst.data.Proposition;
import secpriv.horst.data.Rule;
import secpriv.horst.tools.PredicateHelper;
import secpriv.horst.translation.visitors.FilterClauseRuleVisitor;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public abstract class PruneStrategy {
    public abstract List<Rule> pruneRules(List<Rule> rules);

    private static Set<Predicate> getQueryPredicates(List<Rule> rules) {
        return rules.stream().flatMap(PredicateHelper::queryOrTestStream).collect(Collectors.toSet());
    }

    public enum Enum {
        none(new NonePruneStrategy()),
        aggressive(new AggressivePruneStrategy()),
        deleteLeaves(new DeleteLeavesPruneStrategy());

        public final PruneStrategy strategy;

        Enum(PruneStrategy strategy) {
            this.strategy = strategy;
        }
    }

    public static class NonePruneStrategy extends PruneStrategy {
        @Override
        public List<Rule> pruneRules(List<Rule> rules) {
            return rules;
        }
    }

    public static class AggressivePruneStrategy extends PruneStrategy {
        private static final Logger logger = LogManager.getLogger(AggressivePruneStrategy.class);

        @Override
        public List<Rule> pruneRules(List<Rule> rules) {
            Set<Predicate> queryPredicates = getQueryPredicates(rules);
            Set<Predicate> startPredicate = PredicateGraphHelper.getStartPredicates(rules);
            Graph<Predicate, DefaultEdge> graph = PredicateGraphHelper.calculatePredicateGraph(rules);
            DijkstraShortestPath<Predicate, DefaultEdge> dijkstraAlg = new DijkstraShortestPath<>(graph);

            class IstReachableFromStartPredicatePropositionVisitor implements Proposition.Visitor<Boolean> {
                private final Set<Predicate> reachableFromStart;

                IstReachableFromStartPredicatePropositionVisitor(Set<Predicate> reachableFromStart) {
                    this.reachableFromStart = reachableFromStart;
                }

                @Override
                public Boolean visit(Proposition.PredicateProposition proposition) {
                    if (reachableFromStart.contains(proposition.predicate)) {
                        return true;
                    }
                    for(Predicate startPredicate : startPredicate) {
                        Optional<GraphPath<Predicate, DefaultEdge>> optPath = Optional.ofNullable(dijkstraAlg.getPath(startPredicate, proposition.predicate));
                        optPath.ifPresent(p -> reachableFromStart.addAll(p.getVertexList()));
                        if(optPath.isPresent()) {
                            return true;
                        }
                    }
                    return false;
                }

                @Override
                public Boolean visit(Proposition.ExpressionProposition proposition) {
                    return true;
                }
            }

            class PruneUnreachableOrUnqueriedPropositionsClauseVisitor implements Clause.Visitor<Optional<Clause>> {
                private final Set<Predicate> reachableFromStart = new HashSet<>();
                private final Set<Predicate> reachesAnyQuery = new HashSet<>();

                @Override
                public Optional<Clause> visit(Clause clause) {
                    IstReachableFromStartPredicatePropositionVisitor propositionVisitor = new IstReachableFromStartPredicatePropositionVisitor(reachableFromStart);

                    if (clause.premises.stream().allMatch(p -> p.accept(propositionVisitor))) {
                        if (queryPredicates.stream().anyMatch(q -> this.reachesThisOrAnyQuery(clause.conclusion.predicate, q))) {
                            return Optional.of(clause);
                        }
                    }

                    return Optional.empty();
                }

                private boolean reachesThisOrAnyQuery(Predicate predicate, Predicate query) {
                    if (reachesAnyQuery.contains(predicate)) {
                        return true;
                    }
                    Optional<GraphPath<Predicate, DefaultEdge>> optPath = Optional.ofNullable(dijkstraAlg.getPath(predicate, query));
                    optPath.ifPresent(p -> reachesAnyQuery.addAll(p.getVertexList()));
                    return optPath.isPresent();
                }
            }

            ClauseFilteringRuleVisitor ruleVisitor = new ClauseFilteringRuleVisitor(new PruneUnreachableOrUnqueriedPropositionsClauseVisitor());

            logger.debug("Pruned rules: {}.", () -> rules.stream().map(r -> r.accept(ruleVisitor).isPresent() ? Optional.empty() : Optional.of(r.name)).filter(Optional::isPresent).map(Optional::get).collect(Collectors.toList()));

            return rules.stream().map(r -> r.accept(ruleVisitor)).filter(Optional::isPresent).map(Optional::get).collect(Collectors.toList());
        }
    }

    public static class DeleteLeavesPruneStrategy extends PruneStrategy {
        @Override
        public List<Rule> pruneRules(List<Rule> rules) {
            Set<Predicate> queryPredicates = getQueryPredicates(rules);

            while (true) {
                List<Rule> resultRules = deleteLeaveRules(rules, queryPredicates);
                if (rules == resultRules) {
                    break;
                }
                rules = resultRules;
            }
            return rules;
        }

        private static List<Rule> deleteLeaveRules(List<Rule> rules, Set<Predicate> queryPredicates) {
            PredicateOccurrenceMap predicateOccurrenceMap = new PredicateOccurrenceMap(rules);
            Set<Predicate> allPredicates = predicateOccurrenceMap.getAllPredicates();

            Set<Clause> deletionCandidates = new HashSet<>();

            for (Predicate p : allPredicates) {
                List<Clause> occurrenceInConclusion = predicateOccurrenceMap.getOccurrencesAsConclusion(p);
                List<Clause> occurrenceInPremise = predicateOccurrenceMap.getOccurrencesAsPremise(p);

                if (occurrenceInPremise.isEmpty() && !queryPredicates.contains(p)) {
                    deletionCandidates.addAll(occurrenceInConclusion);
                }
            }

            if (deletionCandidates.isEmpty()) {
                return rules;
            }

            FilterClauseRuleVisitor filterClauseRuleVisitor = new FilterClauseRuleVisitor(deletionCandidates);
            return rules.stream().map(r -> r.accept(filterClauseRuleVisitor)).filter(Optional::isPresent).map(Optional::get).collect(Collectors.toList());
        }
    }
}
