package secpriv.horst.translation;

import secpriv.horst.data.Clause;
import secpriv.horst.data.Rule;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class ClauseFilteringRuleVisitor implements Rule.Visitor<Optional<Rule>> {
    private final Function<Clause, Optional<Clause>> function;

    public ClauseFilteringRuleVisitor(Function<Clause, Optional<Clause>> function) {
        this.function = function;
    }

    public ClauseFilteringRuleVisitor(Clause.Visitor<Optional<Clause>> clauseVisitor) {
        function = c -> c.accept(clauseVisitor);
    }

    @Override
    public Optional<Rule> visit(Rule rule) {
        List<Clause> mappedClauses = rule.clauses.stream().map(function).filter(Optional::isPresent).map(Optional::get).collect(Collectors.toList());

        if (mappedClauses.size() == rule.clauses.size()) {
            if (IntStream.range(0, mappedClauses.size()).allMatch(i -> mappedClauses.get(i) == rule.clauses.get(i))) {
                return Optional.of(rule);
            }
        } else if (mappedClauses.isEmpty()) {
            return Optional.empty();
        }

        return Optional.of(new Rule(rule.name, rule.selectorFunctionInvocation, mappedClauses));
    }
}
