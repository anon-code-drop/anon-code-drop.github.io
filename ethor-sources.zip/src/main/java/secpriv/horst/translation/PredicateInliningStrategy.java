package secpriv.horst.translation;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jgrapht.Graph;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.traverse.DepthFirstIterator;
import secpriv.horst.data.Predicate;
import secpriv.horst.data.Rule;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public abstract class PredicateInliningStrategy {
    public abstract List<Predicate> getInlineCandidates(List<Rule> rules);

    public enum Enum {
        none(new NoneInliningStrategy()),
        linear(new LinearInliningStrategy()),
        exhaustive(new ExhaustiveInliningStrategy()),
        linearExhaustive(new CombiningInliningStrategy(new LinearInliningStrategy(), new ExhaustiveInliningStrategy()));

        public final PredicateInliningStrategy strategy;

        Enum(PredicateInliningStrategy strategy) {
            this.strategy = strategy;
        }
    }

    public static class NoneInliningStrategy extends PredicateInliningStrategy {

        @Override
        public List<Predicate> getInlineCandidates(List<Rule> rules) {
            return Collections.emptyList();
        }
    }

    public static class LinearInliningStrategy extends PredicateInliningStrategy {
        private static final Logger logger = LogManager.getLogger(LinearInliningStrategy.class);

        @Override
        public List<Predicate> getInlineCandidates(List<Rule> rules) {
            Graph<Predicate, DefaultEdge> predicateGraph = PredicateGraphHelper.calculatePredicateGraph(rules);
            List<Predicate> inlineCandidates = new ArrayList<>();

            DepthFirstIterator<Predicate, DefaultEdge> iter = new DepthFirstIterator<>(predicateGraph, PredicateGraphHelper.getStartPredicates(rules));

            while (iter.hasNext()) {
                Predicate predicate = iter.next();
                if (predicateGraph.inDegreeOf(predicate) == 1 && predicateGraph.outDegreeOf(predicate) == 1) {
                    inlineCandidates.add(predicate);
                }
            }

            logger.trace("Found {} candidate predicates to inline.", inlineCandidates::size);
            return inlineCandidates;
        }
    }

    public static class ExhaustiveInliningStrategy extends PredicateInliningStrategy {
        private static final Logger logger = LogManager.getLogger(ExhaustiveInliningStrategy.class);

        @Override
        public List<Predicate> getInlineCandidates(List<Rule> rules) {
            Graph<Predicate, DefaultEdge> predicateGraph = PredicateGraphHelper.calculatePredicateGraph(rules);
            List<Predicate> inlineCandidates = new ArrayList<>();

            OptimalInlineOrderGraphIterator<Predicate, DefaultEdge> iterator = new OptimalInlineOrderGraphIterator<>(predicateGraph, PredicateGraphHelper.getStartPredicates(rules), Comparator.comparing(p -> p.name));
            iterator.forEachRemaining(inlineCandidates::add);

            logger.trace("Found {} candidate predicates to inline.", inlineCandidates::size);
            return inlineCandidates;
        }
    }

    public static class ExplicitEnumerationInliningStrategy extends PredicateInliningStrategy {
        private final List<Predicate> enumeration;

        public ExplicitEnumerationInliningStrategy(List<Predicate> enumeration) {
            this.enumeration = Collections.unmodifiableList(Objects.requireNonNull(enumeration));
        }

        @Override
        public List<Predicate> getInlineCandidates(List<Rule> rules) {
            return enumeration;
        }
    }

    public static class CombiningInliningStrategy extends PredicateInliningStrategy {
        private final PredicateInliningStrategy firstStrategy;
        private final PredicateInliningStrategy secondStrategy;

        public CombiningInliningStrategy(PredicateInliningStrategy firstStrategy, PredicateInliningStrategy secondStrategy) {
            this.firstStrategy = Objects.requireNonNull(firstStrategy);
            this.secondStrategy = Objects.requireNonNull(secondStrategy);
        }

        @Override
        public List<Predicate> getInlineCandidates(List<Rule> rules) {
            List<Predicate> firstList = firstStrategy.getInlineCandidates(rules);
            Set<Predicate> firstPredicates = new HashSet<>(firstList);

            return Stream.concat(firstList.stream(), secondStrategy.getInlineCandidates(rules).stream().filter(c -> !firstPredicates.contains(c))).collect(Collectors.toList());
        }
    }
}
