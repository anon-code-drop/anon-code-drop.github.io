package secpriv.horst.translation;

import org.jgrapht.Graph;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.DirectedPseudograph;
import secpriv.horst.data.Clause;
import secpriv.horst.data.Predicate;
import secpriv.horst.data.Rule;
import secpriv.horst.translation.visitors.RetrievePredicatesPropositionVisitor;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class PredicateGraphHelper {

    private PredicateGraphHelper() {
    }

    public static Graph<Predicate, DefaultEdge> calculatePredicateGraph(List<Rule> rules) {
        DirectedPseudograph<Predicate, DefaultEdge> graph = new DirectedPseudograph<>(DefaultEdge.class);

        class PredicateGraphPopulationClauseVisitor implements Clause.Visitor<Void> {
            @Override
            public Void visit(Clause clause) {
                RetrievePredicatesPropositionVisitor propositionVisitor = new RetrievePredicatesPropositionVisitor();

                List<Predicate> premisePredicates = clause.premises.stream().map(p -> p.accept(propositionVisitor)).filter(Optional::isPresent).map(Optional::get).collect(Collectors.toList());

                for (Predicate premisePredicate : premisePredicates) {
                    Predicate conclusionPredicate = clause.conclusion.predicate;

                    graph.addVertex(premisePredicate);
                    graph.addVertex(conclusionPredicate);

                    graph.addEdge(premisePredicate, conclusionPredicate);
                }

                return null;
            }
        }

        PredicateGraphPopulationClauseVisitor clauseVisitor = new PredicateGraphPopulationClauseVisitor();

        rules.stream().flatMap(r -> r.clauses.stream()).forEach(c -> c.accept(clauseVisitor));

        return graph;
    }


    public static Predicate getStartPredicate(List<Rule> rules) {
        RetrievePredicatesPropositionVisitor propositionVisitor = new RetrievePredicatesPropositionVisitor();

        //TODO This is a bad heuristic, replace by something using the init key word
        Optional<Predicate> optPredicate = rules.stream().flatMap(r -> r.clauses.stream()).flatMap(c -> c.premises.stream()).map(p -> p.accept(propositionVisitor)).filter(Optional::isPresent).map(Optional::get).filter(p -> p.name.endsWith("_0") && p.name.startsWith("MState_")).findFirst();

        return optPredicate.orElseGet(() -> rules.stream().flatMap(r -> r.clauses.stream()).flatMap(c -> c.premises.stream()).map(p -> p.accept(propositionVisitor)).filter(Optional::isPresent).map(Optional::get).findFirst().get());
//        return optPredicate.orElseGet(() -> rules.get(0).clauses.get(0).conclusion.predicate);
    }

}
