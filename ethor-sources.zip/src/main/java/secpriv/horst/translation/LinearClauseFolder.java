package secpriv.horst.translation;

import secpriv.horst.data.*;
import secpriv.horst.translation.visitors.ClauseMerger;
import secpriv.horst.translation.visitors.FilterClauseRuleVisitor;

import java.util.*;
import java.util.stream.Collectors;

public class LinearClauseFolder {

    public static List<Rule> foldLinearClausesRules(List<Rule> allRules) {
        PredicateOccurrenceMap predicateOccurrenceMap = new PredicateOccurrenceMap(allRules);
        Set<Predicate> allPredicates = predicateOccurrenceMap.getAllPredicates();

        Set<Clause> foldedClauses = new HashSet<>();
        Set<Predicate> deletedPredicates = new HashSet<>();

        for (Predicate p : allPredicates.stream().sorted(Comparator.comparing(p -> ((Predicate) p).name.length()).thenComparing(o -> ((Predicate) o).name)).collect(Collectors.toList())) {
            List<Clause> occurrenceInConclusion = predicateOccurrenceMap.getOccurrencesAsConclusion(p);
            List<Clause> occurrenceInPremise = predicateOccurrenceMap.getOccurrencesAsPremise(p);

            if (occurrenceInPremise.size() == 1 && occurrenceInConclusion.size() == 1) {
                foldedClauses.addAll(occurrenceInConclusion);
                foldedClauses.addAll(occurrenceInPremise);
                deletedPredicates.add(p);
            }
        }

        List<Set<Predicate>> groupedDeletedPredicates = groupDeletedPredicates(deletedPredicates, predicateOccurrenceMap);

        FilterClauseRuleVisitor deleteFoldedClausesVisitor = new FilterClauseRuleVisitor(foldedClauses);
        List<Rule> foldedRules = allRules.stream().map(r -> r.accept(deleteFoldedClausesVisitor)).filter(Optional::isPresent).map(Optional::get).collect(Collectors.toList());

        int i = 0;
        for (Set<Predicate> deletionGroup : groupedDeletedPredicates) {
            Clause mergedClause = mergeDeletionGroup(predicateOccurrenceMap, deletionGroup);
            String ruleName = "merge" + (++i);
            foldedRules.add(new Rule(ruleName, CompoundSelectorFunctionInvocation.UnitInvocation, Collections.singletonList(mergedClause)));
        }

        return foldedRules;
    }


    private static Clause mergeDeletionGroup(PredicateOccurrenceMap predicateOccurrenceMap, Set<Predicate> deletionGroup) {
        Set<Clause> unsortedImplicationChain = new HashSet<>();

        for (Predicate p : deletionGroup) {
            unsortedImplicationChain.addAll(predicateOccurrenceMap.getOccurrencesAsConclusion(p));
            unsortedImplicationChain.addAll(predicateOccurrenceMap.getOccurrencesAsPremise(p));
        }

        Clause start = getStartOfImplicationChain(unsortedImplicationChain, deletionGroup);
        Clause end = getEndOfImplicationChain(unsortedImplicationChain, deletionGroup);

        List<Clause> sortedImplicationChain = new ArrayList<>();

        while (start != end) {
            sortedImplicationChain.add(start);
            start = predicateOccurrenceMap.getOccurrencesAsPremise(start.conclusion.predicate).get(0);
        }
        sortedImplicationChain.add(end);

        ClauseMerger clauseMerger = new ClauseMerger();
        return clauseMerger.merge(sortedImplicationChain);
    }


    private static Clause getStartOfImplicationChain(Set<Clause> implicationChain, Set<Predicate> internalPredicates) {
        for (Clause c : implicationChain) {
            if (internalPredicates.stream().noneMatch(p -> implies(p, c))) {
                return c;
            }
        }
        throw new IllegalArgumentException("There must be one clause in whose premises do not contain any of internalPredicates!");
    }

    private static boolean implies(Predicate premise, Clause clause) {
        class ImplicationCheckPropositionVisitor implements Proposition.Visitor<Boolean> {
            @Override
            public Boolean visit(Proposition.PredicateProposition proposition) {
                return proposition.predicate.equals(premise);
            }

            @Override
            public Boolean visit(Proposition.ExpressionProposition proposition) {
                return false;
            }
        }

        ImplicationCheckPropositionVisitor propositionVisitor = new ImplicationCheckPropositionVisitor();
        return clause.premises.stream().anyMatch(p -> p.accept(propositionVisitor));
    }

    private static Clause getEndOfImplicationChain(Set<Clause> implicationChain, Set<Predicate> internalPredicates) {
        for (Clause c : implicationChain) {
            if (!internalPredicates.contains(c.conclusion.predicate)) {
                return c;
            }
        }
        throw new IllegalArgumentException("There must be one clause in whose conclusion is not in internalPredicates!");
    }

    private static List<Set<Predicate>> groupDeletedPredicates(Set<Predicate> deletedPredicates, PredicateOccurrenceMap predicateOccurrenceMap) {
        Map<Predicate, Integer> representatives = new HashMap<>();

        int i = 0;
        for (Predicate p : deletedPredicates) {
            representatives.put(p, i++);
        }

        // The representative r of a predicate p is r in deletedPredicates, such that r is transitively implied by
        // p and r does not imply any other p' in deletedPredicates. This is basically union-find.
        for (Predicate premise : deletedPredicates) {
            Predicate conclusion = predicateOccurrenceMap.getOccurrencesAsPremise(premise).get(0).conclusion.predicate;

            while (deletedPredicates.contains(conclusion)) {
                Predicate newConclusion = predicateOccurrenceMap.getOccurrencesAsPremise(conclusion).get(0).conclusion.predicate;

                if (deletedPredicates.contains(newConclusion)) {
                    conclusion = newConclusion;
                } else {
                    representatives.put(premise, representatives.get(conclusion));
                    break;
                }
            }
        }

        return deletedPredicates.stream().collect(Collectors.groupingBy(representatives::get)).values().stream().map(HashSet::new).collect(Collectors.toList());
    }
}
