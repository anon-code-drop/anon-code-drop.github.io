package secpriv.horst.translation;

import secpriv.horst.data.Clause;
import secpriv.horst.data.Predicate;
import secpriv.horst.data.Rule;
import secpriv.horst.translation.visitors.RetrievePredicatesPropositionVisitor;

import java.util.*;
import java.util.stream.Collectors;

class PredicateOccurrenceMap {
    private final Map<Predicate, List<Clause>> occurrencesAsPremise;
    private final Map<Predicate, List<Clause>> occurrencesAsConclusion;
    private Set<Predicate> allPredicates;

    PredicateOccurrenceMap(List<Rule> rules) {
        occurrencesAsPremise = new HashMap<>();
        occurrencesAsConclusion = new HashMap<>();

        List<Clause> allClauses = rules.stream().flatMap(r -> r.clauses.stream()).collect(Collectors.toList());
        MapPredicateToClauseClauseVisitor mapPredicateToClauseClauseVisitor = new MapPredicateToClauseClauseVisitor(occurrencesAsPremise, occurrencesAsConclusion);
        allClauses.forEach(c -> c.accept(mapPredicateToClauseClauseVisitor));
    }

    public List<Clause> getOccurrencesAsPremise(Predicate predicate) {
        return Collections.unmodifiableList(occurrencesAsPremise.getOrDefault(predicate, Collections.emptyList()));
    }

    public List<Clause> getOccurrencesAsConclusion(Predicate predicate) {
        return Collections.unmodifiableList(occurrencesAsConclusion.getOrDefault(predicate, Collections.emptyList()));
    }

    public Set<Predicate> getAllPredicates() {
        if(allPredicates == null) {
            allPredicates = new HashSet<>();
            allPredicates.addAll(occurrencesAsPremise.keySet());
            allPredicates.addAll(occurrencesAsConclusion.keySet());
            allPredicates = Collections.unmodifiableSet(allPredicates);
        }

        return allPredicates;
    }

    private static class MapPredicateToClauseClauseVisitor implements Clause.Visitor<Void> {
        private final Map<Predicate, List<Clause>> occurrencesAsPremise;
        private final Map<Predicate, List<Clause>> occurrencesAsConclusion;

        private MapPredicateToClauseClauseVisitor(Map<Predicate, List<Clause>> occurrencesAsPremise, Map<Predicate, List<Clause>> occurrencesAsConclusion) {
            this.occurrencesAsPremise = occurrencesAsPremise;
            this.occurrencesAsConclusion = occurrencesAsConclusion;
        }

        @Override
        public Void visit(Clause clause) {
            RetrievePredicatesPropositionVisitor propositionVisitor = new RetrievePredicatesPropositionVisitor();
            clause.premises.stream().map(p -> p.accept(propositionVisitor)).filter(Optional::isPresent).map(Optional::get).forEach(p -> occurrencesAsPremise.compute(p, (ignored, list) -> addIfPresent(clause, list)));
            occurrencesAsConclusion.compute(clause.conclusion.predicate, (ignored, list) -> addIfPresent(clause, list));
            return null;
        }

        private List<Clause> addIfPresent(Clause clause, List<Clause> list) {
            if (list == null) {
                ArrayList<Clause> newList = new ArrayList<>();
                newList.add(clause);
                return newList;
            } else {
                list.add(clause);
                return list;
            }
        }
    }
}
