package secpriv.horst.execution;

import com.microsoft.z3.BoolExpr;
import com.microsoft.z3.Fixedpoint;
import com.microsoft.z3.Params;
import com.microsoft.z3.Status;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import secpriv.horst.data.Predicate;
import secpriv.horst.data.Rule;
import secpriv.horst.translation.TranslateToZ3VisitorState;
import secpriv.horst.translation.visitors.TranslateToZ3RuleVisitor;
import secpriv.horst.visitors.RuleTypeOracle;
import secpriv.horst.visitors.VisitorState;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class StatelessZ3QueryExecutor {
    private static final String FIXED_POINT_PREFIX = "fp.";
    private final Function<Map<String, String>, TranslateToZ3VisitorState> z3TranslationStateSupplier;
    private final RuleTypeOracle ruleTypeOracle;
    private final List<Rule> rules;
    private final ExecutionStrategy executionStrategy;
    private final Map<String, String> fixedpointParams;
    private final Map<String, String> globalParams;

    private final static Logger logger = LogManager.getLogger(StatelessZ3QueryExecutor.class);

    public StatelessZ3QueryExecutor(Function<Map<String, String>, TranslateToZ3VisitorState> z3TranslationStateSupplier, Map<String, String> z3Parameters, List<Rule> rules, RuleTypeOracle ruleTypeOracle, ExecutionStrategy executionStrategy) {
        this.z3TranslationStateSupplier = Objects.requireNonNull(z3TranslationStateSupplier);
        this.ruleTypeOracle = Objects.requireNonNull(ruleTypeOracle);
        this.rules = Objects.requireNonNull(rules);
        this.executionStrategy = executionStrategy;
        this.fixedpointParams = z3Parameters.entrySet().stream().filter(e -> e.getKey().startsWith(FIXED_POINT_PREFIX)).collect(Collectors.toMap(e -> e.getKey().substring(FIXED_POINT_PREFIX.length()), Map.Entry::getValue));
        this.globalParams = z3Parameters.entrySet().stream().filter(e -> !e.getKey().startsWith(FIXED_POINT_PREFIX)).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }

    public StatelessZ3QueryExecutor(Function<Map<String, String>, TranslateToZ3VisitorState> z3TranslationStateSupplier, Map<String, String> z3Parameters, List<Rule> rules, RuleTypeOracle ruleTypeOracle) {
        this(z3TranslationStateSupplier, z3Parameters, rules, ruleTypeOracle, new ExecutionStrategy.ExecuteAllStrategy());
    }

    public ExecutionResult executeQuery(Rule query) {
        System.gc();
        Status result;
        long duration;
        String queryId;
        Optional<String> info = Optional.empty();

        Optional<ExecutionResult> optSubstituteResult = executionStrategy.getSubstituteResult(query);
        if (optSubstituteResult.isPresent()) {
            return optSubstituteResult.get();
        }

        try (TranslateToZ3VisitorState z3TranslationState = z3TranslationStateSupplier.apply(globalParams)) {
            long startPreparation = System.currentTimeMillis();
            Fixedpoint fixedpoint = initializeFixedPoint(z3TranslationState);

            List<BoolExpr> rulesForZ3 = new ArrayList<>();
            for (Rule rule : rules) {
                TranslateToZ3RuleVisitor translateToZ3RuleVisitor = new TranslateToZ3RuleVisitor(z3TranslationState);
                rulesForZ3.addAll(rule.accept(translateToZ3RuleVisitor));
            }

            for (BoolExpr b : rulesForZ3) {
                fixedpoint.addRule(b, null);
            }
            z3TranslationState.registerRelations(fixedpoint, false);

            logger.trace("Preparation overhead: {} ms", () -> (System.currentTimeMillis() - startPreparation));

            queryId = query.name;
            long start = System.currentTimeMillis();


            try {
                Predicate predicate = new Predicate(queryId, Collections.emptyList(), Collections.emptyList());
                BoolExpr z3query = (BoolExpr) z3TranslationState.getZ3PredicateDeclaration(predicate).apply();
                logger.trace("execute {}", queryId);
                result = fixedpoint.query(z3query);
            } catch (Exception e) {
                result = Status.UNKNOWN;
                info = Optional.of(e.getClass().getSimpleName() + ": " + e.getMessage());
            }
            duration = System.currentTimeMillis() - start;

        }
        System.gc();


        ExecutionResult executionResult;
        if (ruleTypeOracle.isTest(query)) {
            boolean success = result != Status.UNKNOWN && ruleTypeOracle.isExpectedTestResult(query, VisitorState.TestResult.fromZ3Result(result));
            executionResult = new ExecutionResult.TestResult(queryId, result, duration, success, info);
        } else {
            executionResult = new ExecutionResult.QueryResult(queryId, result, duration, info);
        }

        executionStrategy.registerResult(executionResult);

        return executionResult;
    }

    private Fixedpoint initializeFixedPoint(TranslateToZ3VisitorState z3TranslationState) {
        Fixedpoint fixedpoint = z3TranslationState.context.mkFixedpoint();

        Params params = z3TranslationState.context.mkParams();
        for (Map.Entry<String, String> entry : fixedpointParams.entrySet()) {
            if(entry.getValue().equals("true")) {
                params.add(entry.getKey(), true);
            } else if(entry.getValue().equals("false")) {
                params.add(entry.getKey(), false);
            } else {
                params.add(entry.getKey(), entry.getKey());
            }
        }

        fixedpoint.setParameters(params);

        return fixedpoint;
    }
}
