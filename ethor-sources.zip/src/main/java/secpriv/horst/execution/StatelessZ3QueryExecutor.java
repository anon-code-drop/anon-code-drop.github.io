package secpriv.horst.execution;

import com.microsoft.z3.BoolExpr;
import com.microsoft.z3.Fixedpoint;
import com.microsoft.z3.Params;
import com.microsoft.z3.Status;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import secpriv.horst.data.Predicate;
import secpriv.horst.data.Rule;
import secpriv.horst.translation.TranslateToZ3VisitorState;
import secpriv.horst.translation.visitors.TranslateToZ3RuleVisitor;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class StatelessZ3QueryExecutor {
    private static final String FIXED_POINT_PREFIX = "fp.";
    private final Function<Map<String, String>, TranslateToZ3VisitorState> z3TranslationStateSupplier;
    private final List<Rule> rules;
    private final ExecutionStrategy executionStrategy;
    private final Map<String, String> fixedpointParams;
    private final Map<String, String> globalParams;

    private final static Logger logger = LogManager.getLogger(StatelessZ3QueryExecutor.class);
    private final List<QuerySpecificPreprocessingStrategy> querySpecificPreprocessingStrategies;

    public StatelessZ3QueryExecutor(Function<Map<String, String>, TranslateToZ3VisitorState> z3TranslationStateSupplier, Map<String, String> z3Parameters, List<Rule> rules, ExecutionStrategy executionStrategy, List<QuerySpecificPreprocessingStrategy> querySpecificPreprocessingStrategies) {
        this.z3TranslationStateSupplier = Objects.requireNonNull(z3TranslationStateSupplier);
        this.rules = Objects.requireNonNull(rules);
        this.executionStrategy = executionStrategy;
        this.fixedpointParams = z3Parameters.entrySet().stream().filter(e -> e.getKey().startsWith(FIXED_POINT_PREFIX)).collect(Collectors.toMap(e -> e.getKey().substring(FIXED_POINT_PREFIX.length()), Map.Entry::getValue));
        this.globalParams = z3Parameters.entrySet().stream().filter(e -> !e.getKey().startsWith(FIXED_POINT_PREFIX)).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        this.querySpecificPreprocessingStrategies = Objects.requireNonNull(querySpecificPreprocessingStrategies);
    }

    public StatelessZ3QueryExecutor(Function<Map<String, String>, TranslateToZ3VisitorState> z3TranslationStateSupplier, Map<String, String> z3Parameters, List<Rule> rules) {
        this(z3TranslationStateSupplier, z3Parameters, rules, new ExecutionStrategy.ExecuteAllStrategy(), Collections.emptyList());
    }


    public ExecutionResult executeQuery(Predicate query) {
        System.gc();
        Status result;
        long duration;
        Optional<String> info = Optional.empty();

        Optional<ExecutionResult> optSubstituteResult = executionStrategy.getSubstituteResult(query);
        if (optSubstituteResult.isPresent()) {
            return optSubstituteResult.get();
        }

        Optional<List<Rule>> optPreprocessedRules = preprocessRules(query);
        if (optPreprocessedRules.isPresent()) {
            if (optPreprocessedRules.get().stream().flatMap(r -> r.clauses.stream()).noneMatch(c -> c.conclusion.predicate.equals(query))) {
                info = Optional.of("Query eliminated during preprocessing.");
                result = Status.UNSATISFIABLE;
                duration = 0L;
            } else {
                try (TranslateToZ3VisitorState z3TranslationState = z3TranslationStateSupplier.apply(globalParams)) {
                    long startPreparation = System.currentTimeMillis();
                    Fixedpoint fixedpoint = initializeFixedPoint(z3TranslationState);

                    List<BoolExpr> rulesForZ3 = new ArrayList<>();
                    for (Rule rule : optPreprocessedRules.get()) {
                        TranslateToZ3RuleVisitor translateToZ3RuleVisitor = new TranslateToZ3RuleVisitor(z3TranslationState);
                        rulesForZ3.addAll(rule.accept(translateToZ3RuleVisitor));
                    }

                    for (BoolExpr b : rulesForZ3) {
                        fixedpoint.addRule(b, null);
                    }
                    z3TranslationState.registerRelations(fixedpoint, false);

                    logger.trace("Preparation overhead: {} ms", () -> (System.currentTimeMillis() - startPreparation));

                    long start = System.currentTimeMillis();

                    try {
                        BoolExpr z3query = (BoolExpr) z3TranslationState.getZ3PredicateDeclaration(query).apply();
                        logger.trace("execute {}", query.name);
                        result = fixedpoint.query(z3query);
                    } catch (Exception e) {
                        result = Status.UNKNOWN;
                        info = Optional.of(e.getClass().getSimpleName() + ": " + e.getMessage());
                    }
                    duration = System.currentTimeMillis() - start;
                }
            }
        } else {
            info = Optional.of("Query specific pruning returned Optional.empty(), this likely indicates a timeout.");
            result = Status.UNKNOWN;
            duration = 0L;
        }
        System.gc();

        Optional<String> finalInfo = info;

        class QueryToExecutionResultVisitor implements Predicate.Visitor<ExecutionResult> {
            final private Status result;

            private QueryToExecutionResultVisitor(Status result) {
                this.result = result;
            }

            @Override
            public ExecutionResult visit(Predicate.RegularPredicate predicate) {
                throw new RuntimeException("Queried regular predicate " + predicate.name + "!");
            }

            @Override
            public ExecutionResult visit(Predicate.QueryPredicate predicate) {
                return new ExecutionResult.QueryResult(query.name, result, duration, finalInfo);
            }

            @Override
            public ExecutionResult visit(Predicate.TestPredicate predicate) {
                boolean success = result != Status.UNKNOWN && predicate.expectedResult == Predicate.TestResult.fromZ3Result(result);
                return new ExecutionResult.TestResult(query.name, result, duration, success, finalInfo);
            }
        }

        ExecutionResult executionResult = query.accept(new QueryToExecutionResultVisitor(result));
        executionStrategy.registerResult(executionResult);

        return executionResult;
    }

    private Fixedpoint initializeFixedPoint(TranslateToZ3VisitorState z3TranslationState) {
        Fixedpoint fixedpoint = z3TranslationState.context.mkFixedpoint();

        Params params = z3TranslationState.context.mkParams();
        for (Map.Entry<String, String> entry : fixedpointParams.entrySet()) {
            if (entry.getValue().equals("true")) {
                params.add(entry.getKey(), true);
            } else if (entry.getValue().equals("false")) {
                params.add(entry.getKey(), false);
            } else {
                params.add(entry.getKey(), entry.getKey());
            }
        }

        fixedpoint.setParameters(params);

        return fixedpoint;
    }

    private Optional<List<Rule>> preprocessRules(Predicate query) {
        List<Rule> rules = this.rules;

        for (QuerySpecificPreprocessingStrategy preprocessingStrategy : querySpecificPreprocessingStrategies) {
            Optional<List<Rule>> optRules = preprocessingStrategy.preprocessForQuery(rules, query);
            if (!optRules.isPresent()) {
                return Optional.empty();
            }
            rules = optRules.get();
        }

        return Optional.of(rules);
    }
}
