package secpriv.horst.execution;

import com.microsoft.z3.Status;
import secpriv.horst.data.Predicate;

import java.util.Optional;

public abstract class ExecutionStrategy {
    public abstract Optional<ExecutionResult> getSubstituteResult(Predicate query);

    public abstract void registerResult(ExecutionResult result);

    public enum Enum {
        all, abortOnFirstSat;

        public ExecutionStrategy getStrategy() {
            switch (this) {
                case all:
                    return new ExecuteAllStrategy();
                case abortOnFirstSat:
                    return new AbortOnFirstSatExecutionStrategy();
            }
            throw new RuntimeException("unreachable code!");
        }
    }

    public static class ExecuteAllStrategy extends ExecutionStrategy {
        @Override
        public Optional<ExecutionResult> getSubstituteResult(Predicate query) {
            return Optional.empty();
        }

        @Override
        public void registerResult(ExecutionResult result) {
        }
    }

    public static class AbortOnFirstSatExecutionStrategy extends ExecutionStrategy {
        private boolean hasEncounteredSatisfiableQuery = false;

        @Override
        public Optional<ExecutionResult> getSubstituteResult(Predicate query) {
            if (hasEncounteredSatisfiableQuery) {
                return Optional.of(new ExecutionResult.QueryResult(query.name, Status.UNKNOWN, 0L, Optional.of("Query was not executed because a satisfiable query was encountered before!")));
            }
            return Optional.empty();
        }

        @Override
        public void registerResult(ExecutionResult result) {
            if (result.status == Status.SATISFIABLE) {
                hasEncounteredSatisfiableQuery = true;
            }
        }
    }
}
