package secpriv.horst.execution;

import com.microsoft.z3.BoolExpr;
import com.microsoft.z3.Fixedpoint;
import com.microsoft.z3.Status;
import secpriv.horst.data.Predicate;
import secpriv.horst.data.Rule;
import secpriv.horst.translation.TranslateToZ3VisitorState;
import secpriv.horst.translation.visitors.TranslateToZ3RuleVisitor;
import secpriv.horst.visitors.RuleTypeOracle;
import secpriv.horst.visitors.VisitorState;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class StatefulZ3QueryExecutor implements AutoCloseable {
    private final TranslateToZ3VisitorState z3TranslationState;
    private final Fixedpoint fixedpoint;
    private final RuleTypeOracle ruleTypeOracle;

    public StatefulZ3QueryExecutor(TranslateToZ3VisitorState z3TranslationState, List<Rule> rules, RuleTypeOracle ruleTypeOracle) {
        this.z3TranslationState = z3TranslationState;
        this.fixedpoint = z3TranslationState.context.mkFixedpoint();
        this.ruleTypeOracle = ruleTypeOracle;

        List<BoolExpr> rulesForZ3 = new ArrayList<>();
        for (Rule rule : rules) {
            TranslateToZ3RuleVisitor translateToZ3RuleVisitor = new TranslateToZ3RuleVisitor(z3TranslationState);
            rulesForZ3.addAll(rule.accept(translateToZ3RuleVisitor));
        }

        for (BoolExpr b : rulesForZ3) {
            fixedpoint.addRule(b, null);
        }
        z3TranslationState.registerRelations(fixedpoint, false);
    }

    public ExecutionResult executeQuery(Rule query) {
        System.gc();
        String queryId = query.name;
        long start = System.currentTimeMillis();

        Status result;
        Optional<String> info = Optional.empty();

        try {
            Predicate predicate = new Predicate(queryId, Collections.emptyList(), Collections.emptyList());
            BoolExpr z3query = (BoolExpr) z3TranslationState.getZ3PredicateDeclaration(predicate).apply();
            System.out.println("execute " + queryId);
            result = fixedpoint.query(z3query);
        } catch (Exception e) {
            result = Status.UNKNOWN;
            info = Optional.of(e.getMessage());
        }

        long duration = System.currentTimeMillis() - start;

        if (ruleTypeOracle.isTest(query)) {
            boolean success = result != Status.UNKNOWN && ruleTypeOracle.isExpectedTestResult(query, VisitorState.TestResult.fromZ3Result(result));
            return new ExecutionResult.TestResult(queryId, result, duration, success, info);
        } else {
            return new ExecutionResult.QueryResult(queryId, result, duration, info);
        }
    }

    @Override
    public void close() {
        z3TranslationState.close();
    }
}
