package secpriv.horst.execution;

import secpriv.horst.data.Clause;
import secpriv.horst.data.Predicate;
import secpriv.horst.data.Rule;
import secpriv.horst.tools.SmtLibGenerator;
import secpriv.horst.translation.ClauseFilteringRuleVisitor;
import secpriv.horst.translation.PredicateInliningStrategy;
import secpriv.horst.translation.PruneStrategy;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

public abstract class QuerySpecificPreprocessingStrategy {
    public abstract Optional<List<Rule>> preprocessForQuery(List<Rule> rules, Predicate query);

    public static class NoneQuerySpecificPreprocessingStrategy extends QuerySpecificPreprocessingStrategy {
        @Override
        public Optional<List<Rule>> preprocessForQuery(List<Rule> rules, Predicate query) {
            return Optional.of(rules);
        }
    }

    public static class WriteSmtOutPreprocessingStrategy extends QuerySpecificPreprocessingStrategy {
        private final String fileName;
        private final String header;

        public WriteSmtOutPreprocessingStrategy(String fileName, String header) {
            this.fileName = Objects.requireNonNull(fileName);
            this.header = Objects.requireNonNull(header);
        }

        @Override
        public Optional<List<Rule>> preprocessForQuery(List<Rule> rules, Predicate query) {
            SmtLibGenerator.writeSmtLibToFile(fileName + "-" + query.name + ".smt", rules, Collections.singleton(query), header + "; query: " + query.name + "\n");
            return Optional.of(rules);
        }
    }

    public static abstract class FilterFirstQuerySpecificPreprocessingStrategy extends QuerySpecificPreprocessingStrategy {
        final PreprocessingStrategy preprocessingStrategy;

        FilterFirstQuerySpecificPreprocessingStrategy(PreprocessingStrategy preprocessingStrategy) {
            this.preprocessingStrategy = preprocessingStrategy;
        }

        @Override
        public Optional<List<Rule>> preprocessForQuery(List<Rule> rules, Predicate query) {
            return applyQuerySpecific(rules, preprocessingStrategy, query);
        }
    }

    public static class ApplyMediumStepTransformationPreprocessingStrategy extends FilterFirstQuerySpecificPreprocessingStrategy {
        public ApplyMediumStepTransformationPreprocessingStrategy(PruneStrategy pruneStrategy, PredicateInliningStrategy predicateInliningStrategy) {
            super(new PreprocessingStrategy.ApplyMediumStepTransformationPreprocessingStrategy(pruneStrategy, predicateInliningStrategy));
        }
    }


    public static class ApplyMediumStepTransformationWithTimeoutPreprocessingStrategy extends FilterFirstQuerySpecificPreprocessingStrategy {
        public ApplyMediumStepTransformationWithTimeoutPreprocessingStrategy(PruneStrategy pruneStrategy, PredicateInliningStrategy predicateInliningStrategy, long timeout) {
            super(new PreprocessingStrategy.ApplyMediumStepTransformationWithTimeoutPreprocessingStrategy(pruneStrategy, predicateInliningStrategy, timeout));
        }
    }

    private static Optional<List<Rule>> applyQuerySpecific(List<Rule> rules, PreprocessingStrategy preprocessingStrategy, Predicate query) {
        FilterIrrelevantQueriesRulesVisitor rulesVisitor = new FilterIrrelevantQueriesRulesVisitor(query);
        return preprocessingStrategy.preprocess(rules.stream().map(r -> r.accept(rulesVisitor)).filter(Optional::isPresent).map(Optional::get).collect(Collectors.toList()), Collections.singleton(query));
    }

    private static class FilterIrrelevantQueriesRulesVisitor extends ClauseFilteringRuleVisitor {
        FilterIrrelevantQueriesRulesVisitor(Predicate relevantPredicate) {
            super((Function<Clause, Optional<Clause>>) c -> {
                FilterIrrelevantQueriesPredicateVisitor predicateVisitor = new FilterIrrelevantQueriesPredicateVisitor(relevantPredicate);
                return c.conclusion.predicate.accept(predicateVisitor) ? Optional.of(c) : Optional.empty();
            });
        }
    }

    private static class FilterIrrelevantQueriesPredicateVisitor implements Predicate.Visitor<Boolean> {
        private final Predicate relevantPredicate;

        private FilterIrrelevantQueriesPredicateVisitor(Predicate relevantPredicate) {
            this.relevantPredicate = relevantPredicate;
        }

        @Override
        public Boolean visit(Predicate.RegularPredicate predicate) {
            return true;
        }

        @Override
        public Boolean visit(Predicate.QueryPredicate predicate) {
            return predicate.equals(relevantPredicate);
        }

        @Override
        public Boolean visit(Predicate.TestPredicate predicate) {
            return predicate.equals(relevantPredicate);
        }
    }
}
