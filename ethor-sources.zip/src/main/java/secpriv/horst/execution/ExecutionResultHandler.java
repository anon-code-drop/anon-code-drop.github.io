package secpriv.horst.execution;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public abstract class ExecutionResultHandler {
    public abstract void handle(List<ExecutionResult> results);

    public static class JsonOutputExecutionResultHandler extends ExecutionResultHandler {
        private final String outputFileName;

        public JsonOutputExecutionResultHandler(String outputFileName) {
            this.outputFileName = outputFileName;
        }

        @Override
        public void handle(List<ExecutionResult> results) {
            try (PrintWriter writer = new PrintWriter(outputFileName)) {
                Gson gson = new Gson();

                JsonObject o = new JsonObject();
                gson.toJson(results, writer);
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public static class ConsoleOutputExecutionResultHandler extends ExecutionResultHandler {
        private final String contractName;

        public ConsoleOutputExecutionResultHandler(String contractName) {
            this.contractName = contractName;
        }

        @Override
        public void handle(List<ExecutionResult> results) {
            System.out.println("Results for " + contractName + ":");

            TestAndQuerySeparatingVisitor separator = new TestAndQuerySeparatingVisitor();
            results.forEach(r -> r.accept(separator));
            if(!separator.queryResults.isEmpty()) {
                System.out.println("Queries");
                for(ExecutionResult.QueryResult result: separator.queryResults) {
                    printQueryResult(result);
                }
            }
            if(!separator.testResults.isEmpty()) {
                long testCount = separator.testResults.size();
                long failCount = separator.testResults.stream().filter(t -> !t.success).count();

                if(failCount == 0) {
                    System.out.println("All " + testCount + " tests passed!");
                } else {
                    System.out.println(failCount + " of " + testCount + " tests failed!");
                    for(ExecutionResult.TestResult result : separator.testResults.stream().filter(t -> !t.success).collect(Collectors.toList())) {
                        printQueryResult(result);
                    }
                }
            }

        }

        private void printQueryResult(ExecutionResult result) {
            System.out.println("query id:       " + result.queryId);
            System.out.println("execution time: " + result.executionTime);
            System.out.println("result:         " + result.status);
            result.info.ifPresent(s -> System.out.println("info:           " + s));
        }
    }

    private static class TestAndQuerySeparatingVisitor implements ExecutionResult.Visitor<Void> {
        public final List<ExecutionResult.QueryResult> queryResults = new ArrayList<>();
        public final List<ExecutionResult.TestResult> testResults = new ArrayList<>();

        @Override
        public Void accept(ExecutionResult.QueryResult queryResult) {
            queryResults.add(queryResult);
            return null;
        }

        @Override
        public Void accept(ExecutionResult.TestResult testResult) {
            testResults.add(testResult);
            return null;
        }
    }
}
