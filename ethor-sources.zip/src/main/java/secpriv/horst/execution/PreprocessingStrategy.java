package secpriv.horst.execution;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import secpriv.horst.data.Predicate;
import secpriv.horst.data.Rule;
import secpriv.horst.tools.PredicateHelper;
import secpriv.horst.tools.SmtLibGenerator;
import secpriv.horst.translation.MediumStepTransformer;
import secpriv.horst.translation.PredicateInliningStrategy;
import secpriv.horst.translation.PruneStrategy;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.*;
import java.util.stream.Collectors;

public abstract class PreprocessingStrategy {
    public abstract Optional<List<Rule>> preprocess(List<Rule> rules, Set<Predicate> queries);

    public static class NonePreprocessingStrategy extends PreprocessingStrategy {
        @Override
        public Optional<List<Rule>> preprocess(List<Rule> rules, Set<Predicate> queries) {
            return Optional.of(rules);
        }
    }

    public static class ApplyMediumStepTransformationPreprocessingStrategy extends PreprocessingStrategy {
        final PruneStrategy pruneStrategy;
        final PredicateInliningStrategy predicateInliningStrategy;

        public ApplyMediumStepTransformationPreprocessingStrategy(PruneStrategy pruneStrategy, PredicateInliningStrategy predicateInliningStrategy) {
            this.pruneStrategy = Objects.requireNonNull(pruneStrategy);
            this.predicateInliningStrategy = Objects.requireNonNull(predicateInliningStrategy);
        }

        @Override
        public Optional<List<Rule>> preprocess(List<Rule> rules, Set<Predicate> queries) {
            return Optional.of(MediumStepTransformer.foldToMediumStepsWithMagic(rules, pruneStrategy, predicateInliningStrategy));
        }
    }

    public static class ApplyMediumStepTransformationWithTimeoutPreprocessingStrategy extends ApplyMediumStepTransformationPreprocessingStrategy {
        private static final Logger logger = LogManager.getLogger(ApplyMediumStepTransformationWithTimeoutPreprocessingStrategy.class);
        private final long timeout;

        public ApplyMediumStepTransformationWithTimeoutPreprocessingStrategy(PruneStrategy pruneStrategy, PredicateInliningStrategy predicateInliningStrategy, long timeout) {
            super(pruneStrategy, predicateInliningStrategy);
            this.timeout = timeout;
        }

        @Override
        public Optional<List<Rule>> preprocess(List<Rule> rules, Set<Predicate> queries) {
            ExecutorService executor = Executors.newCachedThreadPool();

            Future<List<Rule>> future = executor.submit(() -> MediumStepTransformer.foldToMediumStepsWithMagic(rules, pruneStrategy, predicateInliningStrategy));

            Optional<List<Rule>> ret = Optional.empty();

            try {
                ret = Optional.of(future.get(timeout, TimeUnit.SECONDS));
            } catch (InterruptedException | ExecutionException e) {
                logger.error(e);
                throw new RuntimeException(e);
            } catch (TimeoutException e) {
                logger.error("Folding timed out!");
            } finally {
                future.cancel(true);
                executor.shutdownNow();
            }
            return ret;
        }
    }

    public static class WriteSmtOutPreprocessingStrategy extends PreprocessingStrategy {
        private final String fileName;
        private final String header;

        public WriteSmtOutPreprocessingStrategy(String fileName, String header) {
            this.fileName = Objects.requireNonNull(fileName);
            this.header = Objects.requireNonNull(header);
        }

        @Override
        public Optional<List<Rule>> preprocess(List<Rule> rules, Set<Predicate> queries) {
            SmtLibGenerator.writeSmtLibToFile(fileName, rules, queries, header);
            return Optional.of(rules);
        }
    }
}
