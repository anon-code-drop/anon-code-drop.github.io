package secpriv.horst.evm;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.microsoft.z3.Status;
import picocli.CommandLine;
import secpriv.horst.data.Rule;
import secpriv.horst.execution.ExecutionResult;
import secpriv.horst.execution.ExecutionResultHandler;
import secpriv.horst.execution.StatelessZ3QueryExecutor;
import secpriv.horst.internals.SelectorFunctionHelper;
import secpriv.horst.internals.SelectorFunctionInvoker;
import secpriv.horst.internals.error.handling.ExceptionThrowingErrorHandler;
import secpriv.horst.tools.HorstFileParser;
import secpriv.horst.tools.QueryNameParser;
import secpriv.horst.translation.*;
import secpriv.horst.translation.layout.FlatTypeLayouterWithBoolean;
import secpriv.horst.translation.visitors.*;
import secpriv.horst.visitors.RuleTypeOracle;
import secpriv.horst.visitors.StateBasedRuleTypeOracle;
import secpriv.horst.visitors.VisitorState;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.*;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;

@CommandLine.Command(name = "EvmJumpDestinationReconstructor", mixinStandardHelpOptions = true, version = "JumpDestinationReconstructor version 0.0")
public class EvmJumpDestinationReconstructor implements Runnable {
    private static final String JUMP_RULE_NAME = "opJump";
    private static final String JUMPI_RULE_NAME = "opJumpi";
    private static final String JUMP_QUERY_NAME = "jumpDestReconstruction";
    private static final String JUMPI_QUERY_NAME = "jumpiDestReconstruction";
    private static final String JUMP_UNIQUENESS_QUERY_NAME = "jumpDestReconstructionUniqueness";
    private static final String JUMPI_UNIQUENESS_QUERY_NAME = "jumpiDestReconstructionUniqueness";
    private static final String JUMP_ALL_KNOWN_QUERY_NAME = "jumpDestReconstructionAllKnown";
    private static final String JUMPI_ALL_KNOWN_QUERY_NAME = "jumpiDestReconstructionAllKnown";

    @CommandLine.Option(names = {"-s", "--spec"}, description = "Provide the HoRSt spec to compile. You can specify multiple files. The definitions of one file " +
            "will be visible in the the subsequent files.", arity = "1..*")
    private String[] horstFiles = new String[0];

    @CommandLine.Option(names = {"-b", "--big-step-encoding"}, description = "Apply big-step encoding")
    private boolean bigStep = false;

    @CommandLine.Option(names = {"-p", "--preanalysis"}, description = "Apply pre-analysis")
    private boolean pre = false;

    @CommandLine.Parameters
    private File[] contractFiles;

    @CommandLine.Option(names = {"--out-dir"}, description = "Directory files are written.")
    private String outDir;

    @CommandLine.Option(names = {"--time-out"}, description = "Specifies timeout per contract in milliseconds (this wont abort queries).")
    private int timeOut;

    @CommandLine.Option(names = {"--rlimit-start"}, defaultValue = "1600000", description = "Initial rlimit used for reachability queries.")
    private long rlimitStart;

    @CommandLine.Option(names = {"--rlimit-multiplier"}, defaultValue = "2", description = "Value by which rlimit is multiplied after each unsuccessful round.")
    private long rlimitMultiplicator;

    @CommandLine.Option(names = {"--uniqueness-boost"}, defaultValue = "8", description = "Value by which rlimit is multiplied when checking uniqueness.")
    private int uniquenessBoost;

    @CommandLine.Option(names = {"--json-out-dir"}, description = "Directory files are written.")
    private String jsonOutDir;

    @CommandLine.Option(names = {"--approach-from-above"}, description = "Use the \"approach from above\"-algorithm.")
    private boolean approachFromAbove;


    final int abortAtFailedIteration = 7;

    public static void main(String[] args) {
        CommandLine.run(new EvmJumpDestinationReconstructor(), args);
    }

    public static class PossibleJumpDestProvider {
        private final Map<BigInteger, List<BigInteger>> provenJumpDests;

        public PossibleJumpDestProvider(Map<BigInteger, List<BigInteger>> provenJumpDests) {
            this.provenJumpDests = provenJumpDests;
        }

        public Iterable<BigInteger> provenJumpDestsForIdAndPc(BigInteger id, BigInteger pc) {
            return provenJumpDests.getOrDefault(pc, Collections.emptyList());
        }
    }

    public static class ContractWithJumpDestinations {
        public final String bytecode;
        public final String address;
        public final BigInteger balance;
        public final Map<BigInteger, List<BigInteger>> jumpDestinations;

        public ContractWithJumpDestinations(EvmSourceProvider.EvmSourceWithBalanceProvider evmSourceWithBalanceProvider, Map<BigInteger, List<BigInteger>> jumpDestinations) {
            this.bytecode = evmSourceWithBalanceProvider.getSource();
            this.address = evmSourceWithBalanceProvider.getIdAsString();
            this.balance = evmSourceWithBalanceProvider.getBalance();
            this.jumpDestinations = jumpDestinations;
        }
    }

    private enum RuleType {
        REGULAR, JUMP, REACHABILITY_QUERY, QUERY, UNIQUENESS_QUERY, ALL_KNOWN_QUERY
    }

    private boolean timeOutReached;
    private long start;


    private void checkTimeOut() throws TimeoutException {
        if (timeOut > 0) {
            if (System.currentTimeMillis() - start > timeOut) {
                timeOutReached = true;
                throw new TimeoutException("Timeout reached!");
            }
        }
    }

    @Override
    public void run() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        for (File contractFile : contractFiles) {
            start = System.currentTimeMillis();
            timeOutReached = false;
            System.out.println(contractFile.getName());
            SelectorFunctionHelper compiler = new SelectorFunctionHelper();
            EvmSourceProvider.EvmSourceWithBalanceProvider evmSourceProvider = EvmSourceProvider.fromJsonFileWithBalance(contractFile);
            ContractInfoReader contractInfoReader = new ContractInfoReader(evmSourceProvider, false);
            EvmSelectorFunctionProviderTemplate providerTemplate;

            BigInteger id = evmSourceProvider.getId();


            JumpMap jumpMap;
            PossibleJumpDestProvider possibleJumpDestProvider;
            {
                Map<BigInteger, List<BigInteger>> possibleJumpDests = contractInfoReader.contractInfos.get(id).jumps;
                Map<BigInteger, List<BigInteger>> provenJumpDests = new HashMap<>();

                if (pre) {
                    ConstantAnalysis ca = new ConstantAnalysis(contractInfoReader.getContractInfos());
                    ca.getBlocksFromBytecode();
                    ca.runBlocks();
                    ca.printBlocks();
                    providerTemplate = ca;
                } else {
                    providerTemplate = new EvmSelectorFunctionProvider(contractInfoReader.getContractInfos());
                }

                // Okay, this is tricky but also likely irrelevant. We cannot really know, if the preanalysis figured out
                // a singleton jump destination or if there is only one jump destination in the whole contract. If there
                // is ONE jump with more than one jumpDestination, we assume those who only have one jump destination to
                // be "proven". Else we assume nothing. This is for performance.
                Optional<Integer> max = possibleJumpDests.values().stream().map(List::size).max(Integer::compareTo);

                if (max.isPresent() && max.get() > 1) {
                    for (Map.Entry<BigInteger, List<BigInteger>> entry : possibleJumpDests.entrySet()) {
                        if (entry.getValue().size() == 1) {
                            provenJumpDests.put(entry.getKey(), entry.getValue());
                        }
                    }
                }

                jumpMap = new JumpMap(possibleJumpDests, provenJumpDests);
                possibleJumpDestProvider = new PossibleJumpDestProvider(provenJumpDests);
            }

            compiler.registerProvider(providerTemplate);
            compiler.registerProvider(possibleJumpDestProvider);

            VisitorState state = new VisitorState();
            state.errorHandler = new ExceptionThrowingErrorHandler();
            state.setSelectorFunctionHelper(compiler);

            state = HorstFileParser.parseAllHorstFiles(state, horstFiles);

            RuleTypeOracle ruleTypeOracle = new StateBasedRuleTypeOracle(state);

            TranslationPipeline horstRulePipeline = TranslationPipeline
                    .builder()
                    .addStep(new InlineOperationsRuleVisitor(new ArrayList<>(state.getOperations().values())))
                    .addStep(new InlineTypesRuleVisitor(new InlineTypesExpressionVisitor(new FlatTypeLayouterWithBoolean())))
                    .build();

            List<Rule> initialRules = horstRulePipeline.apply(new ArrayList<>(state.getRules().values()));

            JumpDestinationReconstructionRuleTypeOracle jumpDestinationReconstructionRuleTypeOracle = new JumpDestinationReconstructionRuleTypeOracle(ruleTypeOracle);

            Map<RuleType, List<Rule>> rulesByRuleType = initialRules.stream().collect(Collectors.groupingBy(jumpDestinationReconstructionRuleTypeOracle::getRuleTypeForNonInstantiatedRule));

            // Generate QueryParser for all queries and jump rules
            QueryNameParser queryParser = new QueryNameParser(rulesByRuleType.entrySet().stream().filter(e -> e.getKey() != RuleType.REGULAR).flatMap(e -> e.getValue().stream()).collect(Collectors.toList()));

            TranslationPipeline instantiationPipeline = TranslationPipeline.builder()
                    .addFlatMappingStep(new InstantiateParametersRuleVisitor(new SelectorFunctionInvoker(compiler)))
                    .addStep(new SimplifyPredicateArgumentsRuleVisitor())
                    .addStep(new RenameFreeVariablesRuleVisitor())
                    .addStep(new ConservativelyAllocatingConstantFoldingRuleVisitor())
                    .addStep(new FilterUnapplicableClausesRuleVisitor(ruleTypeOracle))
                    .addStep(new RemoveTruePremiseRuleVisitor()).build();

            System.out.println("Finished Preprocessing, starting jump destination reconstruction... (" + (System.currentTimeMillis() - start) + " ms)");

            if (approachFromAbove) {
                approachFromAbove(jumpMap, rulesByRuleType, ruleTypeOracle, queryParser, instantiationPipeline);
            } else {
                approachFromBelow(jumpMap, rulesByRuleType, ruleTypeOracle, queryParser, instantiationPipeline);
            }

            System.out.println("########################################");
            System.out.println("Final jumpdests: ");
            System.out.println(jumpMap);
            System.out.println("########################################");

            String postFix = "-with-jumpdests.json";

            if (timeOutReached) {
                postFix = "-with-abort-timeout-" + timeOut + ".json";
            } else if (jumpMap.getUndeterminedCount() != 0) {
                postFix = "-with-jumpdests-abort-" + abortAtFailedIteration + ".json";
            }

            try (PrintWriter writer = new PrintWriter(jsonOutDir + "/" + cutFileExtension(contractFile.getName(), ".json") + postFix)) {
                writer.write(gson.toJson(new ContractWithJumpDestinations(evmSourceProvider, contractInfoReader.contractInfos.get(id).jumps)));
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            }

            System.out.println("Total time: " + (System.currentTimeMillis() - start) + " ms");
        }
    }

    private JumpMap approachFromBelow(JumpMap jumpMap, Map<RuleType, List<Rule>> rulesByRuleType, RuleTypeOracle ruleTypeOracle, QueryNameParser queryParser, TranslationPipeline instantiationPipeline) {
        List<Rule> regularRules = rulesByRuleType.getOrDefault(RuleType.REGULAR, Collections.emptyList());

        List<Rule> jumpRules = rulesByRuleType.getOrDefault(RuleType.JUMP, Collections.emptyList());
        List<Rule> queryRules = rulesByRuleType.getOrDefault(RuleType.QUERY, Collections.emptyList());
        List<Rule> reachabilityQueryRules = rulesByRuleType.getOrDefault(RuleType.REACHABILITY_QUERY, Collections.emptyList());
        List<Rule> uniquenessQueryRules = rulesByRuleType.getOrDefault(RuleType.UNIQUENESS_QUERY, Collections.emptyList());

        List<Rule> instantiatedNonJumpRules = Collections.unmodifiableList(instantiationPipeline.apply(regularRules));

        long rlimit = rlimitStart;
        Map<String, Integer> unknownResultCount = new HashMap<>();

        int realIterations = -1;
        try {
            for (int failedIterations = 0; failedIterations < abortAtFailedIteration && rlimit >= 0 && jumpMap.getUndeterminedCount() > 0; ) {
                ++realIterations;
                System.out.println();
                System.out.println("############");
                System.out.println();
                System.out.println("Iteration " + failedIterations + "(" + realIterations + ")");
                System.out.println("rlimit: " + rlimit);
                System.out.println(jumpMap);
                System.out.println("undetermined count: " + jumpMap.getUndeterminedCount());

                // Add all instantiated regular rules rules and reinstantiate query rules and jumps in case something has changed
                List<Rule> allRules = new ArrayList<>(instantiatedNonJumpRules);
                allRules.addAll(instantiationPipeline.apply(jumpRules));

                List<Rule> instantiatedReachabilityQueries = instantiationPipeline.apply(reachabilityQueryRules).stream().filter(r -> filterProvenJumps(jumpMap, queryParser, r)).collect(Collectors.toList());
                allRules.addAll(instantiatedReachabilityQueries);

                List<Rule> instantiatedQueryRules = instantiationPipeline.apply(queryRules);
                allRules.addAll(instantiatedQueryRules);

                allRules = applyFolding(ruleTypeOracle, allRules);

                StatelessZ3QueryExecutor executor = new StatelessZ3QueryExecutor(TranslateToZ3VisitorState::withGeneralIntegers, Collections.singletonMap("rlimit", Long.toString(rlimit)), allRules, ruleTypeOracle);

                int removedPossibilities = 0;

                // Execute all "regular" queries (i.e. the ones that are not needed for the jumpdest reconstruction algorithm) this is mainly for debugging.
                for (Rule generalQuery : instantiatedQueryRules) {
                    checkTimeOut();
                    ExecutionResult result = executor.executeQuery(generalQuery);
                    (new ExecutionResultHandler.ConsoleOutputExecutionResultHandler("General")).handle(Collections.singletonList(result));
                }


                // Every query had a certain amount of "UNKNOWN" results. We only execute those with the least amount of "UNKNOWN" results (so that we ask the potentially easiest queries first)
                int totalQueryCount = instantiatedReachabilityQueries.size();
                int minUnknownCountLevel = instantiatedReachabilityQueries.stream().map(q -> unknownResultCount.getOrDefault(q.name, 0)).min(Integer::compareTo).get();
                instantiatedReachabilityQueries = instantiatedReachabilityQueries.stream().filter(q -> unknownResultCount.getOrDefault(q.name, 0) == minUnknownCountLevel).collect(Collectors.toList());

                // If every query that's still around has already been unsuccessfully asked once, start querying for uniqueness again
                if (minUnknownCountLevel > 0) {
                    // Uniqueness candidates are jumps where we have proven some jumpdestinations and no reason to believe, that they are not unique
                    Collection<BigInteger> uniquenessTestCandidates = jumpMap.getUniquenessTestCandidates();
                    if (!uniquenessTestCandidates.isEmpty()) {
                        System.out.println("Re-checking for uniqueness:");
                        for (BigInteger pc : uniquenessTestCandidates) {
                            checkTimeOut();
                            Status uniquenessResult = isJumpUnique(rlimit, pc, ruleTypeOracle, instantiatedNonJumpRules, jumpRules, uniquenessQueryRules, queryParser, instantiationPipeline);
                            // If the uniqueness query is UNSAT, we regenerate everything if it's SAT, the jump loses its status as "uniqueness candidate"
                            if (uniquenessResult == Status.UNSATISFIABLE) {
                                removedPossibilities += jumpMap.addUniquenessProof(pc);
                                break;
                            } else if (uniquenessResult == Status.SATISFIABLE) {
                                jumpMap.addAmbiguityProof(pc);
                            }
                        }
                        // If we have remove jump possibilities: regenerate
                        if (removedPossibilities > 0) {
                            continue;
                        }
                    }
                }

                int executedQuery = 0;
                int lastRemovedPossibility = 0;
                int queryCount = instantiatedReachabilityQueries.size();

                // Execute all reachability queries
                System.out.println("Executing " + queryCount + " rules of unknownCountLevel " + minUnknownCountLevel + " (" + totalQueryCount + " in total).");
                for (Rule query : instantiatedReachabilityQueries) {
                    BigInteger pc = queryParser.getIntParameter(query.name, "!pc");
                    BigInteger jumpDest = queryParser.getIntParameter(query.name, "!j");

                    ++executedQuery;
                    System.out.print(executedQuery + ".\t");
                    checkTimeOut();
                    ExecutionResult result = executor.executeQuery(query);

                    (new ExecutionResultHandler.ConsoleOutputExecutionResultHandler("REACHABILITY")).handle(Collections.singletonList(result));

                    // If result is unknown increase unknown count of that query, if the result is UNSAT, remove the jump, if SAT check for uniqueness
                    if (result.status == Status.UNKNOWN) {
                        unknownResultCount.merge(result.queryId, 1, (oldValue, newValue) -> oldValue + 1);
                    } else if (result.status == Status.UNSATISFIABLE) {
                        ++removedPossibilities;
                        lastRemovedPossibility = executedQuery;
                        jumpMap.removePossibility(pc, jumpDest);
                    } else if (result.status == Status.SATISFIABLE) {
                        jumpMap.addProve(pc, jumpDest);
                        if (!jumpMap.isJumpUniquelyDetermined(pc)) {
                            checkTimeOut();
                            Status uniquenessResult = isJumpUnique(rlimit, pc, ruleTypeOracle, instantiatedNonJumpRules, jumpRules, uniquenessQueryRules, queryParser, instantiationPipeline);
                            if (uniquenessResult == Status.UNSATISFIABLE) {
                                removedPossibilities += jumpMap.addUniquenessProof(pc);
                                break;
                            } else if (uniquenessResult == Status.SATISFIABLE) {
                                jumpMap.addAmbiguityProof(pc);
                            }
                        }
                    } else {
                        throw new RuntimeException("Unreachable code!");
                    }

                    // if we handled half of the cases without finding a possibility to remove, break (this causes the
                    // rlimit to be raised, the remaining, so far unexecuted queries get executed before the other ones
                    // anyway, so if the would have been solved by the old rlimit, they also get solved with the new
                    // rlimit in the same time)
                    if (removedPossibilities == 0 && (totalQueryCount + 1) < executedQuery * 2) {
                        System.out.println(executedQuery + " of " + totalQueryCount + " (total) queries executed without success, raising rlimit...");
                        break;
                    }

                    // If we had some successes but fail repeatedly: regenerate
                    int unsuccessfulStreak = executedQuery - lastRemovedPossibility;
                    if (removedPossibilities > 2 && unsuccessfulStreak > 2 && failedIterations > 0) {
                        System.out.print("I have removed " + removedPossibilities + " possibilities, but was unsuccessful for " + unsuccessfulStreak + " queries. Regenerate Queries.");
                        break;
                    }
                }

                System.out.println("Removed Possibilites: " + removedPossibilities);

                if (removedPossibilities == 0) {
                    rlimit *= rlimitMultiplicator;
                    ++failedIterations;
                }
            }
        } catch (TimeoutException e) {
            System.out.println("Timeout occurred after " + (System.currentTimeMillis() - start) + " ms!");
        }

        return jumpMap;
    }

    private void approachFromAbove(JumpMap jumpMap, Map<RuleType, List<Rule>> rulesByRuleType, RuleTypeOracle ruleTypeOracle, QueryNameParser queryParser, TranslationPipeline instantiationPipeline) {
        List<Rule> regularRules = rulesByRuleType.getOrDefault(RuleType.REGULAR, Collections.emptyList());

        List<Rule> jumpRules = rulesByRuleType.getOrDefault(RuleType.JUMP, Collections.emptyList());
        List<Rule> queryRules = rulesByRuleType.getOrDefault(RuleType.QUERY, Collections.emptyList());
        List<Rule> allKnownQueryRules = rulesByRuleType.getOrDefault(RuleType.ALL_KNOWN_QUERY, Collections.emptyList());

        List<Rule> instantiatedNonJumpRules = Collections.unmodifiableList(instantiationPipeline.apply(regularRules));

        long rlimit = rlimitStart;

        List<Rule> allRules = new ArrayList<>(instantiatedNonJumpRules);
        allRules.addAll(instantiationPipeline.apply(jumpRules));

        List<Rule> instantiatedQueryRules = instantiationPipeline.apply(queryRules);
        allRules.addAll(instantiatedQueryRules);

        List<Rule> instantiatedAllKnownQueries = instantiationPipeline.apply(allKnownQueryRules).stream().filter(r -> filterUniqueJumps(jumpMap, queryParser, r)).collect(Collectors.toList());
        allRules.addAll(instantiatedAllKnownQueries);

        allRules = applyFolding(ruleTypeOracle, allRules);

        StatelessZ3QueryExecutor executor = new StatelessZ3QueryExecutor(TranslateToZ3VisitorState::withGeneralIntegers, Collections.singletonMap("rlimit", Long.toString(rlimit)), allRules, ruleTypeOracle);

        for (Rule generalQuery : instantiatedQueryRules) {
            ExecutionResult result = executor.executeQuery(generalQuery);
            (new ExecutionResultHandler.ConsoleOutputExecutionResultHandler("General")).handle(Collections.singletonList(result));
        }

        Set<BigInteger> allKnownPcs = new TreeSet<>();
        Set<BigInteger> notAllKnownPcs = new TreeSet<>();

        for (Rule query : instantiatedAllKnownQueries) {
            ExecutionResult result = executor.executeQuery(query);
            (new ExecutionResultHandler.ConsoleOutputExecutionResultHandler("ALL_KNOWN")).handle(Collections.singletonList(result));

            BigInteger pc = queryParser.getIntParameter(result.queryId, "!pc");

            if (result.status == Status.UNSATISFIABLE) {
                allKnownPcs.add(pc);

                checkWhichJumpDestinationCanBeRemoved(pc, rlimit, jumpMap, instantiatedNonJumpRules, jumpRules, allKnownQueryRules, instantiationPipeline, queryParser, ruleTypeOracle);

            } else {
                notAllKnownPcs.add(pc);
            }
        }

        System.out.println("Known: " + allKnownPcs);
        System.out.println("Unknown: " + notAllKnownPcs);

    }

    private void checkWhichJumpDestinationCanBeRemoved(BigInteger pc, long rlimit, JumpMap jumpMap, List<Rule> instantiatedNonJumpRules, List<Rule> jumpRules, List<Rule> allKnownQueryRules, TranslationPipeline instantiationPipeline, QueryNameParser queryParser, RuleTypeOracle ruleTypeOracle) {
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println("#########################################");
        System.out.println("EvmJumpDestinationReconstructor.checkWhichJumpDestinationCanBeRemoved");
        System.out.println("#########################################");
        long blaRlimit = 10000000;

        Set<BigInteger> removes = new TreeSet<>();
        Set<BigInteger> proofs = new TreeSet<>();

        for (BigInteger exclusion : jumpMap.getPossibilities(pc)) {
            jumpMap.removePossibility(pc, exclusion);
            List<Rule> allRules = new ArrayList<>(instantiatedNonJumpRules);
            allRules.addAll(instantiationPipeline.apply(jumpRules));

            Rule query = instantiationPipeline.apply(allKnownQueryRules).stream().filter(r -> queryParser.getIntParameter(r.name, "!pc").equals(pc)).findFirst().get();
            allRules.add(query);

            allRules = applyFolding(ruleTypeOracle, allRules);

            StatelessZ3QueryExecutor executor = new StatelessZ3QueryExecutor(TranslateToZ3VisitorState::withGeneralIntegers, Collections.singletonMap("rlimit", Long.toString(blaRlimit)), allRules, ruleTypeOracle);
            ExecutionResult result = executor.executeQuery(query);
            (new ExecutionResultHandler.ConsoleOutputExecutionResultHandler("ALL KNOWN")).handle(Collections.singletonList(result));

            if (result.status == Status.UNSATISFIABLE) {
                removes.add(exclusion);
                System.out.println(exclusion + " successfully removed!");
            } else {
                jumpMap.addPossibility(pc, exclusion);
                if (result.status == Status.SATISFIABLE) {
                    System.out.println("add prove!!!");
                    proofs.add(exclusion);
                    jumpMap.addProve(pc, exclusion);
                }
                System.out.println(exclusion + " readded!");
            }
        }
        System.out.println("##############################################");
        System.out.println("END: EvmJumpDestinationReconstructor.checkWhichJumpDestinationCanBeRemoved");
        System.out.println("proofs = " + proofs);
        System.out.println("removes = " + removes);
        System.out.println("##############################################");
        System.out.println();
        System.out.println();
        System.out.println();
    }

    private boolean filterUniqueJumps(JumpMap jumpMap, QueryNameParser queryParser, Rule r) {
        BigInteger pc = queryParser.getIntParameter(r.name, "!pc");
        return !jumpMap.isJumpUniquelyDetermined(pc);
    }

    private boolean filterProvenJumps(JumpMap jumpMap, QueryNameParser queryParser, Rule r) {
        BigInteger pc = queryParser.getIntParameter(r.name, "!pc");
        BigInteger jumpDest = queryParser.getIntParameter(r.name, "!j");
        return !jumpMap.isJumpProven(pc, jumpDest);
    }

    private List<Rule> applyFolding(RuleTypeOracle ruleTypeOracle, List<Rule> allRules) {
        long start = System.currentTimeMillis();
        if (bigStep) {
            allRules = MediumStepTransformer.foldToMediumStepsWithMagic(allRules, ruleTypeOracle, new PruneStrategy.NonePruneStrategy(), new PredicateInliningStrategy.LinearInliningStrategy());
        }

        System.out.println("Folding  time: " + (System.currentTimeMillis() - start) + " ms");
        return allRules;
    }

    private static String debugDir = null;//"/tmp/bugfinding-08";

    private String getDebugInstanceName(String base) {

        StringJoiner sj = new StringJoiner("-");
        sj.add(base);
        sj.add(Long.toString(System.currentTimeMillis()));
        sj.add(bigStep ? "bigstep" : "nobigstep");
        sj.add(pre ? "pre" : "nopre");

        return debugDir + "/" + sj.toString() + ".smt";
    }

    private Status isJumpUnique(long rlimit, BigInteger pc, RuleTypeOracle ruleTypeOracle, List<Rule> instantiatedNonJumpRules, List<Rule> jumpRules, List<Rule> uniquenessQueryRules, QueryNameParser
            queryParser, TranslationPipeline instantiationPipeline) {
        final int uniquenessBoost = this.uniquenessBoost;

        List<Rule> allRules = new ArrayList<>(instantiatedNonJumpRules);
        allRules.addAll(instantiationPipeline.apply(jumpRules));

        Rule query = instantiationPipeline.apply(uniquenessQueryRules).stream().filter(r -> queryParser.getIntParameter(r.name, "!pc").equals(pc)).findFirst().get();
        allRules.add(query);

        allRules = applyFolding(ruleTypeOracle, allRules);

        StatelessZ3QueryExecutor executor = new StatelessZ3QueryExecutor(TranslateToZ3VisitorState::withGeneralIntegers, Collections.singletonMap("rlimit", Long.toString(rlimit * uniquenessBoost)), allRules, ruleTypeOracle);
        ExecutionResult result = executor.executeQuery(query);
        (new ExecutionResultHandler.ConsoleOutputExecutionResultHandler("UNIQUENESS")).handle(Collections.singletonList(result));

        return result.status;
    }

    private String cutFileExtension(String name, String extension) {
        if (!name.endsWith(extension)) {
            return name;
        }

        return name.substring(0, name.lastIndexOf(extension));
    }

    private static class JumpDestinationReconstructionRuleTypeOracle {
        private final RuleTypeOracle ruleTypeOracle;

        JumpDestinationReconstructionRuleTypeOracle(RuleTypeOracle ruleTypeOracle) {
            this.ruleTypeOracle = ruleTypeOracle;
        }

        private RuleType getRuleTypeForNonInstantiatedRule(Rule rule) {
            if (ruleTypeOracle.isQueryOrTest(rule)) {
                if (rule.name.equals(JUMP_UNIQUENESS_QUERY_NAME) || rule.name.equals(JUMPI_UNIQUENESS_QUERY_NAME)) {
                    return RuleType.UNIQUENESS_QUERY;
                } else if (rule.name.equals(JUMP_QUERY_NAME) || rule.name.equals(JUMPI_QUERY_NAME)) {
                    return RuleType.REACHABILITY_QUERY;
                } else if (rule.name.equals(JUMP_ALL_KNOWN_QUERY_NAME) || rule.name.equals(JUMPI_ALL_KNOWN_QUERY_NAME)) {
                    return RuleType.ALL_KNOWN_QUERY;
                } else {
                    return RuleType.QUERY;
                }
            } else {
                if (rule.name.equals(JUMP_RULE_NAME) || rule.name.startsWith(JUMPI_RULE_NAME)) {
                    return RuleType.JUMP;
                } else {
                    return RuleType.REGULAR;
                }
            }
        }
    }
}
