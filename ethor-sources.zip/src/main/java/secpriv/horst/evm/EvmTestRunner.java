package secpriv.horst.evm;

import com.microsoft.z3.Status;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.Appender;
import org.apache.logging.log4j.core.LoggerContext;
import picocli.CommandLine;
import secpriv.horst.data.Rule;
import secpriv.horst.execution.ExecutionResult;
import secpriv.horst.execution.ExecutionResultHandler;
import secpriv.horst.execution.ExecutionStrategy;
import secpriv.horst.execution.StatelessZ3QueryExecutor;
import secpriv.horst.internals.SelectorFunctionHelper;
import secpriv.horst.internals.SelectorFunctionInvoker;
import secpriv.horst.tools.HorstFileParser;
import secpriv.horst.tools.OptionPairParser;
import secpriv.horst.tools.SmtLibGenerator;
import secpriv.horst.translation.*;
import secpriv.horst.translation.layout.FlatTypeLayouterWithBoolean;
import secpriv.horst.translation.visitors.*;
import secpriv.horst.visitors.RuleTypeOracle;
import secpriv.horst.visitors.StateBasedRuleTypeOracle;
import secpriv.horst.visitors.VisitorState;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@CommandLine.Command(name = "EvmTestRunner", mixinStandardHelpOptions = true, version = "EvmTestRunner version 0.0")
public class EvmTestRunner implements Runnable {
    @CommandLine.Option(names = {"-v", "--verbose"}, description = "Verbose mode. Helpful for troubleshooting. " +
            "Multiple -v options increase the verbosity.")

    private boolean[] verbose = new boolean[0];
    @CommandLine.Option(names = {"-s", "--spec"}, description = "Provide the HoRSt spec to compile. You can specify multiple files. The definitions of one file " +
            "will be visible in the the subsequent files.", arity = "1..*")
    private String[] horstFiles = new String[0];

    @CommandLine.Option(names = {"--z3-param"}, description = "Provide an additional option in the form of name=value to z3", arity = "0..*")
    private String[] z3Params = new String[0];

    @CommandLine.Parameters
    private File[] testFiles;

    @CommandLine.Option(names = "--prune-strategy", defaultValue = "none", arity = "1")
    private PruneStrategy.Enum pruneStrategy;

    @CommandLine.Option(names = "--predicate-inlining-strategy", defaultValue = "none", arity = "1")
    private PredicateInliningStrategy.Enum predicateInliningStrategy;

    @CommandLine.Option(names = {"-p", "--preanalysis"}, description = "Apply pre-analysis")
    private boolean pre = false;

    private static final Logger logger = LogManager.getLogger(EvmTestRunner.class);


    public static void main(String[] args) {
        CommandLine.run(new EvmTestRunner(), args);
    }

    enum TestResultCategory {correctAndUnique, imprecise, incorrect, irregularHaltUnreachable, irregularHaltReachable, ignored, unknown}

    private Map<TestResultCategory, List<String>> testResults = new HashMap<>();

    private class EvmTestResultHandler extends ExecutionResultHandler {
        private static final String CORRECT_VALUE_QUERY = "correctValues";
        private static final String UNIQUE_VALUE_QUERY = "uniqueValues";
        private static final String IRREGULAR_HALT_QUERY = "irregularHalt";
        private final String name;

        private EvmTestResultHandler(String name) {
            this.name = name;
        }

        private class IsSuccessVisitor implements ExecutionResult.Visitor<Boolean> {
            @Override
            public Boolean accept(ExecutionResult.QueryResult queryResult) {
                throw new IllegalArgumentException("Only Tests can be successful or not!");
            }

            @Override
            public Boolean accept(ExecutionResult.TestResult testResult) {
                return testResult.success;
            }
        }

        private TestResultCategory classifyResults(List<ExecutionResult> results) {
            if (results.isEmpty()) {
                return TestResultCategory.irregularHaltUnreachable;
            }

            if (results.stream().anyMatch(r -> r.status == Status.UNKNOWN)) {
                results.forEach(r -> r.info.ifPresent(logger::warn));
                return TestResultCategory.unknown;
            }

            if (results.size() == 1) {
                ExecutionResult result = results.get(0);
                if (result.queryId.startsWith(IRREGULAR_HALT_QUERY)) {
                    if (result.accept(new IsSuccessVisitor())) {
                        return TestResultCategory.irregularHaltUnreachable;
                    } else {
                        return TestResultCategory.irregularHaltReachable;
                    }
                } else if (result.queryId.startsWith(CORRECT_VALUE_QUERY)) {
                    return TestResultCategory.correctAndUnique;
                }
            } else if (results.size() == 2) {
                boolean correct = false;
                boolean unique = false;

                for (ExecutionResult result : results) {
                    if (result.accept(new IsSuccessVisitor())) {
                        if (result.queryId.startsWith(CORRECT_VALUE_QUERY)) {
                            correct = true;
                        } else if (result.queryId.startsWith(UNIQUE_VALUE_QUERY)) {
                            unique = true;
                        }
                    }
                }

                if (correct) {
                    if (unique) {
                        return TestResultCategory.correctAndUnique;
                    } else {
                        return TestResultCategory.imprecise;
                    }
                } else {
                    return TestResultCategory.incorrect;
                }
            }
            return TestResultCategory.ignored;
        }

        @Override
        public void handle(List<ExecutionResult> results) {
            testResults.get(classifyResults(results)).add(name);
        }
    }

    @Override
    public void run() {
        configureLogger();
        Map<String, String> z3ParamMap = OptionPairParser.parseOptionPairs(z3Params);
        Arrays.stream(TestResultCategory.values()).forEach(c -> testResults.put(c, new ArrayList<>()));
        try {
            int i = 0;
            for (File testFile : testFiles) {
                logger.info("Running {} ({} of {})", testFile, ++i, testFiles.length);
                SelectorFunctionHelper compiler = new SelectorFunctionHelper();
                EvmTestSelectorFunctionProvider selectorFunctionProviderTemplate = new EvmTestSelectorFunctionProvider(new String[]{testFile.getPath()}, false);
                ContractInfoReader contractInfoReader = selectorFunctionProviderTemplate.getContractInfoReader();

                compiler.registerProvider(selectorFunctionProviderTemplate);

                EvmSelectorFunctionProviderTemplate providerTemplate;
                if (pre) {
                    ConstantAnalysis ca = new ConstantAnalysis(contractInfoReader.getContractInfos());
                    ca.getBlocksFromBytecode();
                    ca.runBlocks();
                    providerTemplate = ca;
                } else {
                    providerTemplate = new EvmSelectorFunctionProvider(contractInfoReader.getContractInfos());
                }

                selectorFunctionProviderTemplate.setEvmSelectorFunctionProvider(providerTemplate);

                VisitorState state = new VisitorState();
                state.setSelectorFunctionHelper(compiler);

                state = HorstFileParser.parseAllHorstFiles(state, horstFiles);

                RuleTypeOracle ruleTypeOracle = new StateBasedRuleTypeOracle(state);

                TranslationPipeline.TranslationPipelineBuilder pipelineBuilder = TranslationPipeline
                        .builder()
                        .addStep(new InlineOperationsRuleVisitor(new ArrayList<>(state.getOperations().values())))
                        .addStep(new InlineTypesRuleVisitor(new InlineTypesExpressionVisitor(new FlatTypeLayouterWithBoolean())))
                        .addFlatMappingStep(new InstantiateParametersRuleVisitor(new SelectorFunctionInvoker(compiler)))
                        .addStep(new SimplifyPredicateArgumentsRuleVisitor())
                        .addStep(new RenameFreeVariablesRuleVisitor())
                        .addStep(new ConstantFoldingRuleVisitor())
                        .addStep(new FilterUnapplicableClausesRuleVisitor(ruleTypeOracle))
                        .addStep(new RemoveTruePremiseRuleVisitor());

                TranslationPipeline pipeline = pipelineBuilder.build();
                List<Rule> allRules = pipeline.apply(new ArrayList<>(state.getRules().values()));

                ExecutionStrategy executionStrategy = new ExecutionStrategy.ExecuteAllStrategy();

                allRules = MediumStepTransformer.foldToMediumStepsWithMagic(allRules, ruleTypeOracle, pruneStrategy.strategy, predicateInliningStrategy.strategy);

                StatelessZ3QueryExecutor executor = new StatelessZ3QueryExecutor(TranslateToZ3VisitorState::withGeneralIntegers, z3ParamMap, allRules, ruleTypeOracle, executionStrategy);
                List<ExecutionResult> executionResults = allRules.stream().filter(ruleTypeOracle::isQueryOrTest).map(executor::executeQuery).collect(Collectors.toList());

                List<ExecutionResultHandler> resultHandlers = new ArrayList<>();
                resultHandlers.add(new EvmTestResultHandler(testFile.getAbsolutePath()));
                for (ExecutionResultHandler resultHandler : resultHandlers) {
                    resultHandler.handle(executionResults);
                }
            }

            System.out.println("Results: ");
            Arrays.stream(TestResultCategory.values()).forEach(c -> System.out.println(c + ": " + testResults.get(c).size()));

            logger.info("Detailed results:\n{}", testResults.entrySet().stream().flatMap(e -> e.getValue().stream().map(s -> e.getKey()+ ":" + s)).collect(Collectors.joining("\n")));

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void configureLogger() {
        LoggerContext context = (LoggerContext) LogManager.getContext(false);
        Level level = getLoggerLevel();
        context.getConfiguration().getRootLogger().setLevel(level);

        Appender consoleAppender = context.getConfiguration().getAppender("Console");
        context.getConfiguration().getRootLogger().addAppender(consoleAppender, level, null);
    }

    private Level getLoggerLevel() {
        switch (verbose.length) {
            case 0:
                return Level.ERROR;
            case 1:
                return Level.WARN;
            case 2:
                return Level.INFO;
            case 3:
                return Level.DEBUG;
        }
        return Level.TRACE;
    }
}
