package secpriv.horst.evm;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public abstract class EvmSourceProvider {
    public static EvmSourceProvider fromAnyFile(File file) {
        if (file.getName().endsWith(".json")) {
            return fromJsonFile(file);
        }
        return fromPlainFile(file);
    }

    public abstract String getSource();

    public abstract BigInteger getId();

    public Optional<Map<BigInteger, List<BigInteger>>> getJumps() {
        return Optional.empty();
    }

    private static class BufferedEvmSourceProvider extends EvmSourceProvider {
        private final String source;
        private final BigInteger id;

        private BufferedEvmSourceProvider(String source, BigInteger id) {
            this.source = source;
            this.id = id;
        }

        @Override
        public String getSource() {
            return source;
        }

        @Override
        public BigInteger getId() {
            return id;
        }
    }

    private static class BufferedEvmSourceProviderWithJumps extends BufferedEvmSourceProvider {
        private final Map<BigInteger, List<BigInteger>> jumps;

        private BufferedEvmSourceProviderWithJumps(String source, BigInteger id, Map<BigInteger, List<BigInteger>> jumps) {
            super(source, id);
            this.jumps = Objects.requireNonNull(jumps, "Jumps may not be null!");
        }

        @Override
        public Optional<Map<BigInteger, List<BigInteger>>> getJumps() {
            return Optional.of(jumps);
        }
    }

    public static class EvmSourceWithBalanceProvider extends BufferedEvmSourceProvider {
        private final BigInteger balance;
        private final String idAsString;

        private EvmSourceWithBalanceProvider(String source, String idAsString, BigInteger balance) {
            super(source, new BigInteger(idAsString, 16));
            this.balance = balance;
            this.idAsString = idAsString;
        }

        public String getIdAsString() {
            return idAsString;
        }

        public BigInteger getBalance() {
            return balance;
        }
    }

    public static EvmSourceProvider fromPlainFile(File file) {
        try {
            String code = new String(Files.readAllBytes(file.toPath()));
            return new BufferedEvmSourceProvider(code, BigInteger.ZERO);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static EvmSourceProvider fromJsonFile(File file) {
        try {
            JsonObject jsonObject = new JsonParser().parse(new String(Files.readAllBytes(file.toPath()))).getAsJsonObject();
            String code = ignore0x(jsonObject.get("bytecode").getAsString());
            BigInteger id = new BigInteger(ignore0x(jsonObject.get("address").getAsString()), 16);

            JsonObject jumps = jsonObject.getAsJsonObject("jumpDestinations");
            if (jumps == null) {
                return new BufferedEvmSourceProvider(code, id);
            } else {
                return new BufferedEvmSourceProviderWithJumps(code, id, jumps.entrySet().stream().collect(Collectors.toMap(
                        e -> new BigInteger(e.getKey()),
                        e -> StreamSupport.stream(e.getValue().getAsJsonArray().spliterator(), false).map(JsonElement::getAsBigInteger).collect(Collectors.toList())
                )));
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static EvmSourceWithBalanceProvider fromJsonFileWithBalance(File file) {
        try {
            JsonObject jsonObject = new JsonParser().parse(new String(Files.readAllBytes(file.toPath()))).getAsJsonObject();
            String code = ignore0x(jsonObject.get("bytecode").getAsString());
            String idAsString = ignore0x(jsonObject.get("address").getAsString());
            BigInteger balance = new BigInteger(jsonObject.get("balance").getAsString());
            return new EvmSourceWithBalanceProvider(code, idAsString, balance);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static EvmSourceWithBalanceProvider fromTextFileWithBalance(File file, BigInteger balance) {
        EvmSourceProvider provider = fromPlainFile(file);
        return new EvmSourceWithBalanceProvider(provider.getSource(), "0", balance);
    }


    private static String ignore0x(String bytecode) {
        if (bytecode.startsWith("0x")) {
            return bytecode.substring(2);
        } else
            return bytecode;
    }
}
