package secpriv.horst.evm;

import java.math.BigInteger;
import java.util.*;
import java.util.stream.Collectors;

class JumpMap {
    private final Map<BigInteger, List<BigInteger>> possibleJumpDests;
    private final Map<BigInteger, List<BigInteger>> provenJumpDests;

    private final Map<BigInteger, List<BigInteger>> provenJumpDestsAtAmbiguity;

    JumpMap(Map<BigInteger, List<BigInteger>> possibleJumpDests, Map<BigInteger, List<BigInteger>> provenJumpDests) {
        for (Map.Entry<BigInteger, List<BigInteger>> entry : provenJumpDests.entrySet()) {
            if (!possibleJumpDests.containsKey(entry.getKey())) {
                throw new IllegalArgumentException("provenJumpDests contains pc " + entry.getKey() + " which is not contained in possibleJumpDests!");
            }
            if (!possibleJumpDests.get(entry.getKey()).containsAll(entry.getValue())) {
                throw new IllegalArgumentException("provenJumpDests contains impossible jump at pc " + entry.getKey() + "!");
            }
        }

        this.possibleJumpDests = possibleJumpDests;
        this.provenJumpDests = provenJumpDests;
        this.provenJumpDestsAtAmbiguity = new HashMap<>();
    }

    public boolean isJumpPossible(BigInteger pc, BigInteger jumpDest) {
        return possibleJumpDests.getOrDefault(pc, Collections.emptyList()).contains(jumpDest);
    }

    public boolean isJumpProven(BigInteger pc, BigInteger jumpDest) {
        return provenJumpDests.getOrDefault(pc, Collections.emptyList()).contains(jumpDest);
    }

    public boolean isJumpUniquelyDetermined(BigInteger pc) {
        if (!possibleJumpDests.containsKey(pc)) {
            throw new IllegalArgumentException(pc + " is not a possible JumpDestination!");
        }

        List<BigInteger> possibleJumps = possibleJumpDests.getOrDefault(pc, Collections.emptyList());
        List<BigInteger> provenJumps = provenJumpDests.getOrDefault(pc, Collections.emptyList());

        if (possibleJumps.size() != provenJumps.size()) {
            return false;
        }

        return possibleJumps.containsAll(provenJumps);
    }

    public void removePossibility(BigInteger pc, BigInteger jumpDest) {
        if (!possibleJumpDests.containsKey(pc)) {
            throw new IllegalArgumentException("Tried to remove " + pc + " which does not seem to be a valid jump!");
        }
        if (!possibleJumpDests.get(pc).remove(jumpDest)) {
            throw new IllegalArgumentException();
        }
    }

    public void addProve(BigInteger pc, BigInteger jumpDest) {
        if (!possibleJumpDests.containsKey(pc)) {
            throw new IllegalArgumentException("Try to add proof for pc " + pc + ", which is no possible jump!");
        }
        if (!possibleJumpDests.get(pc).contains(jumpDest)) {
            throw new IllegalArgumentException("Try to add proof for jump destination " + jumpDest + ", which is no possible destination for " + pc + "!");
        }
        if (!provenJumpDests.containsKey(pc)) {
            provenJumpDests.put(pc, new ArrayList<>());
        }
        provenJumpDests.get(pc).add(jumpDest);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Possible JumpDestinations:\n");
        for (BigInteger pc : possibleJumpDests.keySet().stream().sorted(BigInteger::compareTo).collect(Collectors.toList())) {
            if (!isJumpUniquelyDetermined(pc)) {
                sb.append(pc);
                sb.append(": ");
                sb.append(possibleJumpDests.get(pc));
                sb.append("\n");
            }
        }
        sb.append("Proven JumpDestinations:\n");
        for (BigInteger pc : provenJumpDests.keySet().stream().sorted(BigInteger::compareTo).collect(Collectors.toList())) {
            if (!isJumpUniquelyDetermined(pc)) {
                sb.append(pc);
                sb.append(": ");
                sb.append(provenJumpDests.get(pc));
                sb.append("\n");
            }
        }
        sb.append("Unique JumpDestinations:\n");
        Set<BigInteger> allJumps = new HashSet<>(provenJumpDests.keySet());
        allJumps.addAll(possibleJumpDests.keySet());
        for (BigInteger pc : allJumps.stream().sorted(BigInteger::compareTo).collect(Collectors.toList())) {
            if (isJumpUniquelyDetermined(pc)) {
                sb.append(pc);
                sb.append(": ");
                sb.append(possibleJumpDests.get(pc));
                sb.append("\n");
            }
        }
        return sb.toString();
    }

    public int addUniquenessProof(BigInteger pc) {
        if (!provenJumpDests.containsKey(pc)) {
            throw new IllegalArgumentException("To adding a uniqueness proof requires proven jump destinations, but for pc " + pc + " no proofs exist!");
        }
        int previousSize = possibleJumpDests.get(pc).size();
        possibleJumpDests.put(pc, provenJumpDests.get(pc));
        return previousSize - possibleJumpDests.get(pc).size();
    }

    public void addAmbiguityProof(BigInteger pc) {
        provenJumpDestsAtAmbiguity.put(pc, new ArrayList<>(provenJumpDests.get(pc)));
    }

    private boolean hasProvenSetChangedSinceLastAmbiguityProof(BigInteger pc) {
        List<BigInteger> a = provenJumpDestsAtAmbiguity.getOrDefault(pc, Collections.emptyList());
        List<BigInteger> b = provenJumpDests.getOrDefault(pc, Collections.emptyList());

        if (a.size() == b.size()) {
            return !a.containsAll(b);
        }
        return true;
    }

    public Collection<BigInteger> getUniquenessTestCandidates() {
        return provenJumpDests.keySet().stream().filter(pc -> !isJumpUniquelyDetermined(pc)).filter(this::hasProvenSetChangedSinceLastAmbiguityProof).collect(Collectors.toList());
    }

    public int getUndeterminedCount() {
        return possibleJumpDests.keySet().stream().filter(pc -> !isJumpUniquelyDetermined(pc)).map(pc -> possibleJumpDests.get(pc).size()).reduce(0, Integer::sum);
    }

    public List<BigInteger> getPossibilities(BigInteger pc) {
        return new ArrayList<>(possibleJumpDests.get(pc));
    }

    public void addPossibility(BigInteger pc, BigInteger jumpDest) {
        if (!possibleJumpDests.containsKey(pc)) {
            possibleJumpDests.put(pc, new ArrayList<>());
        }
        possibleJumpDests.get(pc).add(jumpDest);
    }
}
