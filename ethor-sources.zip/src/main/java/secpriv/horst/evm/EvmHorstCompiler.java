package secpriv.horst.evm;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.Appender;
import org.apache.logging.log4j.core.LoggerContext;
import picocli.CommandLine;
import secpriv.horst.data.Predicate;
import secpriv.horst.data.Rule;
import secpriv.horst.execution.*;
import secpriv.horst.internals.SelectorFunctionHelper;
import secpriv.horst.internals.SelectorFunctionInvoker;
import secpriv.horst.tools.HorstFileParser;
import secpriv.horst.tools.OptionPairParser;
import secpriv.horst.tools.PredicateHelper;
import secpriv.horst.translation.PredicateInliningStrategy;
import secpriv.horst.translation.PruneStrategy;
import secpriv.horst.translation.TranslateToZ3VisitorState;
import secpriv.horst.translation.TranslationPipeline;
import secpriv.horst.translation.layout.FlatTypeLayouterWithBoolean;
import secpriv.horst.translation.visitors.*;
import secpriv.horst.visitors.VisitorState;

import java.io.File;
import java.util.*;
import java.util.stream.Collectors;

@CommandLine.Command(name = "EvmHorstCompiler", mixinStandardHelpOptions = true, version = "EvmHorstCompiler version 0.0")
public class EvmHorstCompiler implements Runnable {
    @CommandLine.Option(names = {"-v", "--verbose"}, description = "Verbose mode. Helpful for troubleshooting. " +
            "Multiple -v options increase the verbosity.")
    private boolean[] verbose = new boolean[0];

    @CommandLine.Option(names = {"-s", "--spec"}, description = "Provide the HoRSt spec to compile. You can specify multiple files. The definitions of one file " +
            "will be visible in the the subsequent files.", arity = "1..*")
    private String[] horstFiles = new String[0];

    @CommandLine.Option(names = {"--z3-param"}, description = "Provide an additional option in the form of name=value to z3", arity = "0..*")
    private String[] z3Params = new String[0];

    @CommandLine.Option(names = {"-b", "--big-step-encoding"}, description = "[Deprecated] Apply big-step encoding. Equivalent to --prune-strategy=deleteLeaves --predicate-inlining-strategy=linear.", hidden = true)
    private boolean bigStep = false;

    @CommandLine.Option(names = {"--no-output-query-results"}, description = "Don't execute queries via z3 API and output results to command line.", defaultValue = "false")
    private boolean noOutputQueryResults;

    @CommandLine.Option(names = {"--exclude-queries"}, description = "Do not execute these queries", arity = "0..*")
    private String[] excludedQueries = new String[0];

    @CommandLine.Option(names = {"-p", "--preanalysis"}, description = "Apply pre-analysis")
    private boolean pre = false;

    @CommandLine.Parameters
    private File[] contractFiles;

    @CommandLine.Option(names = {"--json-out-dir"}, description = "Directory where json files are written.")
    private String jsonOutDir;

    @CommandLine.Option(names = {"--smt-out-dir"}, description = "Directory files where smt are written.")
    private String smtOutDir;

    @CommandLine.Option(names = {"--rlimit"}, defaultValue = "0", description = "[Deprecated] rlimit used for reachability queries. Equivalent to --z3-param rlimit=xxx.", hidden = true)
    private long rlimit;

    @CommandLine.Option(names = {"--query-specific-preprocessing"}, description = "Apply query preprocessing (pruning, predicate inlining, smt-out) separately for every query.")
    private boolean querySpecificPreprocessing;

    @CommandLine.Option(names = {"--folding-timeout"}, defaultValue = "0", description = "Maximal time out used for predicate pruning and inlining.")
    private long foldingTimeout;

    @CommandLine.Option(names = "--prune-strategy", defaultValue = "none", arity = "1")
    private PruneStrategy.Enum pruneStrategy;

    @CommandLine.Option(names = "--predicate-inlining-strategy", defaultValue = "none", arity = "1")
    private PredicateInliningStrategy.Enum predicateInliningStrategy;

    @CommandLine.Option(names = "--execution-strategy", defaultValue = "all", arity = "1")
    private ExecutionStrategy.Enum executionStrategy;

    private static final Logger logger = LogManager.getLogger(EvmHorstCompiler.class);

    private Map<String, String> z3ParamMap;

    public static void main(String[] args) {
        CommandLine.run(new EvmHorstCompiler(), args);
    }

    @Override
    public void run() {
        configureLogger();
        configureArguments();

        for (File contractFile : contractFiles) {
            List<ExecutionResultHandler> resultHandlers = initializeResultHandlers(contractFile);
            List<PreprocessingStrategy> preprocessingStrategies = initializePreprocessingStrategies(contractFile);
            List<QuerySpecificPreprocessingStrategy> querySpecificPreprocessingStrategies = initializeQuerySpecificPreprocessingStrategies(contractFile);

            logger.info("Compiling {}.", contractFile.getName());
            SelectorFunctionHelper compiler = new SelectorFunctionHelper();
            ContractInfoReader contractInfoReader = new ContractInfoReader(EvmSourceProvider.fromAnyFile(contractFile), false);
            EvmSelectorFunctionProviderTemplate providerTemplate;

            if (pre) {
                ConstantAnalysis ca = new ConstantAnalysis(contractInfoReader.getContractInfos());
                ca.getBlocksFromBytecode();
                ca.runBlocks();
                providerTemplate = ca;
            } else {
                providerTemplate = new EvmSelectorFunctionProvider(contractInfoReader.getContractInfos());
            }

            compiler.registerProvider(providerTemplate);

            VisitorState state = new VisitorState();
            state.setSelectorFunctionHelper(compiler);

            state = HorstFileParser.parseAllHorstFiles(state, horstFiles);

            TranslationPipeline.TranslationPipelineBuilder pipelineBuilder = TranslationPipeline
                    .builder()
                    .addStep(new InlineOperationsRuleVisitor(new ArrayList<>(state.getOperations().values())))
                    .addStep(new InlineTypesRuleVisitor(new InlineTypesExpressionVisitor(new FlatTypeLayouterWithBoolean())))
                    .addFlatMappingStep(new InstantiateParametersRuleVisitor(new SelectorFunctionInvoker(compiler)))
                    .addStep(new SimplifyPredicateArgumentsRuleVisitor())
                    .addStep(new ConstantFoldingRuleVisitor())
                    .addStep(new FilterUnapplicableClausesRuleVisitor())
                    .addStep(new RemoveTruePremiseRuleVisitor());

            TranslationPipeline pipeline = pipelineBuilder.build();
            List<Rule> allRules = pipeline.apply(new ArrayList<>(state.getRules().values()));
            Set<Predicate> originalQueries = allRules.stream().flatMap(r -> r.clauses.stream()).map(c -> c.conclusion.predicate).filter(PredicateHelper::isQueryOrTest).collect(Collectors.toSet());

            Optional<List<Rule>> optFoldedRules = applyPreprocessing(allRules, preprocessingStrategies, originalQueries);
            if (!optFoldedRules.isPresent()) {
                continue;
            }

            allRules = optFoldedRules.get();

            if (!resultHandlers.isEmpty()) {
                StatelessZ3QueryExecutor executor = new StatelessZ3QueryExecutor(TranslateToZ3VisitorState::withGeneralIntegers, z3ParamMap, allRules, executionStrategy.getStrategy(), querySpecificPreprocessingStrategies);
                List<ExecutionResult> executionResults = originalQueries.stream().filter(q -> Arrays.stream(excludedQueries).noneMatch(q.name::equals)).map(executor::executeQuery).collect(Collectors.toList());

                for (ExecutionResultHandler resultHandler : resultHandlers) {
                    resultHandler.handle(executionResults);
                }
            } else {
                logger.info("Do not execute z3 queries because results are not requested.");
            }
        }
    }

    private List<QuerySpecificPreprocessingStrategy> initializeQuerySpecificPreprocessingStrategies(File contractFile) {
        List<QuerySpecificPreprocessingStrategy> preprocessingStrategies = new ArrayList<>();

        if (querySpecificPreprocessing) {
            if (foldingTimeout == 0) {
                preprocessingStrategies.add(new QuerySpecificPreprocessingStrategy.ApplyMediumStepTransformationPreprocessingStrategy(pruneStrategy.strategy, predicateInliningStrategy.strategy));
            } else if (foldingTimeout > 0) {
                preprocessingStrategies.add(new QuerySpecificPreprocessingStrategy.ApplyMediumStepTransformationWithTimeoutPreprocessingStrategy(pruneStrategy.strategy, predicateInliningStrategy.strategy, foldingTimeout));
            } else {
                throw new IllegalArgumentException("Folding timeout cannot be negative!");
            }

            if (smtOutDir != null) {
                String header = getHeader(contractFile);
                String fileName = smtOutDir + "/" + contractFile.getName();

                preprocessingStrategies.add(new QuerySpecificPreprocessingStrategy.WriteSmtOutPreprocessingStrategy(fileName, header));
            }
        }

        return preprocessingStrategies;
    }

    private String getHeader(File contractFile) {
        return "; contract file: " + contractFile.getName() + "\n" +
                "; horst files: " + String.join(", ", horstFiles) + "\n" +
                "; pre-analysis: " + pre + "\n" +
                "; prune-strategy: " + pruneStrategy + "\n" +
                "; predicate-inline-strategy: " + predicateInliningStrategy + "\n\n"
                + z3ParamMap.entrySet().stream().map(e -> "(set-option :" + e.getKey() + " " + e.getValue() + ")\n").collect(Collectors.joining());
    }

    private Optional<List<Rule>> applyPreprocessing(List<Rule> allRules, List<PreprocessingStrategy> preprocessingStrategies, Set<Predicate> queries) {
        List<Rule> rules = allRules;

        for (PreprocessingStrategy preprocessingStrategy : preprocessingStrategies) {
            Optional<List<Rule>> optRules = preprocessingStrategy.preprocess(rules, queries);
            if (!optRules.isPresent()) {
                return Optional.empty();
            }
            rules = optRules.get();
        }

        return Optional.of(rules);
    }

    private List<PreprocessingStrategy> initializePreprocessingStrategies(File contractFile) {
        List<PreprocessingStrategy> preprocessingStrategies = new ArrayList<>();

        if (!querySpecificPreprocessing) {
            if (foldingTimeout == 0) {
                preprocessingStrategies.add(new PreprocessingStrategy.ApplyMediumStepTransformationPreprocessingStrategy(pruneStrategy.strategy, predicateInliningStrategy.strategy));
            } else if (foldingTimeout > 0) {
                preprocessingStrategies.add(new PreprocessingStrategy.ApplyMediumStepTransformationWithTimeoutPreprocessingStrategy(pruneStrategy.strategy, predicateInliningStrategy.strategy, foldingTimeout));
            } else {
                throw new IllegalArgumentException("Folding timeout cannot be negative!");
            }

            if (smtOutDir != null) {
                String header = getHeader(contractFile);
                String fileName = smtOutDir + "/" + contractFile.getName() + ".smt";

                preprocessingStrategies.add(new PreprocessingStrategy.WriteSmtOutPreprocessingStrategy(fileName, header));
            }
        }

        return preprocessingStrategies;
    }

    private void configureArguments() {
        if (bigStep) {
            logger.warn("Using deprecated flag -b/--big-step-encoding. Consider using --prune-strategy and --predicate-inlining-strategy instead.");
            pruneStrategy = PruneStrategy.Enum.deleteLeaves;
            predicateInliningStrategy = PredicateInliningStrategy.Enum.linear;
        }

        z3ParamMap = OptionPairParser.parseOptionPairs(z3Params);

        if (rlimit > 0) {
            logger.warn("Using deprecated option rlimit!");
            z3ParamMap.put("rlimit", Long.toString(rlimit));
        }
    }

    private List<ExecutionResultHandler> initializeResultHandlers(File contractFile) {
        List<ExecutionResultHandler> resultHandlers = new ArrayList<>();

        if (jsonOutDir != null) {
            resultHandlers.add(new ExecutionResultHandler.JsonOutputExecutionResultHandler(jsonOutDir + "/" + contractFile.getName() + ".json"));
        }

        if (!noOutputQueryResults) {
            resultHandlers.add(new ExecutionResultHandler.ConsoleOutputExecutionResultHandler(contractFile.getName()));
        }

        return resultHandlers;
    }

    private void configureLogger() {
        LoggerContext context = (LoggerContext) LogManager.getContext(false);
        Level level = getLoggerLevel();
        context.getConfiguration().getRootLogger().setLevel(level);

        Appender consoleAppender = context.getConfiguration().getAppender("Console");
        context.getConfiguration().getRootLogger().addAppender(consoleAppender, level, null);

        if (verbose.length == 1) {
            logger.info("I will compile your HoRSt files!");
        } else if (verbose.length == 2) {
            logger.info("I will verbosely compile your HoRSt files!");
        } else if (verbose.length == 3) {
            logger.info("I will verbosemostly compile your HoRSt files!");
        } else if (verbose.length > 3) {
            logger.info("Dear Sir or Madam! I herewith assure you in the most sincere manner that I will apply the utmost verbosity while I compile your HoRSt files!");
        }
    }

    private Level getLoggerLevel() {
        switch (verbose.length) {
            case 0:
                return Level.ERROR;
            case 1:
                return Level.WARN;
            case 2:
                return Level.INFO;
            case 3:
                return Level.DEBUG;
        }
        return Level.TRACE;
    }
}
